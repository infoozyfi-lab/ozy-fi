'use client';

import React, { Suspense, useEffect, useMemo, useRef, useState, type CSSProperties, type FormEvent, type ChangeEvent, type MouseEvent } from 'react';
import { useSearchParams } from 'next/navigation';
import ResourceManager from '@/components/admin/ResourceManager';
import BundleManager from '@/components/admin/BundleManager';
import ScheduledOffersManager from '@/components/admin/ScheduledOffersManager';
import OrderKanban, { isRefundEligible, refundRemaining } from '@/components/admin/OrderKanban';
import MyAccountModal from '@/components/admin/MyAccountModal';
import ConfirmDialog from '@/components/admin/ConfirmDialog';
import StatTile from '@/components/admin/charts/StatTile';
import AreaTrendChart from '@/components/admin/charts/AreaTrendChart';
import BarChart from '@/components/admin/charts/BarChart';
import ColumnChart from '@/components/admin/charts/ColumnChart';
import StatusMixBar from '@/components/admin/charts/StatusMixBar';
import StatusPill, { STATUS_LABELS as STATUS_LABELS_LOCAL } from '@/components/admin/charts/StatusPill';
import PaymentStatusPill from '@/components/admin/charts/PaymentStatusPill';
import { CATEGORICAL, BRAND, GOLD, formatCurrency, formatCompactCurrency, formatNumber, percentChange } from '@/components/admin/charts/colors';
import type {
  OrderStatus,
  OrderType,
  OrderRow,
  OrderItemRow,
  StaffRole,
  RawCategory,
  RawOptionGroup,
  RawProduct,
  RawSettings,
  ResourceField,
  OpeningHoursDay,
  SpecialHoursEntry,
  StoryBannerImage,
  AuditLogRow,
  CouponRow as CouponRowType,
  StaffRow as StaffRowType,
} from '@/lib/types';
import { getProductFields } from '@/lib/admin-resource-fields';

// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 —
// 'accepted'/'ready' inserted between the existing stages (see
// lib/types.ts's OrderStatus for why no migration was needed).
const ORDER_STATUSES: OrderStatus[] = ['received', 'accepted', 'preparing', 'ready', 'on_the_way', 'delivered', 'cancelled'];
const STATUS_LABELS: Record<OrderStatus, string> = {
  received: 'Received',
  accepted: 'Accepted',
  preparing: 'Preparing',
  ready: 'Ready',
  on_the_way: 'Out for delivery',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

const box: CSSProperties = {
  background: 'var(--bg-card)',
  padding: '24px',
  borderRadius: '14px',
  border: '1px solid var(--line)',
  marginBottom: '24px',
  color: 'var(--cream)',
};

const card: CSSProperties = {
  background: 'var(--bg-card)',
  padding: '20px 22px',
  borderRadius: '14px',
  border: '1px solid var(--line)',
  color: 'var(--cream)',
};

const cardTitle: CSSProperties = { margin: '0 0 16px', fontSize: 16, fontWeight: 700, color: 'var(--cream)' };

const tabBtn = (active: boolean): CSSProperties => ({
  padding: '10px 18px',
  border: '1px solid var(--line)',
  borderBottom: active ? '2px solid var(--ember)' : '1px solid var(--line)',
  borderRadius: '8px 8px 0 0',
  background: active ? 'var(--bg-card)' : 'var(--bg-alt)',
  color: active ? 'var(--cream)' : 'var(--muted)',
  cursor: 'pointer',
  fontWeight: active ? 700 : 400,
});

const inputStyle: CSSProperties = {
  width: '100%',
  padding: '10px',
  marginTop: '4px',
  boxSizing: 'border-box',
  border: '1px solid var(--line)',
  borderRadius: '8px',
  fontSize: 14,
  background: 'var(--bg-alt)',
  color: 'var(--cream)',
};

const btn: CSSProperties = {
  padding: '8px 14px',
  border: '1px solid var(--line)',
  borderRadius: '8px',
  background: 'var(--bg-alt)',
  color: 'var(--cream)',
  cursor: 'pointer',
  fontSize: 13,
  marginRight: 8,
};
const btnPrimary: CSSProperties = { ...btn, background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none', fontWeight: 700 };
const btnDanger: CSSProperties = { ...btn, background: 'var(--danger)', color: 'var(--text-on-accent)', border: 'none', fontWeight: 700 };

const th: CSSProperties = { textAlign: 'left', padding: '10px', color: 'var(--muted)', fontSize: 12.5, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.03em' };
const td: CSSProperties = { padding: '12px 10px', borderTop: '1px solid var(--line)', fontSize: 13.5 };

/* ---------------- Analytics response shape (GET /api/admin/analytics) ---------------- */
// Page-local: this is the one server-side aggregation pass backing every
// chart & KPI on Overview + Reports, not a raw D1 row — see useAnalytics().

interface AnalyticsPeriod {
  revenue: number;
  orders: number;
}

interface AnalyticsSummary {
  today: AnalyticsPeriod;
  yesterday: AnalyticsPeriod;
  last7Days: AnalyticsPeriod;
  prev7Days: AnalyticsPeriod;
  last30Days: AnalyticsPeriod;
  prev30Days: AnalyticsPeriod;
  pendingOrders: number;
  avgOrderValue: number;
  totalRevenue: number;
  totalOrders: number;
  cancelledOrders: number;
}

interface DailyRevenueRow {
  day: string;
  revenue: number;
  orders: number;
}

interface BestSellerRow {
  name: string;
  qty: number;
  revenue: number;
}

interface CategoryBreakdownRow {
  category: string;
  revenue: number;
  qty: number;
}

interface StatusBreakdownRow {
  status: OrderStatus;
  count: number;
}

interface HourlyRow {
  hour: number;
  count: number;
}

interface AnalyticsData {
  summary: AnalyticsSummary;
  revenueByDay: DailyRevenueRow[];
  bestSellers: BestSellerRow[];
  todayBestSellers?: BestSellerRow[];
  categoryBreakdown: CategoryBreakdownRow[];
  statusBreakdown: StatusBreakdownRow[];
  todayStatusBreakdown?: StatusBreakdownRow[];
  hourlyDistribution: HourlyRow[];
}

/* ---------------- Shared data hooks ---------------- */

function useOrders(token: string) {
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    fetch('/api/admin/orders')
      .then((res) => res.json())
      .then((data) => setOrders(Array.isArray(data) ? data : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(load, [token]);

  return { orders, setOrders, loading, reload: load };
}

// Single fetch backing every chart & KPI on Overview + Reports — one
// server-side aggregation pass instead of each tab pulling the full order
// list and re-computing it in the browser.
function useAnalytics(token: string | null) {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    if (!token) return; // not signed in yet — the real fetch fires once the token lands
    setLoading(true);
    setError('');
    fetch('/api/admin/analytics')
      .then((res) => {
        if (!res.ok) throw new Error('Could not load analytics.');
        return res.json();
      })
      .then((d) => setData(d as AnalyticsData | null))
      .catch(() => setError('Could not load analytics.'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [token]);

  return { data, loading, error, reload: load };
}

// Fills gaps in the server's day-grouped revenue rows so the trend chart
// always draws a full, evenly-spaced 30-day line instead of skipping
// zero-order days.
function fillDailyRevenue(rows: DailyRevenueRow[] | undefined | null, days = 30): DailyRevenueRow[] {
  const byDay: Record<string, DailyRevenueRow> = {};
  (rows || []).forEach((r) => { byDay[r.day] = r; });
  const out: DailyRevenueRow[] = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    out.push(byDay[key] || { day: key, revenue: 0, orders: 0 });
  }
  return out;
}

const HOUR_LABELS = Array.from({ length: 24 }, (_, h) => `${h}`.padStart(2, '0'));

function fillHourly(rows: HourlyRow[] | undefined | null): { label: string; value: number }[] {
  const byHour: Record<number, number> = {};
  (rows || []).forEach((r) => { byHour[r.hour] = r.count; });
  return HOUR_LABELS.map((label, h) => ({ label, value: byHour[h] || 0 }));
}

/* ---------------- Overview (Dashboard home) ---------------- */

function OverviewTab({
  token,
  analytics,
  analyticsLoading,
  reloadAnalytics,
}: {
  token: string;
  analytics: AnalyticsData | null;
  analyticsLoading: boolean;
  reloadAnalytics: () => void;
}) {
  const { orders, loading: ordersLoading } = useOrders(token);
  const [productCount, setProductCount] = useState<number | null>(null);

  useEffect(() => {
    fetch('/api/admin/products')
      .then((r) => r.json())
      .then((d) => setProductCount(Array.isArray(d) ? d.length : null))
      .catch(() => {});
  }, [token]);

  if (analyticsLoading || !analytics) return <p>Loading dashboard…</p>;

  const { summary, revenueByDay, bestSellers, categoryBreakdown, statusBreakdown, hourlyDistribution } = analytics;

  const revenueTrend = fillDailyRevenue(revenueByDay, 30);
  const last7Sparkline = revenueTrend.slice(-7).map((d) => d.revenue);
  const hourlyData = fillHourly(hourlyDistribution);
  const statusCounts: Partial<Record<OrderStatus, number>> = Object.fromEntries((statusBreakdown || []).map((s) => [s.status, s.count]));

  const revenueDelta = percentChange(summary.today.revenue, summary.yesterday.revenue);
  const ordersDelta = percentChange(summary.today.orders, summary.yesterday.orders);
  const weekDelta = percentChange(summary.last7Days.revenue, summary.prev7Days.revenue);

  return (
    <>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <p style={{ margin: 0, color: 'var(--muted)', fontSize: 13.5 }}>Last 30 days, updated live from your orders.</p>
        <button type="button" style={btn} onClick={reloadAnalytics}>Refresh</button>
      </div>

      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 16, marginBottom: 20 }}>
        <StatTile
          label="Today's Sales"
          value={formatCurrency(summary.today.revenue)}
          delta={revenueDelta}
          deltaLabel="vs yesterday"
          accent={BRAND}
          sparkline={last7Sparkline}
        />
        <StatTile label="Today's Orders" value={formatNumber(summary.today.orders)} delta={ordersDelta} deltaLabel="vs yesterday" accent={GOLD} />
        <StatTile label="Sales, Last 7 Days" value={formatCurrency(summary.last7Days.revenue)} delta={weekDelta} deltaLabel="vs prior 7 days" accent={CATEGORICAL[0]} />
        <StatTile label="Pending Orders" value={formatNumber(summary.pendingOrders)} sublabel="in the kitchen or on the way" goodDirection="down" />
        <StatTile label="Avg Order Value" value={formatCurrency(summary.avgOrderValue)} sublabel="all-time" />
        <StatTile label="Total Products" value={productCount === null ? '…' : formatNumber(productCount)} sublabel="active in menu" />
      </section>

      <div style={{ ...card, marginBottom: 20 }}>
        <h2 style={cardTitle}>Revenue — last 30 days</h2>
        <AreaTrendChart data={revenueTrend} color={BRAND} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20, marginBottom: 20 }}>
        <div style={card}>
          <h2 style={cardTitle}>Best sellers</h2>
          <BarChart
            items={bestSellers.map((p) => ({ label: p.name, value: p.qty, sublabel: formatCurrency(p.revenue) }))}
            color={BRAND}
            valueFormatter={(v) => `${formatNumber(v)}×`}
            emptyMessage="No items sold yet."
          />
        </div>
        <div style={card}>
          <h2 style={cardTitle}>Revenue by category</h2>
          <BarChart
            items={categoryBreakdown.slice(0, 8).map((c) => ({ label: c.category, value: c.revenue, sublabel: `${formatNumber(c.qty)} sold` }))}
            color={(i) => CATEGORICAL[i % CATEGORICAL.length]}
            valueFormatter={formatCompactCurrency}
            emptyMessage="No sales yet."
          />
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20, marginBottom: 20 }}>
        <div style={card}>
          <h2 style={cardTitle}>Order status mix (30d)</h2>
          <StatusMixBar counts={statusCounts} />
        </div>
        <div style={card}>
          <h2 style={cardTitle}>Peak ordering hours (30d)</h2>
          <ColumnChart data={hourlyData} color={BRAND} />
        </div>
      </div>

      <div style={box}>
        <h2 style={{ marginTop: 0 }}>Recent Orders</h2>
        {ordersLoading ? (
          <p>Loading…</p>
        ) : orders.length === 0 ? (
          <p>No orders yet.</p>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={th}>Order</th>
                  <th style={th}>Customer</th>
                  <th style={th}>Total</th>
                  <th style={th}>Status</th>
                  <th style={th}>Payment</th>
                </tr>
              </thead>
              <tbody>
                {orders.slice(0, 8).map((o) => (
                  <tr key={o.id}>
                    <td style={td}>{o.order_num}</td>
                    <td style={td}>{o.customer_name}</td>
                    <td style={td}>{formatCurrency(o.total)}</td>
                    <td style={td}><StatusPill status={o.status} /></td>
                    <td style={td}><PaymentStatusPill status={o.payment_status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}

/* ---------------- Orders (with detail + status) ---------------- */

// The admin order-detail fetch (/api/admin/orders/:id) returns the order
// row plus its line items — a narrower shape than the full OrderRow (only
// the fields this row actually displays).
interface OrderDetailData {
  customer_name: string;
  phone: string;
  email?: string | null;
  address: string;
  created_at: string;
  payment_method: string;
  // Present on the real API response (SELECT * FROM orders — see
  // app/api/admin/orders/[id]/route.ts) but declared optional here for the
  // same reason as OrderRow.payment_status in lib/types.ts.
  payment_status?: string;
  notes?: string | null;
  driver_name?: string | null;
  items: OrderItemRow[];
  // Round-2 fixes brief, Part 5 — same optional-for-pre-migration-rows
  // reasoning as OrderRow.order_type; treated as 'delivery' wherever it
  // matters below, same as that column's own DB-level default.
  order_type?: OrderType;
}

function OrderDetailRow({
  token,
  order,
  onOrderUpdated,
}: {
  token: string;
  order: OrderRow;
  // Part C (admin-initiated refunds) — lets this row report a refund
  // result back up to OrdersTab's own `orders` state (same as
  // changeStatus's setOrders call above it), instead of this row keeping
  // its own separate copy that the rest of the table wouldn't see.
  onOrderUpdated: (orderId: number, patch: Partial<OrderRow>) => void;
}) {
  const [detail, setDetail] = useState<OrderDetailData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refunding, setRefunding] = useState(false);
  const [refundAmount, setRefundAmount] = useState('');
  const [refundSubmitting, setRefundSubmitting] = useState(false);
  const [refundError, setRefundError] = useState('');

  useEffect(() => {
    fetch(`/api/admin/orders/${order.id}`)
      .then((r) => r.json())
      .then((d) => setDetail(d as OrderDetailData | null))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [token, order.id]);

  const remaining = refundRemaining(order);

  // Same request/response shape and same "don't trust the admin action,
  // wait for the webhook on a card order" rule as OrderKanban.tsx's
  // submitRefund — see that function's comment for the full reasoning.
  const submitRefund = async (amount?: number) => {
    setRefundSubmitting(true);
    setRefundError('');
    try {
      const res = await fetch(`/api/admin/orders/${order.id}/refund`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(amount ? { amount } : {}),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; paymentStatus?: string };
      if (!res.ok) {
        setRefundError(data.error || 'Refund failed.');
        return;
      }
      if (data.paymentStatus) {
        onOrderUpdated(order.id, { payment_status: data.paymentStatus });
      }
      setRefunding(false);
      setRefundAmount('');
    } catch {
      setRefundError('Refund failed. Please try again.');
    } finally {
      setRefundSubmitting(false);
    }
  };

  return (
    <tr>
      <td colSpan={6} style={{ padding: 16, background: 'var(--bg-alt)', borderTop: '1px solid var(--line)' }}>
        {loading ? (
          <p style={{ margin: 0 }}>Loading details…</p>
        ) : !detail ? (
          <p style={{ margin: 0 }}>Could not load order details.</p>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 18 }}>
            <div>
              <p style={{ margin: '0 0 4px', color: 'var(--muted)', fontSize: 13 }}>Customer</p>
              <p style={{ margin: 0 }}>{detail.customer_name}</p>
              <p style={{ margin: 0 }}>{detail.phone}</p>
              <p style={{ margin: 0, color: detail.email ? undefined : 'var(--muted)' }}>{detail.email || 'No email provided'}</p>
              {/* Round-2 fixes brief, Part 5 — same treatment as
                  OrderKanban.tsx's own detail popup: detail.address is a
                  sentinel string (never a real address) for a pickup
                  order, so it's shown as a clear label instead. This is
                  a second real admin surface showing the same
                  underlying data, so it gets the same fix even though
                  the brief's own text names OrderKanban.tsx specifically. */}
              {detail.order_type === 'pickup' ? (
                <p style={{ margin: 0, fontWeight: 700, color: 'var(--gold)' }}>🏪 Pickup — no delivery</p>
              ) : (
                <p style={{ margin: 0 }}>{detail.address}</p>
              )}
            </div>
            <div>
              <p style={{ margin: '0 0 4px', color: 'var(--muted)', fontSize: 13 }}>Order info</p>
              <p style={{ margin: 0 }}>Placed: {detail.created_at}</p>
              <p style={{ margin: 0, display: 'flex', alignItems: 'center', gap: 8 }}>
                Payment: {detail.payment_method} <PaymentStatusPill status={detail.payment_status} />
              </p>
              {detail.notes && <p style={{ margin: 0 }}>Notes: {detail.notes}</p>}
              {detail.driver_name && <p style={{ margin: 0 }}>🛵 Driver: {detail.driver_name}</p>}
              <p style={{ margin: '10px 0 0', display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <a
                  href={`/admin/orders/${order.id}/invoice`}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ ...btn, display: 'inline-block', textDecoration: 'none' }}
                >
                  View invoice ↗
                </a>
                {isRefundEligible(order) && !refunding && (
                  <button type="button" style={btn} onClick={() => { setRefunding(true); setRefundError(''); }}>
                    Refund
                  </button>
                )}
              </p>
              {refunding && (
                <div style={{ marginTop: 10, padding: 12, background: 'var(--bg)', border: '1px solid var(--line)', borderRadius: 8, maxWidth: 340 }}>
                  <p style={{ margin: '0 0 8px', fontSize: 13, color: 'var(--muted)' }}>
                    {order.payment_method === 'card'
                      ? `Refunds through Stripe. Up to ${formatCurrency(remaining)} can still be refunded — the payment status here updates once Stripe confirms it.`
                      : `Marks up to ${formatCurrency(remaining)} as refunded. No Stripe charge exists for a cash-on-delivery order, so nothing is actually processed — this is a record-keeping marker only.`}
                  </p>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                    <button type="button" style={btnPrimary} disabled={refundSubmitting} onClick={() => submitRefund(undefined)}>
                      {refundSubmitting ? 'Processing…' : `Full refund (${formatCurrency(remaining)})`}
                    </button>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <input
                      type="number"
                      min="0.01"
                      max={remaining}
                      step="0.01"
                      placeholder={`Up to ${remaining.toFixed(2)}`}
                      value={refundAmount}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => setRefundAmount(e.target.value)}
                      style={{ ...inputStyle, marginTop: 0, width: 130 }}
                    />
                    <button
                      type="button"
                      style={btn}
                      disabled={refundSubmitting || !refundAmount || Number(refundAmount) <= 0 || Number(refundAmount) > remaining}
                      onClick={() => submitRefund(Number(refundAmount))}
                    >
                      Refund amount
                    </button>
                  </div>
                  {refundError && <p style={{ margin: '8px 0 0', color: 'var(--danger)', fontSize: 13 }}>{refundError}</p>}
                  <button
                    type="button"
                    disabled={refundSubmitting}
                    onClick={() => { setRefunding(false); setRefundError(''); }}
                    style={{ marginTop: 8, background: 'none', border: 'none', color: 'var(--muted)', textDecoration: 'underline', fontSize: 13, cursor: 'pointer', padding: 0 }}
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <p style={{ margin: '0 0 4px', color: 'var(--muted)', fontSize: 13 }}>Items</p>
              {(detail.items || []).map((item) => (
                <div key={item.id} style={{ padding: '8px 0', borderBottom: '1px solid var(--line)' }}>
                  <strong>{item.qty}× {item.name}</strong> — {formatCurrency(item.line_total)}
                  {item.details && (() => {
                    try {
                      const d = JSON.parse(item.details);
                      return d.length ? <div style={{ color: 'var(--muted)', fontSize: 13 }}>{d.join(', ')}</div> : null;
                    } catch {
                      return null;
                    }
                  })()}
                </div>
              ))}
            </div>
          </div>
        )}
      </td>
    </tr>
  );
}

function OrdersTab({ token }: { token: string }) {
  const { orders, setOrders, loading, reload } = useOrders(token);
  const [updatingId, setUpdatingId] = useState<number | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [view, setView] = useState<'board' | 'list'>('board');

  const changeStatus = async (order: OrderRow, status: OrderStatus) => {
    setUpdatingId(order.id);
    try {
      await fetch(`/api/admin/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, status } : o)));
    } finally {
      setUpdatingId(null);
    }
  };

  const visibleOrders = statusFilter === 'all' ? orders : orders.filter((o) => o.status === statusFilter);

  if (view === 'board') {
    return (
      <div style={box}>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
          <a
            href="/admin/kitchen"
            target="_blank"
            rel="noopener noreferrer"
            style={{ ...btnPrimary, textDecoration: 'none', display: 'inline-block' }}
          >
            Open Kitchen Display ↗
          </a>
          <button type="button" style={btn} onClick={() => setView('list')}>Switch to list view</button>
        </div>
        <OrderKanban token={token} />
      </div>
    );
  }

  return (
    <div style={box}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ margin: 0 }}>Orders</h2>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button type="button" style={btn} onClick={() => setView('board')}>Switch to board view</button>
          <select value={statusFilter} onChange={(e: ChangeEvent<HTMLSelectElement>) => setStatusFilter(e.target.value as OrderStatus | 'all')} style={{ ...inputStyle, width: 'auto', marginTop: 0, padding: '8px 10px' }}>
            <option value="all">All statuses</option>
            {ORDER_STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
          </select>
          <button type="button" style={btn} onClick={reload}>Refresh</button>
        </div>
      </div>
      {loading ? (
        <p>Loading orders...</p>
      ) : visibleOrders.length === 0 ? (
        <p>No orders {statusFilter === 'all' ? 'yet' : `with status "${STATUS_LABELS[statusFilter]}"`}.</p>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Order</th>
                <th style={th}>Customer</th>
                <th style={th}>Total</th>
                <th style={th}>Status</th>
                <th style={th}>Payment</th>
                <th style={th}></th>
              </tr>
            </thead>
            <tbody>
              {visibleOrders.map((order) => (
                <React.Fragment key={order.id}>
                  <tr>
                    <td style={td}>{order.order_num}</td>
                    <td style={td}>{order.customer_name}</td>
                    <td style={td}>{formatCurrency(order.total)}</td>
                    <td style={td}>
                      <select
                        value={order.status}
                        disabled={updatingId === order.id}
                        onChange={(e: ChangeEvent<HTMLSelectElement>) => changeStatus(order, e.target.value as OrderStatus)}
                        style={{ ...inputStyle, width: 'auto', padding: '6px 8px', marginTop: 0 }}
                      >
                        {ORDER_STATUSES.map((s) => (
                          <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                        ))}
                      </select>
                    </td>
                    <td style={td}><PaymentStatusPill status={order.payment_status} /></td>
                    <td style={td}>
                      <button type="button" style={btn} onClick={() => setExpandedId(expandedId === order.id ? null : order.id)}>
                        {expandedId === order.id ? 'Hide' : 'Details'}
                      </button>
                    </td>
                  </tr>
                  {expandedId === order.id && (
                    <OrderDetailRow
                      token={token}
                      order={order}
                      onOrderUpdated={(orderId, patch) => setOrders((list) => list.map((o) => (o.id === orderId ? { ...o, ...patch } : o)))}
                    />
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------- Customers (derived from orders) ---------------- */

// Derived, client-computed shape (grouped/aggregated from OrderRow) — not
// a DB row, and unrelated to lib/types.ts's checkout-flow `Customer`
// shape, so kept as its own page-local interface with a distinct name.
interface CustomerSummary {
  name: string;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
  totalOrders: number;
  totalSpent: number;
  lastOrder: string;
}

// Growth features (Feature 3 — stamp card / loyalty) admin view. Grouped
// by the SAME last-6-digits tolerance phoneMatches() (lib/api-helpers.ts)
// uses everywhere else phone lookups happen in this codebase — including
// the stamp-card counting itself (app/api/orders/route.ts) — so what the
// business owner sees here lines up with what actually triggers a
// reward, unlike the table above (which groups by email-or-phone-or-name,
// so the same phone under two different emails would appear as separate
// rows and under-count for loyalty purposes).
interface PhoneLoyaltySummary {
  phone: string;
  totalOrders: number;
  nonCancelledOrders: number;
  lastOrder: string;
}

function groupOrdersByPhone(orders: OrderRow[]): PhoneLoyaltySummary[] {
  const groups: PhoneLoyaltySummary[] = [];
  orders.forEach((o) => {
    const digits = String(o.phone || '').replace(/\D/g, '');
    const key = digits.slice(-6);
    if (!key) return;
    let group = groups.find((g) => g.phone.replace(/\D/g, '').slice(-6) === key);
    if (!group) {
      group = { phone: o.phone, totalOrders: 0, nonCancelledOrders: 0, lastOrder: o.created_at };
      groups.push(group);
    }
    group.totalOrders += 1;
    if (o.status !== 'cancelled') group.nonCancelledOrders += 1;
    if (o.created_at > group.lastOrder) group.lastOrder = o.created_at;
  });
  return groups.sort((a, b) => b.nonCancelledOrders - a.nonCancelledOrders);
}

function LoyaltyByPhoneBox({
  orders,
  everyN,
  onNavigateToRewards,
}: {
  orders: OrderRow[];
  everyN: number;
  onNavigateToRewards?: () => void;
}) {
  const groups = useMemo(() => groupOrdersByPhone(orders), [orders]);

  return (
    <div style={{ ...box, marginBottom: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12, flexWrap: 'wrap' }}>
        <h3 style={{ marginTop: 0, marginBottom: 4 }}>Orders by phone (loyalty progress)</h3>
        {onNavigateToRewards && (
          <button type="button" style={{ ...btn, marginRight: 0 }} onClick={onNavigateToRewards}>
            🎁 Manage in Rewards →
          </button>
        )}
      </div>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0, marginBottom: 12 }}>
        Non-cancelled orders per phone number — every {everyN}{everyN === 1 ? 'st' : everyN === 2 ? 'nd' : everyN === 3 ? 'rd' : 'th'} one earns a stamp-card reward
        (see the Rewards tab&apos;s Stamp Card card to set the threshold and reward %).
      </p>
      {groups.length === 0 ? (
        <p>No orders yet.</p>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Phone</th>
                <th style={th}>Non-cancelled orders</th>
                <th style={th}>Total orders (incl. cancelled)</th>
                <th style={th}>Progress to next reward</th>
                <th style={th}>Last order</th>
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => {
                const remaining = (everyN - (g.nonCancelledOrders % everyN)) % everyN;
                return (
                  <tr key={g.phone}>
                    <td style={td}>{g.phone}</td>
                    <td style={td}>{g.nonCancelledOrders}</td>
                    <td style={td}>{g.totalOrders}</td>
                    <td style={td}>{remaining === 0 ? 'Reward earned this order' : `${remaining} more to go`}</td>
                    <td style={td}>{g.lastOrder}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function CustomersTab({ token, onNavigateToRewards }: { token: string; onNavigateToRewards?: () => void }) {
  const { orders, loading } = useOrders(token);
  // Read-only here — just needs the current threshold to show accurate
  // progress; editing it happens in the Rewards tab (see RewardSettingsForm).
  const { values: settingsValues } = useSettingsValues(token);
  const stampEveryN = Math.max(1, Math.floor(Number(settingsValues.stamp_card_every_n_orders) || 5));

  const customers = useMemo(() => {
    const byEmail: Record<string, CustomerSummary> = {};
    orders.forEach((o) => {
      const key = o.email || o.phone || o.customer_name;
      if (!byEmail[key]) {
        byEmail[key] = {
          name: o.customer_name,
          email: o.email,
          phone: o.phone,
          address: o.address,
          totalOrders: 0,
          totalSpent: 0,
          lastOrder: o.created_at,
        };
      }
      byEmail[key].totalOrders += 1;
      byEmail[key].totalSpent += Number(o.total || 0);
      if (o.created_at > byEmail[key].lastOrder) byEmail[key].lastOrder = o.created_at;
    });
    return Object.values(byEmail).sort((a, b) => b.totalSpent - a.totalSpent);
  }, [orders]);

  return (
    <div>
      {!loading && <LoyaltyByPhoneBox orders={orders} everyN={stampEveryN} onNavigateToRewards={onNavigateToRewards} />}
      <div style={box}>
      <h2 style={{ marginTop: 0 }}>Customers</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: -8 }}>Derived from order history — not a separate customer database.</p>
      {loading ? (
        <p>Loading…</p>
      ) : customers.length === 0 ? (
        <p>No customers yet.</p>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Name</th>
                <th style={th}>Phone</th>
                <th style={th}>Email</th>
                <th style={th}>Orders</th>
                <th style={th}>Total spent</th>
                <th style={th}>Last order</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c, i) => (
                <tr key={i}>
                  <td style={td}>{c.name}</td>
                  <td style={td}>{c.phone}</td>
                  <td style={td}>{c.email || '—'}</td>
                  <td style={td}>{c.totalOrders}</td>
                  <td style={td}>{formatCurrency(c.totalSpent)}</td>
                  <td style={td}>{c.lastOrder}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      </div>
    </div>
  );
}

/* ---------------- Reports (KPI comparisons + table view) ---------------- */

function ReportsTab({ analytics, loading }: { analytics: AnalyticsData | null; loading: boolean }) {
  if (loading || !analytics) return <p>Loading…</p>;

  const { summary, bestSellers, todayBestSellers = [], todayStatusBreakdown = [], categoryBreakdown, statusBreakdown } = analytics;
  const totalCategoryRevenue = categoryBreakdown.reduce((s, c) => s + c.revenue, 0) || 1;
  const totalStatusCount = statusBreakdown.reduce((s, st) => s + st.count, 0) || 1;

  const weekDelta = percentChange(summary.last7Days.revenue, summary.prev7Days.revenue);
  const monthDelta = percentChange(summary.last30Days.revenue, summary.prev30Days.revenue);

  const todayDelivered = todayStatusBreakdown.find((s) => s.status === 'delivered')?.count || 0;
  const todayCancelled = todayStatusBreakdown.find((s) => s.status === 'cancelled')?.count || 0;
  // Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 —
  // 'accepted'/'ready' are new in-progress statuses too (see
  // lib/types.ts's OrderStatus) — included so an order sitting in either
  // one isn't dropped from today's "in progress" count.
  const todayInProgress = todayStatusBreakdown
    .filter((s) => ['received', 'accepted', 'preparing', 'ready', 'on_the_way'].includes(s.status))
    .reduce((sum, s) => sum + s.count, 0);

  return (
    <>
      <div style={{ ...card, marginBottom: 20, border: `1px solid ${BRAND}` }}>
        <h2 style={cardTitle}>📋 Today&apos;s Closing Summary</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 16, marginBottom: 18 }}>
          <StatTile label="Today's Revenue" value={formatCurrency(summary.today.revenue)} accent={BRAND} />
          <StatTile label="Today's Orders" value={formatNumber(summary.today.orders)} />
          <StatTile label="Delivered" value={formatNumber(todayDelivered)} />
          <StatTile label="Still in progress" value={formatNumber(todayInProgress)} />
          <StatTile label="Cancelled" value={formatNumber(todayCancelled)} goodDirection="down" />
        </div>
        <h3 style={{ margin: '0 0 8px', fontSize: 14, color: 'var(--muted)' }}>Today&apos;s best sellers</h3>
        {todayBestSellers.length === 0 ? (
          <p style={{ color: 'var(--muted)', fontSize: 14 }}>No sales yet today.</p>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Item</th>
                <th style={th}>Qty sold</th>
                <th style={th}>Revenue</th>
              </tr>
            </thead>
            <tbody>
              {todayBestSellers.map((p) => (
                <tr key={p.name}>
                  <td style={td}>{p.name}</td>
                  <td style={td}>{formatNumber(p.qty)}</td>
                  <td style={td}>{formatCurrency(p.revenue)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 20 }}>
        <StatTile label="Sales, Last 7 Days" value={formatCurrency(summary.last7Days.revenue)} delta={weekDelta} deltaLabel="vs the 7 days before" accent={BRAND} />
        <StatTile label="Sales, Last 30 Days" value={formatCurrency(summary.last30Days.revenue)} delta={monthDelta} deltaLabel="vs the 30 days before" accent={GOLD} />
        <StatTile label="All-Time Revenue" value={formatCurrency(summary.totalRevenue)} sublabel={`${formatNumber(summary.totalOrders)} orders`} />
        <StatTile label="Average Order Value" value={formatCurrency(summary.avgOrderValue)} sublabel="all-time" />
        <StatTile label="Cancelled Orders" value={formatNumber(summary.cancelledOrders)} sublabel="all-time" goodDirection="down" />
      </section>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 20 }}>
        <div style={card}>
          <h2 style={cardTitle}>Best sellers — table view</h2>
          {bestSellers.length === 0 ? (
            <p style={{ color: 'var(--muted)' }}>No items sold yet.</p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={th}>Item</th>
                  <th style={th}>Qty sold</th>
                  <th style={th}>Revenue</th>
                </tr>
              </thead>
              <tbody>
                {bestSellers.map((p) => (
                  <tr key={p.name}>
                    <td style={td}>{p.name}</td>
                    <td style={td}>{formatNumber(p.qty)}</td>
                    <td style={td}>{formatCurrency(p.revenue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div style={card}>
          <h2 style={cardTitle}>Revenue by category — table view</h2>
          {categoryBreakdown.length === 0 ? (
            <p style={{ color: 'var(--muted)' }}>No sales yet.</p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={th}>Category</th>
                  <th style={th}>Revenue</th>
                  <th style={th}>Share</th>
                </tr>
              </thead>
              <tbody>
                {categoryBreakdown.map((c) => (
                  <tr key={c.category}>
                    <td style={td}>{c.category}</td>
                    <td style={td}>{formatCurrency(c.revenue)}</td>
                    <td style={td}>{((c.revenue / totalCategoryRevenue) * 100).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div style={card}>
          <h2 style={cardTitle}>Order status — last 30 days</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Status</th>
                <th style={th}>Orders</th>
                <th style={th}>Share</th>
              </tr>
            </thead>
            <tbody>
              {ORDER_STATUSES.map((s) => {
                const row = statusBreakdown.find((st) => st.status === s);
                const count = row ? row.count : 0;
                return (
                  <tr key={s}>
                    <td style={td}><StatusPill status={s} /></td>
                    <td style={td}>{formatNumber(count)}</td>
                    <td style={td}>{((count / totalStatusCount) * 100).toFixed(1)}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ---------------- Settings ---------------- */

interface SettingsField {
  key: string;
  label: string;
  number?: boolean;
  textarea?: boolean;
  // Overrides the default '0.1' step for a `number` field — every
  // pre-existing field here is a euro amount, where 0.1 is the right
  // granularity, but map coordinates (Part 7) need much finer precision
  // than that. Without this, a browser's native number-input step
  // validation would flag e.g. "60.192059" as invalid and silently block
  // the Save button (a real <button type="submit"> in a plain <form>
  // with no noValidate) rather than saving it.
  step?: string;
}

const SETTINGS_FIELDS: SettingsField[] = [
  { key: 'restaurant_name', label: 'Restaurant name' },
  { key: 'phone', label: 'Phone' },
  { key: 'email', label: 'Email' },
  { key: 'address', label: 'Address' },
  { key: 'minimum_order', label: 'Minimum order (€)', number: true },
  { key: 'delivery_fee', label: 'Delivery fee (€)', number: true },
  // Checkout-improvements brief, item 13 — a plain, admin-set estimate
  // shown to the customer during checkout ("~35 minutes to your area" /
  // "~20 min until ready for pickup" — see context/StoreContext.tsx's
  // deliverySettings and components/CheckoutModal.tsx). Deliberately NOT
  // a real-time/distance-based estimate, which would need a new paid
  // routing/maps API call — this reuses the same simple, already-
  // configured-settings pattern as minimum_order/delivery_fee above, at
  // no extra cost. Left blank (0), the checkout screen simply shows no
  // estimate rather than a guessed number.
  { key: 'estimated_delivery_minutes', label: 'Estimated delivery time (minutes)', number: true, step: '1' },
  { key: 'estimated_pickup_minutes', label: 'Estimated pickup time (minutes)', number: true, step: '1' },
  // Audit-fixes brief, Part 7 — optional map coordinates, used only to
  // add a `geo` block to the Restaurant structured data (see
  // app/(site)/[locale]/layout.tsx's getRestaurantSchema). Both blank by
  // default; leaving either one empty simply omits `geo` entirely rather
  // than guessing a location.
  { key: 'geo_lat', label: 'Map latitude (optional, for search engines)', number: true, step: 'any' },
  { key: 'geo_lng', label: 'Map longitude (optional, for search engines)', number: true, step: 'any' },
];

// Phase 7.7 — per-day opening hours, replacing the old single free-text
// `opening_hours` field. Same settings key, new value shape: a JSON array
// of 7 {day, open, close, closed} objects instead of a free-text string —
// see this change's summary for why the same key was reused and what
// reads it (nothing did publicly before this — components/Visit.js was
// hardcoded placeholder content; it's now wired to this).
const OPENING_HOURS_DAYS: { key: string; label: string }[] = [
  { key: 'mon', label: 'Monday' },
  { key: 'tue', label: 'Tuesday' },
  { key: 'wed', label: 'Wednesday' },
  { key: 'thu', label: 'Thursday' },
  { key: 'fri', label: 'Friday' },
  { key: 'sat', label: 'Saturday' },
  { key: 'sun', label: 'Sunday' },
];

function defaultOpeningHours(): OpeningHoursDay[] {
  return OPENING_HOURS_DAYS.map((d) => ({ day: d.key, open: '11:00', close: '22:00', closed: false }));
}

// Returns a valid 7-day array, or null if `raw` is empty/missing, or is
// the OLD free-text value from before this change (plain JSON.parse
// failure — that old value can't be auto-converted into structured
// open/close times, so the admin form falls back to defaults and the
// person re-enters their real hours once, rather than the page crashing
// on an unparseable settings value).
function parseOpeningHours(raw: string | undefined | null): OpeningHoursDay[] | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length === OPENING_HOURS_DAYS.length) return parsed;
  } catch {
    // Old free-text value, or corrupt — treated the same as "unset".
  }
  return null;
}

// Priority-fixes brief (roadmap gap analysis), Part 7 — special/holiday
// hours editor (admin_settings.special_hours). Mirrors parseOpeningHours'
// own "corrupt/unset -> empty" fallback — see lib/openingHours.ts's
// parseSpecialHours for the read-side counterpart the storefront
// actually uses (this admin-side copy exists only so a malformed stored
// value renders an empty editable list instead of crashing the settings
// page; kept deliberately simple/local rather than importing the
// storefront's own parser, since this one doesn't need its stricter
// silent-drop-per-entry behavior — any admin-authored entry here is
// about to be edited and re-saved anyway).
function parseSpecialHoursAdmin(raw: string | undefined | null): SpecialHoursEntry[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

// Bundle 1 Task 5 — story banner slider editor
// (admin_settings.story_banner_images). Same "corrupt/unset -> empty
// list, never crash" fallback as parseSpecialHoursAdmin above — see
// lib/menu-i18n.ts's parseStoryBannerImages for the read-side counterpart
// the storefront actually renders from (kept as its own simple local
// copy here for the same reason parseSpecialHoursAdmin is: this one is
// about to be edited and re-saved, not rendered as-is).
function parseStoryBannerImagesAdmin(raw: string | undefined | null): StoryBannerImage[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item) => ({
      url: typeof item?.url === 'string' ? item.url : '',
      alt: typeof item?.alt === 'string' ? item.alt : '',
    }));
  } catch {
    return [];
  }
}

// Shared by all three settings sections below — each one loads the full
// settings object (cheap: it's one small key/value table) but only ever
// PUTs back the handful of keys it actually owns, so the three sections
// can never clobber each other's data.
function useSettingsValues(token: string) {
  const [values, setValues] = useState<RawSettings>({});
  const [loading, setLoading] = useState(true);
  // Additive — existing callers that destructure only { values, setValues,
  // loading } are unaffected. Added so a caller that used to render nothing
  // at all on failure (return null while loading, forever, on a request
  // that never settles or a non-OK response) can instead show a visible
  // "why" — added while diagnosing a report of the (now-retired)
  // PricingRulesBox silently never appearing; RewardSettingsForm below
  // still relies on the same visible-error behavior.
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    fetch('/api/admin/settings')
      .then((r) => {
        // Previously any non-OK response (401/403/500) still had its JSON
        // body parsed and handed to setValues() as if it were real settings
        // (e.g. a 403's `{ error: "..." }` became the entire `values`
        // object) — silently wrong rather than surfaced. Now it's a
        // rejection, so it lands in .catch() below and sets `error` instead.
        if (!r.ok) throw new Error(`Settings request failed (HTTP ${r.status})`);
        return r.json();
      })
      // r.json() resolves to `unknown` under real @types/node fetch typings;
      // cast to RawSettings (the shape the settings API always returns) so
      // this is assignable to setValues' state type — same fallback-to-{}
      // behavior as before.
      .then((d) => setValues((d as RawSettings) || {}))
      .catch(() => setError('Could not load settings.'))
      .finally(() => setLoading(false));
  }, [token]);

  return { values, setValues, loading, error };
}

function SettingsTab({ token }: { token: string }) {
  return <RestaurantInfoSettings token={token} />;
}

/* ---------------- Settings: Restaurant Info ---------------- */

function RestaurantInfoSettings({ token }: { token: string }) {
  const { values, setValues, loading } = useSettingsValues(token);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [hours, setHours] = useState<OpeningHoursDay[]>(defaultOpeningHours());
  const [hoursWasFreeText, setHoursWasFreeText] = useState(false);
  const hoursInitialized = useRef(false);
  // Priority-fixes brief (roadmap gap analysis), Part 7 — special/
  // holiday hours, initialized the same once-on-load way as `hours`
  // above (see the effect below).
  const [specialHours, setSpecialHours] = useState<SpecialHoursEntry[]>([]);
  const specialHoursInitialized = useRef(false);

  // Initialize the structured-hours editor once, the first time settings
  // finish loading — not on every `values` change, or typing in any other
  // Restaurant Settings field would keep resetting whatever the person
  // just edited here.
  useEffect(() => {
    if (loading || hoursInitialized.current) return;
    hoursInitialized.current = true;
    const parsed = parseOpeningHours(values.opening_hours);
    if (parsed) {
      setHours(parsed);
    } else {
      setHours(defaultOpeningHours());
      // Distinguish "never set anything" from "there's an old free-text
      // value that couldn't convert" — only the second case needs a note,
      // so the person knows their old hours text didn't just vanish
      // silently, it needs re-entering in the new day-by-day form.
      setHoursWasFreeText(!!values.opening_hours);
    }
  }, [loading, values.opening_hours]);

  useEffect(() => {
    if (loading || specialHoursInitialized.current) return;
    specialHoursInitialized.current = true;
    setSpecialHours(parseSpecialHoursAdmin(values.special_hours));
  }, [loading, values.special_hours]);

  const setField = (key: string, val: string) => {
    setValues((v) => ({ ...v, [key]: val }));
    setSaved(false);
  };

  const setDay = (dayKey: string, patch: Partial<OpeningHoursDay>) => {
    setHours((h) => h.map((d) => (d.day === dayKey ? { ...d, ...patch } : d)));
    setSaved(false);
  };

  // Priority-fixes brief (roadmap gap analysis), Part 7.
  const addSpecialHoursRow = () => {
    setSpecialHours((rows) => [...rows, { date: '', closed: true, open: '11:00', close: '22:00' }]);
    setSaved(false);
  };
  const updateSpecialHoursRow = (index: number, patch: Partial<SpecialHoursEntry>) => {
    setSpecialHours((rows) => rows.map((r, i) => (i === index ? { ...r, ...patch } : r)));
    setSaved(false);
  };
  const removeSpecialHoursRow = (index: number) => {
    setSpecialHours((rows) => rows.filter((_, i) => i !== index));
    setSaved(false);
  };

  const isClosed = values.store_closed === '1';

  const toggleStoreClosed = async () => {
    const next = isClosed ? '0' : '1';
    setField('store_closed', next);
    await fetch('/api/admin/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ store_closed: next }),
    });
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const body: Record<string, string> = {};
      SETTINGS_FIELDS.forEach((f) => { body[f.key] = values[f.key] || ''; });
      body.opening_hours = JSON.stringify(hours);
      // Priority-fixes brief (roadmap gap analysis), Part 7 — drop any
      // row the admin left with a blank date (e.g. clicked "+ Add" and
      // then changed their mind) rather than saving an unusable entry
      // that could never match a real calendar date.
      body.special_hours = JSON.stringify(specialHours.filter((r) => r.date));
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setHoursWasFreeText(false);
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p>Loading…</p>;

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Restaurant Settings</h2>

      <div
        style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12,
          padding: 16, marginBottom: 24, borderRadius: 10,
          background: isClosed ? 'var(--danger-bg)' : 'var(--bg-alt)',
          border: `1px solid ${isClosed ? 'var(--danger-border)' : 'var(--line)'}`,
        }}
      >
        <div>
          <strong style={{ color: isClosed ? 'var(--danger)' : 'var(--cream)' }}>
            {isClosed ? '🔴 Store is closed — not taking orders' : '🟢 Store is open — taking orders normally'}
          </strong>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: 'var(--muted)' }}>
            For emergencies (kitchen issue, fully booked, closing early). Takes effect immediately.
          </p>
        </div>
        <button
          type="button"
          onClick={toggleStoreClosed}
          style={isClosed ? btnPrimary : btnDanger}
        >
          {isClosed ? 'Reopen store' : 'Close store now'}
        </button>
      </div>

      <form onSubmit={save}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14 }}>
          {SETTINGS_FIELDS.map((f) => (
            <label key={f.key} style={f.textarea ? { gridColumn: '1 / -1' } : undefined}>
              {f.label}
              {f.textarea ? (
                <textarea
                  style={{ ...inputStyle, minHeight: 70 }}
                  value={values[f.key] || ''}
                  onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setField(f.key, e.target.value)}
                />
              ) : (
                <input
                  style={inputStyle}
                  type={f.number ? 'number' : 'text'}
                  step={f.number ? (f.step || '0.1') : undefined}
                  value={values[f.key] || ''}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setField(f.key, e.target.value)}
                />
              )}
            </label>
          ))}
        </div>

        <h3 style={{ margin: '24px 0 4px', fontSize: 15 }}>Opening hours</h3>
        {hoursWasFreeText && (
          <p style={{ margin: '0 0 12px', fontSize: 12.5, color: 'var(--gold)' }}>
            Your previous opening-hours text couldn't be converted automatically — filled in with placeholder times below, please set each day correctly and save.
          </p>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {OPENING_HOURS_DAYS.map((d) => {
            const row = hours.find((h) => h.day === d.key) || { open: '11:00', close: '22:00', closed: false };
            return (
              <div key={d.key} style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                <span style={{ width: 96, fontSize: 13.5 }}>{d.label}</span>
                <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--muted)' }}>
                  <input
                    type="checkbox"
                    checked={row.closed}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => setDay(d.key, { closed: e.target.checked })}
                  />
                  Closed all day
                </label>
                {!row.closed && (
                  <>
                    <input
                      type="time"
                      value={row.open}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => setDay(d.key, { open: e.target.value })}
                      style={{ ...inputStyle, width: 'auto', marginTop: 0 }}
                    />
                    <span style={{ color: 'var(--muted)' }}>–</span>
                    <input
                      type="time"
                      value={row.close}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => setDay(d.key, { close: e.target.value })}
                      style={{ ...inputStyle, width: 'auto', marginTop: 0 }}
                    />
                  </>
                )}
              </div>
            );
          })}
        </div>

        <h3 style={{ margin: '24px 0 4px', fontSize: 15 }}>Special / holiday hours</h3>
        <p style={{ margin: '0 0 12px', fontSize: 12.5, color: 'var(--muted)' }}>
          Overrides the regular weekly hours above for one specific date — a public holiday, a one-off early
          closing, etc. Checked before the weekly schedule wherever the site shows the live open/closed badge and
          next opening/closing time (the homepage). Leave a date&apos;s row out entirely on a normal week.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {specialHours.map((row, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <input
                type="date"
                value={row.date}
                onChange={(e: ChangeEvent<HTMLInputElement>) => updateSpecialHoursRow(i, { date: e.target.value })}
                style={{ ...inputStyle, width: 'auto', marginTop: 0 }}
              />
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--muted)' }}>
                <input
                  type="checkbox"
                  checked={row.closed}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => updateSpecialHoursRow(i, { closed: e.target.checked })}
                />
                Closed all day
              </label>
              {!row.closed && (
                <>
                  <input
                    type="time"
                    value={row.open || ''}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => updateSpecialHoursRow(i, { open: e.target.value })}
                    style={{ ...inputStyle, width: 'auto', marginTop: 0 }}
                  />
                  <span style={{ color: 'var(--muted)' }}>–</span>
                  <input
                    type="time"
                    value={row.close || ''}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => updateSpecialHoursRow(i, { close: e.target.value })}
                    style={{ ...inputStyle, width: 'auto', marginTop: 0 }}
                  />
                </>
              )}
              <button type="button" style={btnDanger} onClick={() => removeSpecialHoursRow(i)}>Remove</button>
            </div>
          ))}
          {!specialHours.length && <p style={{ margin: 0, fontSize: 13, color: 'var(--muted)' }}>No special dates configured.</p>}
        </div>
        <div style={{ marginTop: 10 }}>
          <button type="button" style={btn} onClick={addSpecialHoursRow}>+ Add a date</button>
        </div>

        <div style={{ marginTop: 16 }}>
          <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Saving…' : 'Save settings'}</button>
          {saved && <span style={{ marginLeft: 12, color: 'var(--gold)' }}>Saved ✓</span>}
        </div>
      </form>
      <p style={{ marginTop: 16, color: 'var(--muted)', fontSize: 13 }}>
        Note: the login email/password are separate Cloudflare secrets and aren&apos;t changed here.
      </p>
    </div>
  );
}

/* ---------------- Settings: Homepage Display (featured card + popular products) ---------------- */

function HomepageDisplaySettings({ token }: { token: string }) {
  const { values, setValues, loading } = useSettingsValues(token);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [products, setProducts] = useState<RawProduct[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  // Bundle 1 Task 5 — story banner slider. Initialized once (same
  // once-on-load pattern as RestaurantInfoSettings' `hours`/
  // `specialHours` above) so typing elsewhere in this form doesn't keep
  // resetting whatever the admin is mid-edit on here.
  const [storyImages, setStoryImages] = useState<StoryBannerImage[]>([]);
  const storyImagesInitialized = useRef(false);
  const [storyUploading, setStoryUploading] = useState(false);
  const [storyUploadError, setStoryUploadError] = useState('');

  const MAX_STORY_IMAGES = 10;

  useEffect(() => {
    fetch('/api/admin/products')
      .then((r) => r.json())
      .then((d) => setProducts(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, [token]);

  useEffect(() => {
    if (loading || storyImagesInitialized.current) return;
    storyImagesInitialized.current = true;
    setStoryImages(parseStoryBannerImagesAdmin(values.story_banner_images));
  }, [loading, values.story_banner_images]);

  const setField = (key: string, val: string) => {
    setValues((v) => ({ ...v, [key]: val }));
    setSaved(false);
  };

  // Bundle 1 Task 5 — same nameHint pattern as uploadBannerImage below
  // (and ResourceManager.tsx/BundleManager.tsx before it), so these
  // photos get a real, SEO-meaningful storage key/URL instead of a
  // camera-roll filename.
  const uploadStoryImage = async (file: File) => {
    if (storyImages.length >= MAX_STORY_IMAGES) return;
    setStoryUploading(true);
    setStoryUploadError('');
    try {
      const body = new FormData();
      body.append('file', file, file.name || 'upload.jpg');
      body.append('nameHint', 'ozy-fi-story-banner');
      const res = await fetch('/api/admin/upload', { method: 'POST', body });
      const data = (await res.json().catch(() => ({}))) as { error?: string; url?: string };
      if (!res.ok) throw new Error(data.error || 'Upload failed.');
      setStoryImages((imgs) => [...imgs, { url: data.url || '', alt: '' }]);
      setSaved(false);
    } catch (err: any) {
      setStoryUploadError(err.message || 'Upload failed.');
    } finally {
      setStoryUploading(false);
    }
  };

  const removeStoryImage = (index: number) => {
    setStoryImages((imgs) => imgs.filter((_, i) => i !== index));
    setSaved(false);
  };

  const setStoryImageAlt = (index: number, alt: string) => {
    setStoryImages((imgs) => imgs.map((img, i) => (i === index ? { ...img, alt } : img)));
    setSaved(false);
  };

  // Up/down move, not drag-and-drop — this admin panel has no existing
  // drag-reorder pattern anywhere (categories/products/bundles reorder
  // via a plain numeric "Sort order" field on each independent DB row,
  // which doesn't map onto a single flat JSON-array setting like this
  // one), and the brief explicitly allows "even a simple up/down or drag
  // pattern" as the fallback when no pattern already exists to match.
  const moveStoryImage = (index: number, direction: -1 | 1) => {
    setStoryImages((imgs) => {
      const target = index + direction;
      if (target < 0 || target >= imgs.length) return imgs;
      const next = imgs.slice();
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
    setSaved(false);
  };

  let popularIds: string[] = [];
  try { popularIds = JSON.parse(values.popular_product_ids || '[]'); } catch { popularIds = []; }

  const togglePopular = (id: string) => {
    const has = popularIds.includes(id);
    let next: string[];
    if (has) {
      next = popularIds.filter((p) => p !== id);
    } else {
      if (popularIds.length >= 3) return; // cap at 3 — matches the homepage grid
      next = [...popularIds, id];
    }
    setField('popular_product_ids', JSON.stringify(next));
  };

  // Same nameHint pattern as ResourceManager.tsx/BundleManager.tsx — the
  // upload route prefers this over the file's own name when building the
  // storage key/URL. The custom banner has no ingredients-like second
  // field (its "Banner price text" isn't description content), so this
  // only ever sends a nameHint, never a descriptionHint.
  const uploadBannerImage = async (file: File, nameHint?: string) => {
    setUploading(true);
    setUploadError('');
    try {
      const body = new FormData();
      body.append('file', file, file.name || 'upload.jpg');
      if (nameHint) body.append('nameHint', nameHint);
      const res = await fetch('/api/admin/upload', {
        method: 'POST', body,
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; url?: string };
      if (!res.ok) throw new Error(data.error || 'Upload failed.');
      setField('featured_banner_image', data.url || '');
    } catch (err: any) {
      setUploadError(err.message || 'Upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const body = {
        featured_type: values.featured_type || 'none',
        featured_product_id: values.featured_product_id || '',
        featured_banner_title: values.featured_banner_title || '',
        featured_banner_price: values.featured_banner_price || '',
        featured_banner_image: values.featured_banner_image || '',
        popular_product_ids: values.popular_product_ids || '[]',
        // Bundle 1 Task 5 — drop any image an admin removed mid-edit
        // (removeStoryImage already keeps this in sync) and any leftover
        // blank alt text stays as an empty string (Story.tsx supplies its
        // own fallback alt when one is blank — see that component).
        story_banner_images: JSON.stringify(storyImages.filter((img) => img.url).slice(0, MAX_STORY_IMAGES)),
      };
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p>Loading…</p>;

  const featuredType = values.featured_type || 'none';

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Homepage Display</h2>

      <form onSubmit={save}>
        <h3 style={{ marginBottom: 4 }}>Homepage featured card</h3>
        <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
          Shown on the homepage, right below the hero. Pick a real product — its
          photo/name/price stay in sync automatically — or a custom banner. (Bundles have
          their own &quot;Combo deals&quot; section further down, so they&apos;re not offered here.)
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14, marginBottom: 24 }}>
          <label>
            Card type
            <select style={inputStyle} value={featuredType} onChange={(e: ChangeEvent<HTMLSelectElement>) => setField('featured_type', e.target.value)}>
              <option value="none">None (hidden)</option>
              <option value="product">Real product</option>
              <option value="banner">Custom banner</option>
            </select>
          </label>

          {featuredType === 'product' && (
            <label>
              Featured product
              <select style={inputStyle} value={values.featured_product_id || ''} onChange={(e: ChangeEvent<HTMLSelectElement>) => setField('featured_product_id', e.target.value)}>
                <option value="">Select…</option>
                {products.map((p) => <option key={p.id} value={p.id}>{p.name} · {formatCurrency(p.price)}</option>)}
              </select>
            </label>
          )}

          {featuredType === 'banner' && (
            <>
              <label>Banner title<input style={inputStyle} value={values.featured_banner_title || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('featured_banner_title', e.target.value)} /></label>
              <label>Banner price text (optional)<input style={inputStyle} value={values.featured_banner_price || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('featured_banner_price', e.target.value)} placeholder="e.g. From €9.90" /></label>
              <label style={{ gridColumn: '1 / -1' }}>
                Banner image
                <input
                  style={inputStyle}
                  value={values.featured_banner_image || ''}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setField('featured_banner_image', e.target.value)}
                  placeholder="Upload below, or paste an image URL"
                />
                <input
                  type="file"
                  accept="image/*"
                  style={{ marginTop: 8, color: 'var(--cream)' }}
                  disabled={uploading}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    const f = e.target.files && e.target.files[0];
                    if (f) uploadBannerImage(f, values.featured_banner_title || '');
                    e.target.value = '';
                  }}
                />
                {uploading && <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 0' }}>Uploading…</p>}
                {uploadError && <p style={{ fontSize: 12, color: 'var(--danger)', margin: '4px 0 0' }}>{uploadError}</p>}
                {values.featured_banner_image && (
                  <img
                    src={values.featured_banner_image}
                    alt="Banner preview"
                    style={{ marginTop: 8, maxWidth: 200, borderRadius: 8, border: '1px solid var(--line)' }}
                  />
                )}
              </label>
            </>
          )}
        </div>

        <h3 style={{ marginBottom: 4 }}>Popular right now</h3>
        <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: -2, marginBottom: 14 }}>
          Shown on the homepage, right below the category shortcuts. Pick up to 3 products.
        </p>
        <div style={{
          display: 'flex', flexWrap: 'wrap', gap: '8px 16px', marginBottom: 24,
          padding: 12, border: '1px solid var(--line)', borderRadius: 8, background: 'var(--bg-alt)',
        }}>
          {products.map((p) => {
            const checked = popularIds.includes(p.id);
            const disabled = !checked && popularIds.length >= 3;
            return (
              <label key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, opacity: disabled ? 0.5 : 1 }}>
                <input type="checkbox" checked={checked} disabled={disabled} onChange={() => togglePopular(p.id)} />
                {p.name}
              </label>
            );
          })}
        </div>

        <h3 style={{ marginBottom: 4 }}>Story banner</h3>
        <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: -2, marginBottom: 14 }}>
          Real photos for the homepage &quot;Our Story&quot; section, shown as an
          auto-advancing slider. Wide (16:9) photos work best — around
          3840×2160 is ideal, but anything close to that ratio will fill the
          banner cleanly. Up to {MAX_STORY_IMAGES} images; add a short,
          descriptive caption for each (used as its alt text). With none
          configured, the section shows a plain on-brand placeholder instead
          — never a stock/random photo.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 14 }}>
          {storyImages.map((img, i) => (
            <div
              key={img.url + i}
              style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: 10,
                border: '1px solid var(--line)', borderRadius: 8, background: 'var(--bg-alt)',
              }}
            >
              <img src={img.url} alt="" style={{ width: 96, height: 54, objectFit: 'cover', borderRadius: 6, flexShrink: 0 }} />
              <input
                style={{ ...inputStyle, flex: 1 }}
                value={img.alt}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setStoryImageAlt(i, e.target.value)}
                placeholder="Caption / alt text (e.g. 'Fresh dough being hand-stretched')"
              />
              <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                <button type="button" style={{ ...btn, padding: '6px 10px', opacity: i === 0 ? 0.4 : 1 }} disabled={i === 0} onClick={() => moveStoryImage(i, -1)} aria-label="Move up">↑</button>
                <button type="button" style={{ ...btn, padding: '6px 10px', opacity: i === storyImages.length - 1 ? 0.4 : 1 }} disabled={i === storyImages.length - 1} onClick={() => moveStoryImage(i, 1)} aria-label="Move down">↓</button>
                <button type="button" style={{ ...btnDanger, padding: '6px 10px' }} onClick={() => removeStoryImage(i)}>Remove</button>
              </div>
            </div>
          ))}
          {!storyImages.length && (
            <p style={{ fontSize: 13, color: 'var(--muted)', margin: 0 }}>No images yet — add up to {MAX_STORY_IMAGES} below.</p>
          )}
        </div>
        <label style={{ display: 'block', marginBottom: 24 }}>
          {storyImages.length < MAX_STORY_IMAGES ? (
            <input
              type="file"
              accept="image/*"
              disabled={storyUploading}
              style={{ color: 'var(--cream)' }}
              onChange={(e: ChangeEvent<HTMLInputElement>) => {
                const f = e.target.files && e.target.files[0];
                if (f) uploadStoryImage(f);
                e.target.value = '';
              }}
            />
          ) : (
            <span style={{ fontSize: 13, color: 'var(--muted)' }}>Maximum of {MAX_STORY_IMAGES} images reached — remove one to add another.</span>
          )}
          {storyUploading && <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 0' }}>Uploading…</p>}
          {storyUploadError && <p style={{ fontSize: 12, color: 'var(--danger)', margin: '4px 0 0' }}>{storyUploadError}</p>}
        </label>

        <div style={{ marginTop: 16 }}>
          <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Saving…' : 'Save settings'}</button>
          {saved && <span style={{ marginLeft: 12, color: 'var(--gold)' }}>Saved ✓</span>}
        </div>
      </form>
    </div>
  );
}

/* ---------------- Settings: Tracking & Analytics ---------------- */

function TrackingAnalyticsSettings({ token }: { token: string }) {
  const { values, setValues, loading } = useSettingsValues(token);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const setField = (key: string, val: string) => {
    setValues((v) => ({ ...v, [key]: val }));
    setSaved(false);
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const keys = [
        'ga4_measurement_id', 'secret_ga4_api_secret', 'ga4_debug_mode',
        'meta_pixel_id', 'secret_meta_access_token', 'meta_test_event_code',
        'tiktok_pixel_id', 'secret_tiktok_access_token', 'tiktok_test_event_code',
        'clarity_id',
      ];
      const body: Record<string, string> = {};
      keys.forEach((k) => { body[k] = values[k] || ''; });
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <p>Loading…</p>;

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Tracking &amp; Analytics</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
        Optional — only fill these in once you&apos;ve created the matching ad/analytics
        accounts. Leaving a field blank means that platform stays completely off; nothing
        fires until its ID (and, for Meta/TikTok, its access token) is set here. Takes
        effect immediately on save — no redeploy needed.
      </p>

      <form onSubmit={save}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14, marginBottom: 12 }}>
          <label>
            GA4 Measurement ID
            <input style={inputStyle} type="text" placeholder="G-XXXXXXXXXX" value={values.ga4_measurement_id || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('ga4_measurement_id', e.target.value)} />
          </label>
          <label>
            GA4 API Secret
            <input style={inputStyle} type="password" placeholder="For server-side purchase/refund events" value={values.secret_ga4_api_secret || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('secret_ga4_api_secret', e.target.value)} />
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 22 }}>
            <input type="checkbox" checked={values.ga4_debug_mode === '1'} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('ga4_debug_mode', e.target.checked ? '1' : '0')} />
            <span>GA4 Debug Mode <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(shows in DebugView, doesn&apos;t count as real data — turn off once verified)</span></span>
          </label>
          <label>
            Meta (Facebook/Instagram) Pixel ID
            <input style={inputStyle} type="text" placeholder="e.g. 123456789012345" value={values.meta_pixel_id || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('meta_pixel_id', e.target.value)} />
          </label>
          <label>
            Meta Conversions API Access Token
            <input style={inputStyle} type="password" value={values.secret_meta_access_token || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('secret_meta_access_token', e.target.value)} />
          </label>
          <label>
            Meta Test Event Code <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(from Events Manager → Test Events — leave blank once verified)</span>
            <input style={inputStyle} type="text" placeholder="e.g. TEST12345" value={values.meta_test_event_code || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('meta_test_event_code', e.target.value)} />
          </label>
          <label>
            TikTok Pixel ID
            <input style={inputStyle} type="text" value={values.tiktok_pixel_id || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('tiktok_pixel_id', e.target.value)} />
          </label>
          <label>
            TikTok Events API Access Token
            <input style={inputStyle} type="password" value={values.secret_tiktok_access_token || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('secret_tiktok_access_token', e.target.value)} />
          </label>
          <label>
            TikTok Test Event Code <span style={{ color: 'var(--muted)', fontWeight: 400 }}>(from TikTok Events Manager — leave blank once verified)</span>
            <input style={inputStyle} type="text" value={values.tiktok_test_event_code || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('tiktok_test_event_code', e.target.value)} />
          </label>
          <label>
            Microsoft Clarity Project ID
            <input style={inputStyle} type="text" placeholder="e.g. abcd1234ef" value={values.clarity_id || ''} onChange={(e: ChangeEvent<HTMLInputElement>) => setField('clarity_id', e.target.value)} />
          </label>
        </div>
        <p style={{ color: 'var(--muted)', fontSize: 12, marginTop: 0 }}>
          🔒 The two Pixel IDs, Measurement ID, and Clarity ID are visible in the site&apos;s
          public data (this is normal — every site&apos;s pixel ID is visible in its own page
          source). The Access Token/API Secret fields are never exposed publicly — they&apos;re
          only used from the server when sending order events.
        </p>
        <div style={{ marginTop: 16 }}>
          <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Saving…' : 'Save settings'}</button>
          {saved && <span style={{ marginLeft: 12, color: 'var(--gold)' }}>Saved ✓</span>}
        </div>
      </form>
    </div>
  );
}


/* ---------------- Menu & Pricing (Categories/Products/Options/Add-ons) ---------------- */

/* ---------------- Options & Toppings — grouped landing page ---------------- */
// Previously this screen just stacked two flat tables (all option groups,
// then every single option from every group mixed together in one long
// list) — confusing once there were more than a couple of groups, since
// Base/Sauce/Cheese/Topping/Dip choices all ran together. This groups
// them the same way Product Management does: pick a group first (as a
// card), then see only that group's choices.
// Maps each option group's `kind` to the exact heading text a customer
// actually sees on the product customization page (components/
// ProductPage.js) — so the admin card for, say, the "toppings" group
// shows the same "Finish — tap to add toppings" wording the customer
// sees, instead of only the internal group name. Base/Sauce/Cheese
// don't have their own on-page heading (they show as a collapsed row
// that just displays whichever choice is currently selected), so those
// three get a short plain description instead of a quoted heading.
const GROUP_KIND_CUSTOMER_VIEW: Record<string, string> = {
  base: 'Shown on the site as: a "Bottom" row — tap to change the crust',
  sauce: 'Shown on the site as: a "Sauce" row — tap to change the sauce',
  cheese: 'Shown on the site as: a "Cheese" row — tap to change the cheese',
  sauce_stripe: 'Shown on the site as: "Finish with sauce stripes"',
  dip: 'Shown on the site as: "Dip the edges"',
  topping: 'Shown on the site as: "Finish — tap to add toppings"',
  filling: 'Shown on the site as: "Fillings"',
  // Pizza-size-feature brief — see optionGroupFields' own 'size' option
  // comment above for the full "global, not per-product" caveat; repeated
  // here in plain language since this hint is what an admin actually sees
  // while managing option groups.
  size: 'Shown on the site as: a "Size" row — tap to change the size (applies to EVERY product with toppings enabled, same as Base/Sauce/Cheese — not per-product)',
};

// Per-product-size brief, Part 2 — `PricingRulesBox` is fully retired.
// It existed solely to edit the single global `size_large_upcharge` value
// behind the old M/L toggle; that toggle and its admin_settings-backed
// upcharge are gone, and the box had no other content, so it's removed
// rather than left empty. Per-product size pricing is now edited directly
// from each product's own edit page (see app/admin/products/[id]/edit/
// page.tsx's Sizes section) instead of a cross-product Settings-style box.

/* ---------------- Rewards (growth-features consolidation) ---------------- */
//
// Every growth/loyalty feature's settings, previously scattered across
// Menu & Pricing's "Pricing rules" box and a couple of hardcoded route
// constants, now live in one dedicated section — see this task's brief.
// Follows the SAME "landing page of cards, click into one to manage just
// that feature" structure MenuTabs/OptionsManager already established
// above, rather than inventing a new layout.

interface RewardSettingFieldDef {
  key: string;
  label: string;
  min?: number;
  max?: number;
  step?: string;
  // Shared discount-value pattern (color-palette-and-discount-pattern
  // brief, part 2 — see lib/types.ts's DiscountValue). When true, `key`
  // is a BASE key and this field actually reads/writes `${key}_type`
  // ('percent'|'amount') + `${key}_value` (number) as a pair, rendered
  // as a type-toggle + number input via DiscountValueInput below,
  // instead of one plain number field.
  discount?: boolean;
}

// Shared discount-value pattern — one small type-toggle ('%' vs '€') +
// number control, reused by every growth feature's discount SETTING
// through RewardSettingsForm/StampCardSettingsForm below.
// components/admin/ScheduledOffersManager.tsx has its own copy of this
// same two-control shape (it isn't built from RewardSettingsForm, since
// scheduled offers have their own bespoke form — see that file), but
// both store to the exact same `${key}_type`/`${key}_value` convention.
function DiscountValueInput({
  label,
  typeValue,
  numberValue,
  onTypeChange,
  onNumberChange,
}: {
  label: string;
  typeValue: string;
  numberValue: string;
  onTypeChange: (v: 'percent' | 'amount') => void;
  onNumberChange: (v: string) => void;
}) {
  const type: 'percent' | 'amount' = typeValue === 'amount' ? 'amount' : 'percent';
  return (
    <label style={{ minWidth: 260 }}>
      {label}
      <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
        <select
          style={{ ...inputStyle, marginTop: 0, width: 84, flexShrink: 0 }}
          value={type}
          onChange={(e: ChangeEvent<HTMLSelectElement>) => onTypeChange(e.target.value as 'percent' | 'amount')}
        >
          <option value="percent">%</option>
          <option value="amount">€</option>
        </select>
        <input
          style={{ ...inputStyle, marginTop: 0 }}
          type="number"
          min={0}
          max={type === 'percent' ? 100 : undefined}
          step={type === 'percent' ? '1' : '0.5'}
          value={numberValue}
          onChange={(e: ChangeEvent<HTMLInputElement>) => onNumberChange(e.target.value)}
        />
      </div>
    </label>
  );
}

// One small reusable form for a handful of admin_settings keys — the
// same useSettingsValues-plus-a-form-that-PUTs-back-only-its-own-keys
// shape the now-retired PricingRulesBox used, just parameterized so each
// Rewards card doesn't need its own hand-copied version of that box. A
// `discount: true` field reads/writes its `_type`/`_value` pair via
// DiscountValueInput instead of a single plain number.
function RewardSettingsForm({
  token,
  title,
  description,
  fields,
}: {
  token: string;
  title: string;
  description?: string;
  fields: RewardSettingFieldDef[];
}) {
  const { values, setValues, loading, error } = useSettingsValues(token);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSaving(true);
    try {
      const body: Record<string, string> = {};
      fields.forEach((f) => {
        if (f.discount) {
          body[`${f.key}_type`] = values[`${f.key}_type`] || 'percent';
          body[`${f.key}_value`] = values[`${f.key}_value`] || '';
        } else {
          body[f.key] = values[f.key] || '';
        }
      });
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div style={{ ...box, padding: 16, color: 'var(--muted)' }}>Loading…</div>;
  }
  if (error) {
    return <div style={{ ...box, padding: 16, color: 'var(--danger)' }}>{error}</div>;
  }

  return (
    <div style={box}>
      <h3 style={{ marginTop: 0, marginBottom: 4 }}>{title}</h3>
      {description && (
        <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0, marginBottom: 16 }}>{description}</p>
      )}
      <form onSubmit={save} style={{ display: 'flex', alignItems: 'flex-end', gap: 12, flexWrap: 'wrap' }}>
        {fields.map((f) => (
          f.discount ? (
            <DiscountValueInput
              key={f.key}
              label={f.label}
              typeValue={values[`${f.key}_type`] || 'percent'}
              numberValue={values[`${f.key}_value`] || ''}
              onTypeChange={(v) => { setValues((vals) => ({ ...vals, [`${f.key}_type`]: v })); setSaved(false); }}
              onNumberChange={(v) => { setValues((vals) => ({ ...vals, [`${f.key}_value`]: v })); setSaved(false); }}
            />
          ) : (
            <label key={f.key} style={{ minWidth: 260 }}>
              {f.label}
              <input
                style={inputStyle}
                type="number"
                step={f.step || '1'}
                min={f.min ?? 0}
                max={f.max}
                value={values[f.key] || ''}
                onChange={(e: ChangeEvent<HTMLInputElement>) => { setValues((v) => ({ ...v, [f.key]: e.target.value })); setSaved(false); }}
              />
            </label>
          )
        ))}
        <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        {saved && <span style={{ color: 'var(--gold)' }}>Saved ✓</span>}
      </form>
    </div>
  );
}

// Stamp-card redesign — same checkbox-list-over-fetched-products pattern
// already established by HomepageDisplaySettings' popular_product_ids
// picker above, reused here (per the brief's own pointer) rather than
// inventing a new multi-select control. A bespoke component (not
// RewardSettingsForm) because RewardSettingsForm's field-list model has
// no concept of a product picker — same reasoning ScheduledOffersManager
// documents for why IT isn't the generic <ResourceManager/> either.
function StampCardSettingsForm({ token }: { token: string }) {
  const { values, setValues, loading, error } = useSettingsValues(token);
  const [products, setProducts] = useState<RawProduct[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch('/api/admin/products')
      .then((r) => r.json())
      .then((d) => setProducts(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, [token]);

  let eligibleIds: string[] = [];
  try {
    const parsed = JSON.parse(values.stamp_card_eligible_product_ids || '[]');
    if (Array.isArray(parsed)) eligibleIds = parsed;
  } catch {
    eligibleIds = [];
  }

  const toggleEligible = (id: string) => {
    const next = eligibleIds.includes(id) ? eligibleIds.filter((p) => p !== id) : [...eligibleIds, id];
    setValues((v) => ({ ...v, stamp_card_eligible_product_ids: JSON.stringify(next) }));
    setSaved(false);
  };

  const setField = (key: string, val: string) => {
    setValues((v) => ({ ...v, [key]: val }));
    setSaved(false);
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stamp_card_eligible_product_ids: values.stamp_card_eligible_product_ids || '[]',
          stamp_card_reward_type: values.stamp_card_reward_type || 'percent',
          stamp_card_reward_value: values.stamp_card_reward_value || '',
          stamp_card_every_n_orders: values.stamp_card_every_n_orders || '',
        }),
      });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div style={{ ...box, padding: 16, color: 'var(--muted)' }}>Loading…</div>;
  }
  if (error) {
    return <div style={{ ...box, padding: 16, color: 'var(--danger)' }}>{error}</div>;
  }

  return (
    <div style={box}>
      <h3 style={{ marginTop: 0, marginBottom: 4 }}>Stamp Card</h3>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0, marginBottom: 16 }}>
        On a customer&apos;s every Nth non-cancelled order, if their cart contains ANY of the eligible
        products below, one unit of the cheapest eligible item in the cart gets this percentage off —
        applied immediately, no code needed. If the cart has none of these products, the reward is held
        (one per phone number at a time) and applied automatically the next time that phone orders an
        eligible item, however many orders later. Never stacks with a coupon, the welcome discount, or a
        scheduled offer — whichever discount is most favorable to the customer wins.
      </p>
      <form onSubmit={save}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 16 }}>
          <DiscountValueInput
            label="Reward — blank/0 disables it"
            typeValue={values.stamp_card_reward_type || 'percent'}
            numberValue={values.stamp_card_reward_value || ''}
            onTypeChange={(v) => setField('stamp_card_reward_type', v)}
            onNumberChange={(v) => setField('stamp_card_reward_value', v)}
          />
          <label style={{ minWidth: 260 }}>
            Every Nth order — blank defaults to 5
            <input
              style={inputStyle}
              type="number"
              min={1}
              step="1"
              value={values.stamp_card_every_n_orders || ''}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setField('stamp_card_every_n_orders', e.target.value)}
            />
          </label>
        </div>

        <div style={{ marginBottom: 16 }}>
          <span style={{ display: 'block', marginBottom: 6 }}>Eligible products</span>
          <div
            style={{
              display: 'flex', flexWrap: 'wrap', gap: '8px 16px', padding: 12, border: '1px solid var(--line)',
              borderRadius: 8, background: 'var(--bg-alt)', maxHeight: 260, overflowY: 'auto',
            }}
          >
            {products.length === 0 && <span style={{ color: 'var(--muted)', fontSize: 13 }}>No products found.</span>}
            {products.map((p) => (
              <label key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                <input type="checkbox" checked={eligibleIds.includes(p.id)} onChange={() => toggleEligible(p.id)} />
                {p.name}
              </label>
            ))}
          </div>
        </div>

        <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
        {saved && <span style={{ color: 'var(--gold)', marginLeft: 12 }}>Saved ✓</span>}
      </form>
    </div>
  );
}

const REWARD_CARDS: { id: string; label: string; icon: string; desc: string }[] = [
  { id: 'first_order', label: 'First-Order Discount', icon: '🎉', desc: "Automatic % off a phone number's very first order" },
  { id: 'stamp_card', label: 'Stamp Card', icon: '🎟️', desc: 'On every Nth order, % off the cheapest eligible item — or banked until one is ordered' },
  { id: 'referral', label: 'Referral Program', icon: '🤝', desc: 'A coupon for a friend, from the footer sign-up form' },
  { id: 'scheduled_offers', label: 'Scheduled Offers', icon: '📅', desc: 'Weekday/time-window discounts, e.g. a Monday boost or a Friday special' },
  { id: 'wow_moment', label: 'Ozy Wow Moment', icon: '✨', desc: 'A random surprise reward on a configurable share of orders' },
  // Reorder has no settings to configure — included anyway (rather than
  // omitted) so all 6 growth features are represented here, per the
  // brief's "consolidate settings from all 6 features into one place";
  // its card just explains that and links to where the feature itself
  // lives, instead of a settings form.
  { id: 'reorder', label: 'Reorder', icon: '🔁', desc: 'Always on for every customer — nothing to configure' },
];

function RewardsTab({ token }: { token: string }) {
  const [tab, setTab] = useState<string | null>(null);

  if (!tab) {
    return (
      <div>
        <h2 style={{ marginTop: 0, marginBottom: 4 }}>Rewards</h2>
        <p style={{ color: 'var(--muted)', fontSize: 13.5, marginTop: 0, marginBottom: 16 }}>
          Every growth and loyalty feature's settings, in one place. Pick a card to manage just that feature.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 14 }}>
          {REWARD_CARDS.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setTab(c.id)}
              style={{
                textAlign: 'left', background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 12,
                padding: 20, cursor: 'pointer', color: 'var(--cream)',
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 8 }}>{c.icon}</div>
              <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 4 }}>{c.label}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)' }}>{c.desc}</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <button type="button" style={{ ...btn, marginBottom: 16 }} onClick={() => setTab(null)}>← Back to Rewards</button>

      {tab === 'first_order' && (
        <RewardSettingsForm
          token={token}
          title="First-Order Discount"
          description="Automatically applied to a phone number's genuinely first order (any past order, of any status, disqualifies it). Never stacks with a coupon or a scheduled offer — whichever discount is most favorable to the customer wins."
          fields={[
            { key: 'first_order_discount', label: 'Discount — blank/0 disables it', discount: true },
          ]}
        />
      )}

      {tab === 'stamp_card' && <StampCardSettingsForm token={token} />}

      {tab === 'referral' && (
        <RewardSettingsForm
          token={token}
          title="Referral Program"
          description="The footer's “Refer a friend” form mints a single-use coupon for the email address entered — resubmitting the same email returns the existing code rather than a new one. (There is currently no separate reward for the person who shares the form — only the friend's coupon amount below.)"
          fields={[
            { key: 'referral_discount', label: 'Friend coupon amount — blank defaults to 3€', discount: true },
          ]}
        />
      )}

      {tab === 'scheduled_offers' && (
        <ScheduledOffersManager onChanged={() => {}} />
      )}

      {tab === 'wow_moment' && (
        <RewardSettingsForm
          token={token}
          title="Ozy Wow Moment"
          description="A random chance, on every order, of a small surprise reward shown right on the confirmation screen — a single-use coupon for the customer's next order. Both odds and reward must be set above 0 for this to ever trigger."
          fields={[
            { key: 'wow_moment_chance_percent', label: 'Odds (%) — blank/0 disables it', min: 0, max: 100, step: '1' },
            { key: 'wow_moment_reward', label: 'Reward — blank/0 disables it', discount: true },
          ]}
        />
      )}

      {tab === 'reorder' && (
        <div style={box}>
          <h3 style={{ marginTop: 0 }}>Reorder</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13.5, marginBottom: 0 }}>
            The “Reorder this” button on the order-tracking page is available on every past order —
            there's nothing to turn on or configure. Prices are always recomputed at today's menu
            prices when a customer reorders, never the historical order's price.
          </p>
        </div>
      )}
    </div>
  );
}

/* ---------------- Customer Source ---------------- */
//
// Stamp-card redesign / discount-source tracking task, Part C. Built
// entirely from data this admin panel already fetches generically
// (GET /api/admin/orders via useOrders, GET /api/admin/coupons via
// useCoupons — both defined elsewhere in this file) rather than a new
// bespoke report endpoint: every column each of the 5 sub-sections below
// needs turns out to already be on the `orders`/`coupons` rows once
// discount_source/is_reorder are added (see worker/migrations/
// 010_stamp_card_redesign_and_source_tracking.sql), so this stays a pure
// client-side derivation, following the "reuse existing admin CRUD/report
// patterns" standing rule rather than adding a parallel API.
//
// Historical orders placed before that migration have discount_source
// NULL and is_reorder/triggered_wow_moment 0 — they simply don't show up
// in the Coupons/Reorders views or count toward the Referral/Stamp-card-
// earner badges below, same as any newly-added tracking column. Flagged
// in this task's delivery summary, not something this UI hides.

interface CustomerSourceGroup {
  phone: string;
  totalOrders: number;
  nonCancelledOrders: number;
  totalSpend: number;
  hasReferral: boolean;
  hasStampCard: boolean;
  lastOrder: string;
}

// Deliberately a SEPARATE grouping function from groupOrdersByPhone above
// (used by the Customers tab's loyalty box) rather than extending that
// one — it already ships and is unrelated to this task; adding fields it
// doesn't need risks it in the shuffle, against this project's "stay
// scoped" standing rule. Same last-6-digits phoneMatches tolerance
// (matching lib/api-helpers.ts's server-side logic) so groupings here
// line up with what the server actually treats as "the same customer".
function groupOrdersForCustomerSource(orders: OrderRow[]): CustomerSourceGroup[] {
  const groups: CustomerSourceGroup[] = [];
  orders.forEach((o) => {
    const digits = String(o.phone || '').replace(/\D/g, '');
    const key = digits.slice(-6);
    if (!key) return;
    let group = groups.find((g) => g.phone.replace(/\D/g, '').slice(-6) === key);
    if (!group) {
      group = { phone: o.phone, totalOrders: 0, nonCancelledOrders: 0, totalSpend: 0, hasReferral: false, hasStampCard: false, lastOrder: o.created_at };
      groups.push(group);
    }
    group.totalOrders += 1;
    if (o.status !== 'cancelled') {
      group.nonCancelledOrders += 1;
      group.totalSpend += Number(o.total) || 0;
    }
    if (o.discount_source === 'referral') group.hasReferral = true;
    if (o.discount_source === 'stamp_card') group.hasStampCard = true;
    if (o.created_at > group.lastOrder) group.lastOrder = o.created_at;
  });
  return groups;
}

interface ReferralSourceRow {
  email: string;
  code: string;
  createdAt: string;
  timesUsed: number;
  redemption: { phone: string; orderNum: string; date: string } | null;
}

// A referral coupon's own row has no phone/order/redeemed-at of its own
// (worker/schema.sql's `coupons` table only ever stores the referring
// email) — but the order that actually redeemed it (if any) is findable
// by matching orders.coupon_code back to this coupon's code, which also
// gives an accurate redemption date (the order's created_at) without
// needing a new column for it.
function buildReferralSourceRows(coupons: CouponRowType[], orders: OrderRow[]): ReferralSourceRow[] {
  return coupons
    .filter((c) => c.referral_email)
    .map((c) => {
      const matched = orders.find((o) => o.coupon_code === c.code);
      return {
        email: c.referral_email as string,
        code: c.code,
        createdAt: c.created_at,
        timesUsed: c.times_used,
        redemption: matched ? { phone: matched.phone, orderNum: matched.order_num, date: matched.created_at } : null,
      };
    })
    .sort((a, b) => (a.createdAt > b.createdAt ? -1 : 1));
}

function phoneContains(phone: string, filter: string): boolean {
  const f = filter.replace(/\D/g, '');
  if (!f) return true;
  return String(phone || '').replace(/\D/g, '').includes(f);
}

const CUSTOMER_SOURCE_CARDS: { id: string; label: string; icon: string; desc: string }[] = [
  { id: 'coupons', label: 'Coupons', icon: '🏷️', desc: 'Orders where a manually-entered coupon code won the discount' },
  { id: 'referrals', label: 'Referrals', icon: '🤝', desc: "Every friend code the referral form has issued, and whether it's been used" },
  { id: 'reorders', label: 'Reorders', icon: '🔁', desc: 'Orders placed via the "Reorder this" button' },
  { id: 'repeat', label: 'Repeat Customers', icon: '🔂', desc: '2 or more orders from the same phone number' },
  { id: 'badges', label: 'Customer Badges', icon: '🏅', desc: 'At-a-glance labels computed from order history — nothing to configure' },
];

function CustomerSourceTab({ token }: { token: string }) {
  const { orders, loading: ordersLoading } = useOrders(token);
  const { coupons, loading: couponsLoading } = useCoupons(token);
  const [tab, setTab] = useState<string | null>(null);
  const [phoneFilter, setPhoneFilter] = useState('');
  const loading = ordersLoading || couponsLoading;

  const phoneFilterInput = (
    <input
      style={{ ...inputStyle, maxWidth: 240, marginBottom: 16 }}
      placeholder="Filter by phone…"
      value={phoneFilter}
      onChange={(e: ChangeEvent<HTMLInputElement>) => setPhoneFilter(e.target.value)}
    />
  );

  if (!tab) {
    return (
      <div>
        <h2 style={{ marginTop: 0, marginBottom: 4 }}>Customer Source</h2>
        <p style={{ color: 'var(--muted)', fontSize: 13.5, marginTop: 0, marginBottom: 16 }}>
          Where orders and customers come from, split by source. Pick a card to see just that view.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 14 }}>
          {CUSTOMER_SOURCE_CARDS.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setTab(c.id)}
              style={{
                textAlign: 'left', background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 12,
                padding: 20, cursor: 'pointer', color: 'var(--cream)',
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 8 }}>{c.icon}</div>
              <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 4 }}>{c.label}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)' }}>{c.desc}</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div>
        <button type="button" style={{ ...btn, marginBottom: 16 }} onClick={() => setTab(null)}>← Back to Customer Source</button>
        <p>Loading…</p>
      </div>
    );
  }

  const couponOrders = orders.filter((o) => o.discount_source === 'manual_coupon' && phoneContains(o.phone, phoneFilter));
  const reorderOrders = orders.filter((o) => o.is_reorder && phoneContains(o.phone, phoneFilter));
  const groups = groupOrdersForCustomerSource(orders).filter((g) => phoneContains(g.phone, phoneFilter));
  const repeatGroups = groups.filter((g) => g.totalOrders >= 2).sort((a, b) => b.totalOrders - a.totalOrders);
  const badgeGroups = groups
    .filter((g) => g.totalOrders >= 2 || g.hasReferral || g.hasStampCard)
    .sort((a, b) => (b.lastOrder > a.lastOrder ? 1 : -1));
  const referralRows = buildReferralSourceRows(coupons, orders).filter((r) => phoneContains(r.redemption?.phone || '', phoneFilter));

  return (
    <div>
      <button type="button" style={{ ...btn, marginBottom: 16 }} onClick={() => setTab(null)}>← Back to Customer Source</button>

      {tab === 'coupons' && (
        <div style={box}>
          <h3 style={{ marginTop: 0 }}>Coupons</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
            Every order where a manually-entered coupon code (not the automatic welcome discount,
            stamp card, or a scheduled offer) won the discount.
          </p>
          {phoneFilterInput}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr><th style={th}>Phone</th><th style={th}>Date</th><th style={th}>Order #</th><th style={th}>Coupon code</th><th style={th}>Discount</th></tr>
              </thead>
              <tbody>
                {couponOrders.length === 0 && <tr><td style={td} colSpan={5}>No matching orders.</td></tr>}
                {couponOrders.map((o) => (
                  <tr key={o.id}>
                    <td style={td}>{o.phone}</td>
                    <td style={td}>{o.created_at}</td>
                    <td style={td}>{o.order_num}</td>
                    <td style={td}><code>{o.coupon_code}</code></td>
                    <td style={td}>{formatCurrency(o.discount_amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'referrals' && (
        <div style={box}>
          <h3 style={{ marginTop: 0 }}>Referrals</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
            Every friend code the footer&apos;s referral form has issued. &ldquo;Used&rdquo; means an
            order was placed with that code — the date/phone/order shown is that redemption, found by
            matching the order&apos;s coupon code back to this one (there&apos;s no separate
            redeemed-at column; an order&apos;s own timestamp is an exact stand-in, since redemption
            happens the moment the order is placed).
          </p>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
            <strong>Honest gap:</strong> there is currently no separate reward for the person who
            <em> shares</em> the form (the referrer) anywhere in this codebase — only the friend&apos;s
            coupon below exists (confirmed again for this task; see the Rewards tab&apos;s Referral
            Program card). There is nothing to show for &ldquo;the referrer&apos;s own pending/redeemed
            reward status&rdquo; because that reward doesn&apos;t exist yet — building it would be new
            functionality, out of scope here.
          </p>
          {phoneFilterInput}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr><th style={th}>Referring email</th><th style={th}>Friend&apos;s code</th><th style={th}>Issued</th><th style={th}>Used?</th><th style={th}>Redeemed by (phone / order #)</th></tr>
              </thead>
              <tbody>
                {referralRows.length === 0 && <tr><td style={td} colSpan={5}>No referrals yet.</td></tr>}
                {referralRows.map((r) => (
                  <tr key={r.code}>
                    <td style={td}>{r.email}</td>
                    <td style={td}><code>{r.code}</code></td>
                    <td style={td}>{r.createdAt}</td>
                    <td style={td}>{r.timesUsed > 0 ? 'Yes' : 'Not yet'}</td>
                    <td style={td}>{r.redemption ? `${r.redemption.phone} / ${r.redemption.orderNum} (${r.redemption.date})` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'reorders' && (
        <div style={box}>
          <h3 style={{ marginTop: 0 }}>Reorders</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
            Every order placed via the &ldquo;Reorder this&rdquo; button on the order-tracking page.
            Only orders placed since this tracking was added can be marked this way — orders from
            before then show as regular orders, not reorders (there was nothing recording it until now).
          </p>
          {phoneFilterInput}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr><th style={th}>Phone</th><th style={th}>Date</th><th style={th}>Order #</th><th style={th}>Total</th></tr>
              </thead>
              <tbody>
                {reorderOrders.length === 0 && <tr><td style={td} colSpan={4}>No matching orders.</td></tr>}
                {reorderOrders.map((o) => (
                  <tr key={o.id}>
                    <td style={td}>{o.phone}</td>
                    <td style={td}>{o.created_at}</td>
                    <td style={td}>{o.order_num}</td>
                    <td style={td}>{formatCurrency(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'repeat' && (
        <div style={box}>
          <h3 style={{ marginTop: 0 }}>Repeat Customers</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
            Phone numbers with 2 or more total orders (any status). Total spend sums only non-cancelled
            orders — a cancelled order was never actually paid for.
          </p>
          {phoneFilterInput}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr><th style={th}>Phone</th><th style={th}>Total orders</th><th style={th}>Non-cancelled</th><th style={th}>Total spend</th><th style={th}>Last order</th></tr>
              </thead>
              <tbody>
                {repeatGroups.length === 0 && <tr><td style={td} colSpan={5}>No repeat customers yet.</td></tr>}
                {repeatGroups.map((g) => (
                  <tr key={g.phone}>
                    <td style={td}>{g.phone}</td>
                    <td style={td}>{g.totalOrders}</td>
                    <td style={td}>{g.nonCancelledOrders}</td>
                    <td style={td}>{formatCurrency(g.totalSpend)}</td>
                    <td style={td}>{g.lastOrder}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'badges' && (
        <div style={box}>
          <h3 style={{ marginTop: 0 }}>Customer Badges</h3>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0 }}>
            Computed on the fly from order history every time this view loads — not a stored or
            manually-assigned field, so there&apos;s nothing to edit here. <strong>Repeat</strong> = 2+
            total orders. <strong>Referral</strong> = at least one order where a referral-minted coupon
            won the discount (there&apos;s no way to detect the OTHER side — someone who only ever
            shared the form without a linked order — since referral codes aren&apos;t tied to a phone
            number until redeemed). <strong>Stamp card earner</strong> = at least one order where the
            stamp-card reward actually won the discount. Only phones with at least one badge are shown.
          </p>
          {phoneFilterInput}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr><th style={th}>Phone</th><th style={th}>Badges</th><th style={th}>Last order</th></tr>
              </thead>
              <tbody>
                {badgeGroups.length === 0 && <tr><td style={td} colSpan={3}>No customers with a badge yet.</td></tr>}
                {badgeGroups.map((g) => (
                  <tr key={g.phone}>
                    <td style={td}>{g.phone}</td>
                    <td style={td}>
                      {g.totalOrders >= 2 && <span style={{ marginRight: 8 }}>🔂 Repeat</span>}
                      {g.hasReferral && <span style={{ marginRight: 8 }}>🤝 Referral</span>}
                      {g.hasStampCard && <span style={{ marginRight: 8 }}>🎟️ Stamp card earner</span>}
                    </td>
                    <td style={td}>{g.lastOrder}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function OptionsManager({
  optionGroupFields,
  optionFields,
  onChanged,
}: {
  optionGroupFields: ResourceField[];
  optionFields: ResourceField[];
  onChanged?: () => void;
}) {
  const [groups, setGroups] = useState<RawOptionGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<RawOptionGroup | null>(null); // null = show the group picker

  const loadGroups = () => {
    setLoading(true);
    setError('');
    fetch('/api/admin/option_groups')
      .then((res) => res.json())
      .then((data) => setGroups(Array.isArray(data) ? data : []))
      .catch(() => setError('Could not load option groups.'))
      .finally(() => setLoading(false));
  };

  useEffect(loadGroups, []);

  // Bump both this screen's own group list (in case a group was renamed/
  // added/removed) and the parent Menu & Pricing screen's shared reload
  // trigger (other tabs, like Products, also read option groups).
  const handleChanged = () => {
    loadGroups();
    if (onChanged) onChanged();
  };

  if (selectedGroup) {
    return (
      <div>
        <button type="button" style={{ ...btn, marginBottom: 16 }} onClick={() => setSelectedGroup(null)}>
          ← Back to Options & Toppings
        </button>
        <ResourceManager
          table="options"
          title={`${selectedGroup.title} — choices`}
          fields={optionFields}
          displayCols={['id', 'label', 'label_fi', 'price_delta']}
          onChanged={handleChanged}
          parentFilter={{ field: 'group_id', value: selectedGroup.id }}
        />
      </div>
    );
  }

  return (
    <div>
      <h2 style={{ marginTop: 0, marginBottom: 4 }}>Options & Toppings</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13.5, marginTop: 0, marginBottom: 16 }}>
        Pick a group below to see and edit just its choices (e.g. only the toppings, not the sauces mixed in too).
      </p>

      {loading && <p>Loading…</p>}
      {error && <p style={{ color: 'var(--danger)' }}>{error}</p>}

      {!loading && !error && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, marginBottom: 28 }}>
          {groups.map((g) => (
            <button
              key={g.id}
              type="button"
              onClick={() => setSelectedGroup(g)}
              style={{
                textAlign: 'left', background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 12,
                padding: 16, cursor: 'pointer', color: 'var(--cream)',
              }}
            >
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{g.title}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                {GROUP_KIND_CUSTOMER_VIEW[g.kind] || g.kind}
              </div>
            </button>
          ))}
          {groups.length === 0 && <p style={{ color: 'var(--muted)' }}>No option groups yet — add one below.</p>}
        </div>
      )}

      <h3 style={{ marginBottom: 8 }}>Option groups</h3>
      <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 0, marginBottom: 12 }}>
        The categories themselves (Base, Sauce, Cheese, Toppings, Fillings…) — add or rename a group here, then click its card above to manage its individual choices.
      </p>
      <ResourceManager
        table="option_groups"
        title="Option Groups"
        fields={optionGroupFields}
        displayCols={['id', 'title', 'kind', 'sort_order']}
        onChanged={handleChanged}
      />
    </div>
  );
}


/* ---------------- Menu Availability (Staff role) ---------------- */

// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 4 — the
// entire admin surface a 'staff' account gets for "menu availability":
// a flat list of products (grouped by category name, for orientation
// only — nothing here is clickable/editable) with a single on/off toggle
// per row, writing only `active` via PUT /api/admin/products/:id. This
// is deliberately NOT the full ResourceManager-based Menu & Pricing tab
// (which exposes price/name/image/etc. editing) — staff's chosen
// permission boundary is "menu availability, not pricing", and the
// server-side enforcement of that same boundary lives in
// app/api/admin/[table]/[id]/route.ts's PUT (rejects any field but
// `active`, and any table but `products`, for this role) — this
// component's simplicity is a UX nicety on top of that, not the actual
// access control, same relationship as ROLE_TABS has to requireRole()
// elsewhere in this file.
function MenuAvailabilityTab({ token }: { token: string }) {
  const [categories, setCategories] = useState<RawCategory[]>([]);
  const [products, setProducts] = useState<RawProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    setError('');
    Promise.all([
      fetch('/api/admin/categories').then((r) => r.json()),
      fetch('/api/admin/products').then((r) => r.json()),
    ])
      .then(([cats, prods]) => {
        setCategories(Array.isArray(cats) ? cats : []);
        setProducts(Array.isArray(prods) ? prods : []);
      })
      .catch(() => setError('Could not load the menu.'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [token]);

  const categoryTitle = (id: string) => categories.find((c) => c.id === id)?.title || id;

  const toggleActive = async (product: RawProduct) => {
    setBusyId(product.id);
    setError('');
    const next = product.active ? 0 : 1;
    try {
      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: next }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error || 'Could not update availability.');
      }
      setProducts((list) => list.map((p) => (p.id === product.id ? { ...p, active: next } : p)));
    } catch (err: any) {
      setError(err.message || 'Could not update availability.');
    } finally {
      setBusyId(null);
    }
  };

  const sorted = products.slice().sort((a, b) => {
    const catCompare = categoryTitle(a.category_id).localeCompare(categoryTitle(b.category_id));
    if (catCompare !== 0) return catCompare;
    return (a.sort_order || 0) - (b.sort_order || 0);
  });

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Menu Availability</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13.5 }}>
        Turn an item off when it&apos;s sold out or unavailable today — it disappears from the menu immediately.
        Turn it back on any time. Prices, descriptions and everything else here can only be changed by a Manager
        or Owner.
      </p>
      {error && <p style={{ color: 'var(--danger)' }}>{error}</p>}
      {loading ? (
        <p>Loading menu…</p>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Category</th>
                <th style={th}>Item</th>
                <th style={th}>Price</th>
                <th style={th}>Available</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((p) => (
                <tr key={p.id}>
                  <td style={td}>{categoryTitle(p.category_id)}</td>
                  <td style={td}>{p.name}</td>
                  <td style={td}>{formatCurrency(p.price)}</td>
                  <td style={td}>
                    <button
                      type="button"
                      disabled={busyId === p.id}
                      onClick={() => toggleActive(p)}
                      style={p.active ? btnPrimary : btnDanger}
                    >
                      {busyId === p.id ? '…' : p.active ? '🟢 Available' : '⚪ Unavailable'}
                    </button>
                  </td>
                </tr>
              ))}
              {!sorted.length && (
                <tr><td style={td} colSpan={4}>No menu items yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function MenuTabs({ token, initialTab }: { token: string; initialTab?: string | null }) {
  const [categories, setCategories] = useState<RawCategory[]>([]);
  const [optionGroups, setOptionGroups] = useState<RawOptionGroup[]>([]);
  const [products, setProducts] = useState<RawProduct[]>([]);
  const [refreshKey, setRefreshKey] = useState(0);

  const loadRefs = () => {
    fetch('/api/admin/categories').then((r) => r.json()).then((d) => setCategories(Array.isArray(d) ? d : [])).catch(() => {});
    fetch('/api/admin/option_groups').then((r) => r.json()).then((d) => setOptionGroups(Array.isArray(d) ? d : [])).catch(() => {});
    fetch('/api/admin/products').then((r) => r.json()).then((d) => setProducts(Array.isArray(d) ? d : [])).catch(() => {});
  };

  useEffect(loadRefs, [token, refreshKey]);
  const bump = () => setRefreshKey((k) => k + 1);
  // Bundle-slug-and-navigation brief, Task 2 — `initialTab` (from the
  // dashboard's own `?menuTab=` query param) lands the admin back on
  // e.g. "products" after returning from the dedicated product-edit page,
  // instead of always resetting to the landing page of big option cards.
  // Only affects the very first render; `null`/absent behaves exactly as
  // before this feature existed.
  const [tab, setTab] = useState<string | null>(initialTab ?? null);

  // Phase: bilingual site — every `_fi` field below is optional; the
  // storefront falls back to the English/default field next to it when
  // empty (see lib/menu-i18n.js). Placed directly after its English
  // counterpart in each list so the two are easy to compare while editing.
  const categoryFields: ResourceField[] = [
    { key: 'id', label: 'ID (slug)', type: 'text', required: true, placeholder: 'e.g. pizzat' },
    { key: 'title', label: 'Title (English)', type: 'text', required: true },
    { key: 'title_fi', label: 'Title (Finnish, optional)', type: 'text' },
    { key: 'sub', label: 'Subtitle (English)', type: 'text' },
    { key: 'sub_fi', label: 'Subtitle (Finnish, optional)', type: 'text' },
    { key: 'image', label: 'Image', type: 'image' },
    { key: 'sort_order', label: 'Sort order', type: 'number', default: 0 },
    // Priority-fixes brief (roadmap gap analysis), Part 2 — admin SEO
    // fields (worker/migrations/017_admin_seo_fields.sql). Categories had
    // none of this before — not even a meta description — see the
    // fallback chain in generateMetadata,
    // app/(site)/[locale]/menu/[category]/page.tsx.
    {
      key: 'meta_description', label: 'Meta description (English, optional)', type: 'textarea',
      hint: 'Shown in Google search results — aim for under ~160 characters. Leave blank to use the subtitle above.',
    },
    {
      key: 'meta_description_fi', label: 'Meta description (Finnish, optional)', type: 'textarea',
      hint: 'Shown in Google search results — aim for under ~160 characters. Leave blank to use the subtitle above.',
    },
    {
      key: 'seo_title', label: 'SEO title (English, optional)', type: 'text',
      hint: 'Overrides the page <title>. Leave blank to use the category title.',
    },
    {
      key: 'seo_title_fi', label: 'SEO title (Finnish, optional)', type: 'text',
      hint: 'Overrides the page <title>. Leave blank to use the category title.',
    },
    {
      key: 'canonical_url', label: 'Canonical URL override (optional)', type: 'text',
      hint: 'Rarely needed — leave blank unless you specifically need this page to point its canonical somewhere other than its own URL.',
    },
    {
      key: 'noindex', label: 'Hide from search engines (noindex)', type: 'checkbox',
      hint: 'When checked, this page is excluded from the sitemap and told not to be indexed.',
    },
    {
      key: 'og_image_url', label: 'Social share image override (optional)', type: 'image',
      hint: 'Shown when this page is shared on social media. Leave blank to use the category image above.',
    },
  ];

  const optionGroupFields: ResourceField[] = [
    { key: 'id', label: 'ID (slug)', type: 'text', required: true, placeholder: 'e.g. base' },
    { key: 'title', label: 'Title (English)', type: 'text', required: true },
    { key: 'title_fi', label: 'Title (Finnish, optional)', type: 'text' },
    {
      key: 'kind', label: 'Kind', type: 'select', required: true,
      options: [
        { value: 'base', label: 'Base' }, { value: 'sauce', label: 'Sauce' }, { value: 'cheese', label: 'Cheese' },
        { value: 'sauce_stripe', label: 'Sauce stripe' }, { value: 'dip', label: 'Dip' },
        { value: 'topping', label: 'Topping (checkbox list)' }, { value: 'filling', label: 'Filling category' },
        // Per-product-size brief — required/single-select, same as
        // 'base'/'sauce'/etc. above, but now genuinely PER-PRODUCT rather
        // than global: pick which product this size ladder belongs to in
        // the "Product" field below (see lib/menu-i18n.ts's
        // normalizeMenuBlob for the product_id-scoped lookup this drives).
        // Every other 'kind' here stays global exactly as before.
        { value: 'size', label: 'Size (per-product tiers — pick a Product below)' },
      ],
    },
    {
      key: 'product_id', label: 'Product (only used by "Size" groups)', type: 'select',
      options: [{ value: '', label: '— none (global — every other kind) —' }, ...products.map((p) => ({ value: p.id, label: `${p.name} (${p.id})` }))],
      hint: 'Only matters for a "Size" group: it scopes that size ladder to this one product. Ignored for every other kind, which stay global/shared by every product exactly as before.',
    },
    { key: 'icon', label: 'Icon (emoji, optional)', type: 'text' },
    { key: 'sort_order', label: 'Sort order', type: 'number', default: 0 },
  ];

  const optionFields: ResourceField[] = [
    { key: 'id', label: 'ID (slug)', type: 'text', required: true, placeholder: 'e.g. base-classic' },
    { key: 'group_id', label: 'Option group', type: 'select', required: true, options: optionGroups.map((g) => ({ value: g.id, label: `${g.title} (${g.id})` })) },
    { key: 'label', label: 'Label (English)', type: 'text', required: true },
    { key: 'label_fi', label: 'Label (Finnish, optional)', type: 'text' },
    { key: 'price_delta', label: 'Price delta (€)', type: 'number', step: '0.1', default: 0 },
    { key: 'color', label: 'Color (hex, optional)', type: 'text', placeholder: '#c0392b' },
    { key: 'sort_order', label: 'Sort order', type: 'number', default: 0 },
  ];

  // Bundle-slug-and-navigation brief, Task 2 — moved to lib/admin-resource-fields.ts
  // so app/admin/products/[id]/edit/page.tsx's dedicated edit form can build
  // the exact same field list rather than a separately hand-typed copy.
  const productFields: ResourceField[] = getProductFields(categories);

  const addonFields: ResourceField[] = [
    { key: 'id', label: 'ID (slug)', type: 'text', required: true },
    { key: 'type', label: 'Type', type: 'select', required: true, options: [{ value: 'drink', label: 'Drink' }, { value: 'dip', label: 'Dip' }, { value: 'snack', label: 'Snack' }] },
    { key: 'name', label: 'Name (English)', type: 'text', required: true },
    { key: 'name_fi', label: 'Name (Finnish, optional)', type: 'text' },
    { key: 'price', label: 'Price (€)', type: 'number', step: '0.1', required: true },
    { key: 'image', label: 'Image', type: 'image' },
    { key: 'active', label: 'Active', type: 'checkbox', default: true },
    { key: 'sort_order', label: 'Sort order', type: 'number', default: 0 },
  ];

  const TABS = [
    { id: 'products', label: 'Products', icon: '🍕', desc: 'Add, edit, price, and manage every menu item' },
    { id: 'categories', label: 'Categories', icon: '📁', desc: 'Organize the menu into sections like Pizza, Kebab, Burgers' },
    { id: 'options', label: 'Options & Toppings', icon: '🧀', desc: 'Bases, sauces, cheese, toppings, and filling choices' },
    { id: 'addons', label: 'Add-ons', icon: '🥤', desc: 'Drinks, dips, and snacks customers can add to their order' },
    { id: 'bundles', label: 'Bundles', icon: '🎁', desc: 'Combo deals and multi-item meal bundles' },
  ];

  if (!tab) {
    return (
      <div>
        <h2 style={{ marginTop: 0, marginBottom: 16 }}>Product Management</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 14 }}>
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              style={{
                textAlign: 'left', background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 12,
                padding: 20, cursor: 'pointer', color: 'var(--cream)',
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 8 }}>{t.icon}</div>
              <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 4 }}>{t.label}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)' }}>{t.desc}</div>
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <button type="button" style={{ ...btn, marginBottom: 16 }} onClick={() => setTab(null)}>← Back to Product Management</button>

      {tab === 'categories' && (
        <ResourceManager table="categories" title="Categories" fields={categoryFields} displayCols={['id', 'title', 'sub', 'sort_order']} onChanged={bump} />
      )}
      {tab === 'products' && (
        <ResourceManager table="products" title="Products" fields={productFields} displayCols={['id', 'category_id', 'name', 'price', 'active']} onChanged={bump} />
      )}
      {tab === 'options' && (
        <OptionsManager optionGroupFields={optionGroupFields} optionFields={optionFields} onChanged={bump} />
      )}
      {tab === 'addons' && (
        <ResourceManager table="addons" title="Add-ons (drinks, dips, snacks)" fields={addonFields} displayCols={['id', 'type', 'name', 'price', 'active']} onChanged={bump} />
      )}
      {tab === 'bundles' && (
        <BundleManager token={token} categories={categories} products={products} onChanged={bump} />
      )}
    </div>
  );
}

/* ---------------- Staff Management (Owner-only) ---------------- */

// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 4 — 'staff'
// inserted between 'kitchen' and 'manager', matching its chosen
// permission boundary (a step up from kitchen, still well short of
// manager). Feeds both the "create account" role picker and each
// existing account's role-change dropdown (StaffRow below) — adding it
// here is the entire admin-UI surface needed to let an Owner assign it.
const ROLE_OPTIONS: { value: StaffRole; label: string }[] = [
  { value: 'kitchen', label: 'Kitchen' },
  { value: 'staff', label: 'Staff' },
  { value: 'manager', label: 'Manager' },
  { value: 'owner', label: 'Owner' },
];

function useStaffList(token: string) {
  const [staff, setStaff] = useState<StaffRowType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    if (!token) return;
    setLoading(true);
    setError('');
    fetch('/api/admin/staff')
      .then((res) => {
        if (!res.ok) throw new Error('Could not load staff.');
        return res.json();
      })
      .then((data) => setStaff(Array.isArray(data) ? data : []))
      .catch(() => setError('Could not load staff.'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [token]);

  return { staff, loading, error, reload: load };
}

function AddStaffForm({ onAdded }: { onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<StaffRole>('kitchen');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const reset = () => {
    setName(''); setEmail(''); setPassword(''); setRole('kitchen'); setError('');
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      const res = await fetch('/api/admin/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not create staff account.');
      reset();
      setOpen(false);
      onAdded();
    } catch (err: any) {
      setError(err.message || 'Could not create staff account.');
    } finally {
      setSaving(false);
    }
  };

  if (!open) {
    return <button type="button" style={btnPrimary} onClick={() => setOpen(true)}>+ Add staff account</button>;
  }

  return (
    <form onSubmit={submit} style={{ ...card, marginBottom: 20 }}>
      <h3 style={cardTitle}>New staff account</h3>
      {error && <p style={{ color: 'var(--danger)', marginTop: 0 }}>{error}</p>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14 }}>
        <label>Name<input style={inputStyle} value={name} onChange={(e: ChangeEvent<HTMLInputElement>) => setName(e.target.value)} required /></label>
        <label>Email<input style={inputStyle} type="email" value={email} onChange={(e: ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)} required /></label>
        <label>Temporary password<input style={inputStyle} type="text" value={password} onChange={(e: ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)} minLength={8} required /></label>
        <label>
          Role
          <select style={inputStyle} value={role} onChange={(e: ChangeEvent<HTMLSelectElement>) => setRole(e.target.value as StaffRole)}>
            {ROLE_OPTIONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </select>
        </label>
      </div>
      <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>
        Give this password to the staff member directly — there's no email-invite flow yet, so share it out of band (in person, a call, etc.), not over an insecure channel.
      </p>
      <div style={{ marginTop: 8 }}>
        <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Creating…' : 'Create account'}</button>
        <button type="button" style={btn} onClick={() => { reset(); setOpen(false); }}>Cancel</button>
      </div>
    </form>
  );
}

// Body shape sent to PATCH /api/admin/staff/:id — only ever one of these
// fields at a time in this file, but modeled as one loose optional-field
// shape (matching the API route's own partial-patch handling) rather than
// three separate patch functions.
interface StaffPatchBody {
  role?: StaffRole;
  active?: number;
  disable2fa?: boolean;
}

function StaffRow({ member, onChanged }: { member: StaffRowType; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirmingDisable2fa, setConfirmingDisable2fa] = useState(false);

  const patch = async (body: StaffPatchBody) => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/admin/staff/${member.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Update failed.');
      onChanged();
    } catch (err: any) {
      setError(err.message || 'Update failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <tr>
      <td style={td}>{member.name}</td>
      <td style={td}>{member.email}</td>
      <td style={td}>
        <select
          style={{ ...inputStyle, marginTop: 0, width: 'auto' }}
          value={member.role}
          disabled={busy}
          onChange={(e: ChangeEvent<HTMLSelectElement>) => patch({ role: e.target.value as StaffRole })}
        >
          {ROLE_OPTIONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
      </td>
      <td style={td}>{member.active ? '🟢 Active' : '⚪ Inactive'}</td>
      <td style={td}>
        {member.totp_enabled ? (
          <button
            type="button"
            style={{ ...btn, fontSize: 12, padding: '5px 10px' }}
            disabled={busy}
            onClick={() => setConfirmingDisable2fa(true)}
          >
            🔒 On — force off
          </button>
        ) : '—'}
        <ConfirmDialog
          open={confirmingDisable2fa}
          title="Force-disable 2FA?"
          message={`Force-disable 2FA on ${member.name}'s account? They'll be able to log in with just their password again.`}
          confirmLabel="Force off"
          cancelLabel="Cancel"
          busy={busy}
          onConfirm={() => {
            // Phase 7.9 lockout recovery — see this feature's summary
            // for why this exists: without it, a staff member who
            // loses their authenticator device has no way back in.
            patch({ disable2fa: true });
            setConfirmingDisable2fa(false);
          }}
          onCancel={() => setConfirmingDisable2fa(false)}
        />
      </td>
      <td style={td}>
        <button
          type="button"
          style={member.active ? btnDanger : btnPrimary}
          disabled={busy}
          onClick={() => patch({ active: member.active ? 0 : 1 })}
        >
          {member.active ? 'Deactivate' : 'Reactivate'}
        </button>
        {error && <div style={{ color: 'var(--danger)', fontSize: 12, marginTop: 4 }}>{error}</div>}
      </td>
    </tr>
  );
}

function StaffManagementTab({ token }: { token: string }) {
  const { staff, loading, error, reload } = useStaffList(token);

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Staff</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13.5 }}>
        Kitchen role: Orders board only. Manager: Orders, Menu &amp; Pricing, Homepage Display, Customers, Reports.
        Owner: everything, including this page. There's always at least one Owner account — the last one can't be deactivated or demoted.
      </p>
      <div style={{ marginBottom: 20 }}>
        <AddStaffForm onAdded={reload} />
      </div>
      {loading ? <p>Loading…</p> : error ? <p style={{ color: 'var(--danger)' }}>{error}</p> : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Name</th>
                <th style={th}>Email</th>
                <th style={th}>Role</th>
                <th style={th}>Status</th>
                <th style={th}>2FA</th>
                <th style={th}></th>
              </tr>
            </thead>
            <tbody>
              {staff.map((m) => <StaffRow key={m.id} member={m} onChanged={reload} />)}
              {!staff.length && (
                <tr><td style={td} colSpan={6}>No staff accounts yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------- Activity Log (Owner-only) ---------------- */

function ActivityLogTab({ token }: { token: string }) {
  const [entries, setEntries] = useState<AuditLogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!token) return;
    setLoading(true);
    setError('');
    fetch('/api/admin/activity')
      .then((res) => {
        if (!res.ok) throw new Error('Could not load activity.');
        return res.json();
      })
      .then((data) => setEntries(Array.isArray(data) ? data : []))
      .catch(() => setError('Could not load activity.'))
      .finally(() => setLoading(false));
  }, [token]);

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Activity Log</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13.5 }}>
        Recent order status changes, menu/price edits, settings changes and staff account changes, most recent first.
      </p>
      {loading ? <p>Loading…</p> : error ? <p style={{ color: 'var(--danger)' }}>{error}</p> : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>When</th>
                <th style={th}>Who</th>
                <th style={th}>Action</th>
                <th style={th}>Detail</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.id}>
                  <td style={td}>{new Date(`${e.created_at}Z`).toLocaleString()}</td>
                  <td style={td}>{e.staff_name}</td>
                  <td style={td}>{e.action}</td>
                  <td style={td}>{e.detail}</td>
                </tr>
              ))}
              {!entries.length && (
                <tr><td style={td} colSpan={4}>Nothing logged yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------- Coupons (Phase 7.6, Manager+Owner) ---------------- */

function useCoupons(token: string) {
  const [coupons, setCoupons] = useState<CouponRowType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    if (!token) return;
    setLoading(true);
    setError('');
    fetch('/api/admin/coupons')
      .then((res) => {
        if (!res.ok) throw new Error('Could not load coupons.');
        return res.json();
      })
      .then((data) => setCoupons(Array.isArray(data) ? data : []))
      .catch(() => setError('Could not load coupons.'))
      .finally(() => setLoading(false));
  };

  useEffect(load, [token]);

  return { coupons, loading, error, reload: load };
}

function AddCouponForm({ onAdded }: { onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<'percent' | 'amount'>('percent');
  const [discountValue, setDiscountValue] = useState('');
  const [expiresAt, setExpiresAt] = useState('');
  const [minOrderAmount, setMinOrderAmount] = useState('');
  const [usageLimit, setUsageLimit] = useState('');
  // Priority-fixes brief (roadmap gap analysis), Part 4 — optional cap
  // on this coupon's discount, in euros.
  const [maxDiscountAmount, setMaxDiscountAmount] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const reset = () => {
    setCode(''); setDiscountType('percent'); setDiscountValue('');
    setExpiresAt(''); setMinOrderAmount(''); setUsageLimit(''); setMaxDiscountAmount(''); setError('');
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      const res = await fetch('/api/admin/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          discount_type: discountType,
          discount_value: Number(discountValue),
          expires_at: expiresAt || null,
          min_order_amount: minOrderAmount === '' ? null : Number(minOrderAmount),
          usage_limit: usageLimit === '' ? null : Number(usageLimit),
          max_discount_amount: maxDiscountAmount === '' ? null : Number(maxDiscountAmount),
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not create coupon.');
      reset();
      setOpen(false);
      onAdded();
    } catch (err: any) {
      setError(err.message || 'Could not create coupon.');
    } finally {
      setSaving(false);
    }
  };

  if (!open) {
    return <button type="button" style={btnPrimary} onClick={() => setOpen(true)}>+ New coupon</button>;
  }

  return (
    <form onSubmit={submit} style={{ ...card, marginBottom: 20 }}>
      <h3 style={cardTitle}>New coupon</h3>
      {error && <p style={{ color: 'var(--danger)', marginTop: 0 }}>{error}</p>}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14 }}>
        <label>
          Code
          <input style={inputStyle} value={code} onChange={(e: ChangeEvent<HTMLInputElement>) => setCode(e.target.value.toUpperCase())} placeholder="SAVE10" required />
        </label>
        <label>
          Type
          <select style={inputStyle} value={discountType} onChange={(e: ChangeEvent<HTMLSelectElement>) => setDiscountType(e.target.value as 'percent' | 'amount')}>
            <option value="percent">Percent off</option>
            <option value="amount">Amount off (€)</option>
          </select>
        </label>
        <label>
          Value {discountType === 'percent' ? '(%)' : '(€)'}
          <input style={inputStyle} type="number" min="0.01" step="0.01" value={discountValue} onChange={(e: ChangeEvent<HTMLInputElement>) => setDiscountValue(e.target.value)} required />
        </label>
        <label>
          Expires (optional)
          <input style={inputStyle} type="date" value={expiresAt} onChange={(e: ChangeEvent<HTMLInputElement>) => setExpiresAt(e.target.value)} />
        </label>
        <label>
          Minimum order € (optional)
          <input style={inputStyle} type="number" min="0" step="0.01" value={minOrderAmount} onChange={(e: ChangeEvent<HTMLInputElement>) => setMinOrderAmount(e.target.value)} />
        </label>
        <label>
          Usage limit (optional)
          <input style={inputStyle} type="number" min="1" step="1" value={usageLimit} onChange={(e: ChangeEvent<HTMLInputElement>) => setUsageLimit(e.target.value)} placeholder="Unlimited" />
        </label>
        <label>
          Maximum discount € (optional)
          <input style={inputStyle} type="number" min="0.01" step="0.01" value={maxDiscountAmount} onChange={(e: ChangeEvent<HTMLInputElement>) => setMaxDiscountAmount(e.target.value)} placeholder="No cap" />
        </label>
      </div>
      <div style={{ marginTop: 8 }}>
        <button type="submit" style={btnPrimary} disabled={saving}>{saving ? 'Creating…' : 'Create coupon'}</button>
        <button type="button" style={btn} onClick={() => { reset(); setOpen(false); }}>Cancel</button>
      </div>
    </form>
  );
}

function CouponRow({ coupon, onChanged }: { coupon: CouponRowType; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const toggleActive = async () => {
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/admin/coupons/${coupon.code}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: coupon.active ? 0 : 1 }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Update failed.');
      onChanged();
    } catch (err: any) {
      setError(err.message || 'Update failed.');
    } finally {
      setBusy(false);
    }
  };

  const valueLabel = coupon.discount_type === 'percent' ? `${coupon.discount_value}%` : `${Number(coupon.discount_value).toFixed(2)} €`;
  const usageLabel = coupon.usage_limit != null ? `${coupon.times_used} / ${coupon.usage_limit}` : `${coupon.times_used}`;
  const expiredAlready = coupon.expires_at && new Date(coupon.expires_at).getTime() < Date.now() - 24 * 60 * 60 * 1000;

  return (
    <tr>
      <td style={td}><strong>{coupon.code}</strong></td>
      <td style={td}>{valueLabel}</td>
      <td style={td}>{coupon.max_discount_amount != null ? `${Number(coupon.max_discount_amount).toFixed(2)} €` : '—'}</td>
      <td style={td}>{coupon.min_order_amount != null ? `${Number(coupon.min_order_amount).toFixed(2)} €` : '—'}</td>
      <td style={td}>{usageLabel}</td>
      <td style={td}>{coupon.expires_at || '—'}{expiredAlready ? ' (expired)' : ''}</td>
      <td style={td}>{coupon.active ? '🟢 Active' : '⚪ Inactive'}</td>
      <td style={td}>
        <button
          type="button"
          style={coupon.active ? btnDanger : btnPrimary}
          disabled={busy}
          onClick={toggleActive}
        >
          {coupon.active ? 'Deactivate' : 'Reactivate'}
        </button>
        {error && <div style={{ color: 'var(--danger)', fontSize: 12, marginTop: 4 }}>{error}</div>}
      </td>
    </tr>
  );
}

function CouponsTab({ token }: { token: string }) {
  const { coupons, loading, error, reload } = useCoupons(token);

  return (
    <div style={box}>
      <h2 style={{ marginTop: 0 }}>Coupons</h2>
      <p style={{ color: 'var(--muted)', fontSize: 13.5 }}>
        Customers enter a code at checkout — every code is re-checked (validity, expiry, minimum order, usage limit)
        and the discount recalculated on our server when the order is actually placed, never trusted from the browser.
      </p>
      <div style={{ marginBottom: 20 }}>
        <AddCouponForm onAdded={reload} />
      </div>
      {loading ? <p>Loading…</p> : error ? <p style={{ color: 'var(--danger)' }}>{error}</p> : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={th}>Code</th>
                <th style={th}>Discount</th>
                <th style={th}>Max. discount</th>
                <th style={th}>Min. order</th>
                <th style={th}>Used</th>
                <th style={th}>Expires</th>
                <th style={th}>Status</th>
                <th style={th}></th>
              </tr>
            </thead>
            <tbody>
              {coupons.map((c) => <CouponRow key={c.code} coupon={c} onChanged={reload} />)}
              {!coupons.length && (
                <tr><td style={td} colSpan={8}>No coupons yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ---------------- Root ---------------- */

// Which top-level tabs each role can see — mirrors the requireRole()
// checks the underlying APIs already enforce (lib/adminAuth.js and each
// app/api/admin/**/route.js), so a role never sees a tab whose API call
// would 403 anyway. This list is the UX nicety on top of that real
// enforcement, not a substitute for it.
// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 4 — 'staff'
// gets 'orders' (same as kitchen) plus the new, narrower
// 'menu_availability' tab (see MenuAvailabilityTab above) — not 'menu'
// itself, which exposes pricing.
const ROLE_TABS: Record<StaffRole, string[]> = {
  kitchen: ['orders'],
  staff: ['orders', 'menu_availability'],
  manager: ['overview', 'orders', 'menu', 'rewards', 'coupons', 'homepage', 'customers', 'customer_source', 'reports'],
  owner: ['overview', 'orders', 'menu', 'rewards', 'coupons', 'homepage', 'customers', 'customer_source', 'reports', 'tracking', 'settings', 'staff', 'activity'],
};

// Bundle-slug-and-navigation brief, Task 2 — the dedicated product-edit
// route (app/admin/products/[id]/edit/page.tsx) needs to send the admin
// back to the exact tab/sub-tab they came from, and `useSearchParams()`
// requires a Suspense boundary around whatever component calls it (a
// Next.js App Router rule for any hook that reads the URL's query string) —
// so the actual dashboard implementation moved to `AdminDashboardView`
// below, and this is now just that thin wrapper.
export default function AdminDashboard() {
  return (
    <Suspense fallback={null}>
      <AdminDashboardView />
    </Suspense>
  );
}

function AdminDashboardView() {
  const searchParams = useSearchParams();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<StaffRole | null>(null);
  const [token, setToken] = useState('');
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<string | null>(null); // set once we know the role — see checkSession below
  const [showMyAccount, setShowMyAccount] = useState(false); // Phase 7.9 — visible to every role

  // See app/admin/page.js for the matching check on the login page, and
  // why it's written to always resolve `ready` one way or another instead
  // of ever leaving this page stuck blank.
  //
  // Phase 5b: cookie-only, no sessionStorage fast path anymore — every
  // load asks /api/admin/me. `token` here is kept as a plain "are we
  // authenticated" flag (not a real secret — there is no token string
  // available to client JS at all now) purely so the many child
  // components below that gate on `if (!token) return` / depend on it in
  // a `useEffect([token])` keep working unchanged; none of them send it
  // anywhere anymore (the `Authorization` headers were removed before
  // staff roles existed — auth now travels solely via the httpOnly
  // cookie, sent automatically on every same-origin fetch()).
  useEffect(() => {
    let cancelled = false;

    async function checkSession() {
      try {
        const res = await fetch('/api/admin/me');
        // res.json() resolves to `unknown` under real fetch typings — cast
        // to the small shape this endpoint actually returns.
        const data = (await res.json().catch(() => ({ authenticated: false }))) as {
          authenticated?: boolean;
          email?: string;
          name?: string;
          role?: StaffRole;
        };
        if (cancelled) return;
        if (data.authenticated) {
          setToken('cookie-session');
          setEmail(data.email || '');
          setName(data.name || '');
          setRole(data.role || null);
          // Kitchen never sees the Overview/Dashboard tab — land them
          // straight on the one tab they do have (Orders) instead of a
          // tab list that would render empty for a beat.
          const roleTabs = ROLE_TABS[data.role as StaffRole] || [];
          const fallbackTab = roleTabs.includes('overview') ? 'overview' : (roleTabs[0] || 'orders');
          // Bundle-slug-and-navigation brief, Task 2 — a `?tab=` query
          // param (set by app/admin/products/[id]/edit/page.tsx's Cancel/
          // Save-success navigation, and by the Edit button's
          // router.replace before leaving for that page) means "land back
          // on this specific tab" rather than this role's usual default.
          // Ignored (falls through to the normal default) unless it names
          // a real tab this role can actually see — a stale/bookmarked/
          // hand-edited URL can't put someone on a tab their role doesn't
          // have access to.
          const requestedTab = searchParams.get('tab');
          setTab(requestedTab && roleTabs.includes(requestedTab) ? requestedTab : fallbackTab);
          setReady(true);
        } else {
          window.location.href = '/admin';
        }
      } catch {
        // Couldn't verify the session — send them back to login rather
        // than leaving the dashboard hanging on nothing.
        if (!cancelled) window.location.href = '/admin';
      }
    }

    checkSession();
    return () => {
      cancelled = true;
    };
  }, []);

  // Kitchen's role has no access to GET /api/admin/analytics (403) — skip
  // the request entirely rather than firing it and discarding the error,
  // same as the pre-signed-in case this hook already handles via `token`.
  const canSeeAnalytics = role === 'manager' || role === 'owner';
  const { data: analytics, loading: analyticsLoading, reload: reloadAnalytics } = useAnalytics(canSeeAnalytics ? token || null : null);

  const logout = () => {
    // Clears the httpOnly cookie server-side — client JS has no way to
    // read or delete it directly, and there's nothing left in
    // sessionStorage to clean up on this end (phase 5b: cookie is the
    // only session state). Fire-and-redirect: even if this request fails
    // outright, the cookie still expires on its own (24h) — worst case is
    // a stale device staying signed in a little longer, not this tab
    // failing to leave.
    fetch('/api/admin/logout', { method: 'POST' }).finally(() => {
      window.location.href = '/admin';
    });
  };

  if (!ready || !tab) return null;

  const pendingCount = analytics ? analytics.summary.pendingOrders : null;

  const ALL_TABS = [
    { id: 'overview', label: '🏠 Dashboard' },
    { id: 'orders', label: '📦 Orders', badge: pendingCount },
    { id: 'menu', label: '🍕 Menu & Pricing' },
    // Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 4 — only
    // ever shown to 'staff' (see ROLE_TABS above); manager/owner already
    // have the full 'menu' tab above, which is a strict superset.
    { id: 'menu_availability', label: '🍽️ Menu Availability' },
    { id: 'rewards', label: '🎁 Rewards' },
    { id: 'coupons', label: '🏷️ Coupons' },
    { id: 'homepage', label: '🖼️ Homepage Display' },
    { id: 'customers', label: '👥 Customers' },
    { id: 'customer_source', label: '🔎 Customer Source' },
    { id: 'reports', label: '📊 Reports' },
    { id: 'tracking', label: '📈 Tracking & Analytics' },
    { id: 'settings', label: '⚙️ Settings' },
    { id: 'staff', label: '🧑‍🍳 Staff' },
    { id: 'activity', label: '📝 Activity Log' },
  ];
  // The real enforcement is server-side (requireRole in every
  // app/api/admin/**/route.js) — this filter just keeps a role from
  // seeing a tab whose API calls would 403 anyway. Falls back to showing
  // nothing extra for an unrecognized role rather than guessing broad.
  const TOP_TABS = ALL_TABS.filter((t) => (role ? ROLE_TABS[role] : []).includes(t.id));

  const ROLE_LABEL: Record<StaffRole, string> = { kitchen: 'Kitchen', staff: 'Staff', manager: 'Manager', owner: 'Owner' };

  // Audit-fixes brief, Part 6.8 — the flat 13-tab strip (more, for an
  // Owner, than any other role sees) was one long wrapped row with no way
  // to scan it — "Coupons" and "Customer Source" sat side by side with no
  // hint they belong to different parts of the app. Grouping is purely
  // visual/organizational: it only changes how TOP_TABS is laid out below,
  // never which tab is selected or what renders for it, so tab state and
  // routing (tab === t.id, setTab, badges) are untouched. A group renders
  // only if at least one of its tabs survives the existing role filter, so
  // e.g. Kitchen (Orders only) still sees a single unlabeled row rather
  // than a wall of empty group headers.
  const TAB_GROUPS: { label: string; ids: string[] }[] = [
    { label: 'Overview', ids: ['overview'] },
    { label: 'Operations', ids: ['orders', 'menu', 'homepage'] },
    { label: 'Marketing', ids: ['rewards', 'coupons'] },
    { label: 'Customers', ids: ['customers', 'customer_source'] },
    { label: 'Insights', ids: ['reports', 'tracking'] },
    { label: 'Admin', ids: ['settings', 'staff', 'activity'] },
  ];

  return (
    <main style={{ minHeight: '100vh', background: 'var(--bg)', padding: '30px', color: 'var(--cream)', fontFamily: "'Work Sans', sans-serif" }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <div>
            <h1 style={{ margin: 0, color: 'var(--cream)' }}>OZY Admin Dashboard</h1>
            <p style={{ color: 'var(--muted)' }}>
              {name || email}
              {role && <span style={{ marginLeft: 8, opacity: 0.7 }}>· {ROLE_LABEL[role] || role}</span>}
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setShowMyAccount(true)} style={btn}>My Account</button>
            <button onClick={logout} style={btn}>Logout</button>
          </div>
        </header>

        {showMyAccount && <MyAccountModal onClose={() => setShowMyAccount(false)} />}

        <div style={{ marginBottom: 20 }}>
          {TAB_GROUPS.map((group) => {
            const groupTabs = group.ids
              .map((id) => TOP_TABS.find((t) => t.id === id))
              .filter((t): t is (typeof TOP_TABS)[number] => Boolean(t));
            if (!groupTabs.length) return null;
            return (
              <div key={group.label} style={{ marginBottom: 10 }}>
                <div
                  style={{
                    fontSize: 11,
                    fontWeight: 700,
                    letterSpacing: '0.06em',
                    textTransform: 'uppercase',
                    color: 'var(--muted)',
                    marginBottom: 6,
                  }}
                >
                  {group.label}
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {groupTabs.map((t) => (
                    <button key={t.id} type="button" style={tabBtn(tab === t.id)} onClick={() => setTab(t.id)}>
                      {t.label}
                      {!!t.badge && (
                        <span
                          style={{
                            marginLeft: 8,
                            background: 'var(--ember)',
                            color: 'var(--text-on-accent)',
                            borderRadius: 999,
                            padding: '1px 7px',
                            fontSize: 11.5,
                            fontWeight: 800,
                          }}
                        >
                          {t.badge}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {tab === 'overview' && (
          <OverviewTab token={token} analytics={analytics} analyticsLoading={analyticsLoading} reloadAnalytics={reloadAnalytics} />
        )}
        {tab === 'orders' && <OrdersTab token={token} />}
        {tab === 'menu' && <MenuTabs token={token} initialTab={searchParams.get('menuTab')} />}
        {tab === 'menu_availability' && <MenuAvailabilityTab token={token} />}
        {tab === 'rewards' && <RewardsTab token={token} />}
        {tab === 'coupons' && <CouponsTab token={token} />}
        {tab === 'homepage' && <HomepageDisplaySettings token={token} />}
        {tab === 'customers' && <CustomersTab token={token} onNavigateToRewards={() => setTab('rewards')} />}
        {tab === 'customer_source' && <CustomerSourceTab token={token} />}
        {tab === 'reports' && <ReportsTab analytics={analytics} loading={analyticsLoading} />}
        {tab === 'tracking' && <TrackingAnalyticsSettings token={token} />}
        {tab === 'settings' && <SettingsTab token={token} />}
        {tab === 'staff' && <StaffManagementTab token={token} />}
        {tab === 'activity' && <ActivityLogTab token={token} />}
      </div>
    </main>
  );
}
