import { getCloudflareContext } from '@opennextjs/cloudflare';
import { json } from '@/lib/api-helpers';
import { requireRole, getSession } from '@/lib/adminAuth';
import { logActivity } from '@/lib/auditLog';
import { trackRefundServerSide } from '@/lib/server-tracking';
import { sendEmailSafe, getAdminNotificationEmail } from '@/lib/email';
import { orderStatusCustomerEmail, cancellationAdminEmail, type CustomerFacingStatus } from '@/lib/email-templates';
import type { StaffRole, OrderStatus, OrderRow } from '@/lib/types';

export const dynamic = 'force-dynamic';

// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 4 — 'staff'
// gets the same order access as 'kitchen' here too (view + advance/cancel
// status — no pricing/refund fields are touched by this route).
const ORDER_ROLES: StaffRole[] = ['kitchen', 'staff', 'manager', 'owner'];

interface PatchOrderBody {
  status?: unknown;
  estimated_minutes?: unknown;
  driver_name?: unknown;
}

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { env } = await getCloudflareContext({ async: true });
  const denied = await requireRole(request, env, ORDER_ROLES);
  if (denied) return denied;

  const { id } = await params;
  const order = await env.DB.prepare('SELECT * FROM orders WHERE id = ?').bind(id).first();
  if (!order) return json({ error: 'Not found' }, 404);

  const items = await env.DB.prepare('SELECT * FROM order_items WHERE order_id = ?').bind(id).all();

  return json({ ...order, items: items.results });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { env, ctx } = await getCloudflareContext({ async: true });
  const denied = await requireRole(request, env, ORDER_ROLES);
  if (denied) return denied;

  const { id } = await params;

  const body = (await request.json().catch(() => ({}))) as PatchOrderBody;
  // Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 —
  // 'accepted'/'ready' are now valid transitions too (see lib/types.ts's
  // OrderStatus).
  const allowed: OrderStatus[] = ['received', 'accepted', 'preparing', 'ready', 'on_the_way', 'delivered', 'cancelled'];

  if (!allowed.includes(body.status as OrderStatus)) {
    return json({ error: 'Invalid status' }, 400);
  }

  // Both extra fields below are optional add-ons to the same status-change
  // PATCH (matches the existing ETA pattern) rather than separate
  // endpoints — the Kanban board already calls this one PATCH per move.
  const sets = ['status = ?'];
  const values: unknown[] = [body.status];
  let noteSuffix = '';

  // Optional: when accepting an order (moving it to "preparing"), staff
  // can attach an ETA. Stored as an absolute timestamp so it stays
  // correct however long the customer waits before checking /track.
  const minutes = Number(body.estimated_minutes);
  if (Number.isFinite(minutes) && minutes > 0) {
    const eta = new Date(Date.now() + minutes * 60000).toISOString();
    sets.push('estimated_ready_at = ?');
    values.push(eta);
    noteSuffix += ` (ETA ${minutes} min)`;
  }

  // Optional: when sending an order out ("on_the_way"), staff can note
  // who's delivering it (Phase 7.1). Free-text, matches the ETA prompt's
  // UX pattern — see components/admin/OrderKanban.js's DriverPromptModal.
  // Skippable (the Kanban UI has a "send without a driver" option), so
  // only touch the column when a non-empty name was actually sent.
  const driverName = typeof body.driver_name === 'string' ? body.driver_name.trim() : '';
  if (driverName) {
    sets.push('driver_name = ?');
    values.push(driverName);
    noteSuffix += ` (driver: ${driverName})`;
  }

  values.push(id);
  await env.DB.prepare(`UPDATE orders SET ${sets.join(', ')} WHERE id = ?`).bind(...values).run();
  const etaNote = noteSuffix;

  // Fetched once, reused for both the audit log entry (needs order_num)
  // and the cancellation-tracking branch below (needs total/email/phone)
  // — avoids a second identical SELECT.
  const order = await env.DB.prepare('SELECT * FROM orders WHERE id = ?').bind(id).first<OrderRow>();

  const session = await getSession(request, env);
  ctx.waitUntil(
    logActivity(env, session, 'order.status_changed', `Order ${order?.order_num || id} → ${body.status}${etaNote}`)
  );

  // Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 1 — order-
  // status-change emails. Customer-facing for the four statuses the
  // brief names ("preparing, ready, dispatched/picked-up, completed" —
  // i.e. CustomerFacingStatus below); 'received'/'accepted' have nothing
  // new to tell the customer beyond the "order received" email already
  // sent at creation, and 'cancelled' is deliberately admin-only (see
  // cancellationAdminEmail below) rather than also emailing the customer
  // — a scope decision, not an oversight; flagged in this task's delivery
  // report. Fire-and-forget, same reasoning as every other email call
  // site — never lets a slow/failed send delay this admin action.
  const CUSTOMER_FACING_STATUSES: CustomerFacingStatus[] = ['preparing', 'ready', 'on_the_way', 'delivered'];
  if (order) {
    if (CUSTOMER_FACING_STATUSES.includes(body.status as CustomerFacingStatus)) {
      ctx.waitUntil(
        (async () => {
          try {
            await sendEmailSafe(
              env,
              orderStatusCustomerEmail({
                orderNum: order.order_num,
                email: order.email,
                status: body.status as CustomerFacingStatus,
                orderType: order.order_type || 'delivery',
                locale: order.locale === 'fi' ? 'fi' : 'en',
                estimatedReadyAt: order.estimated_ready_at,
                driverName: order.driver_name,
              })
            );
          } catch (err) {
            console.error('[email] order-status notification failed:', err);
          }
        })()
      );
    } else if (body.status === 'cancelled') {
      ctx.waitUntil(
        (async () => {
          try {
            const adminEmail = await getAdminNotificationEmail(env);
            if (adminEmail) {
              await sendEmailSafe(
                env,
                cancellationAdminEmail({ adminEmail, orderNum: order.order_num, customerName: order.customer_name })
              );
            }
          } catch (err) {
            console.error('[email] cancellation notification failed:', err);
          }
        })()
      );
    }
  }

  // Tell the ad platforms this order didn't actually happen, so revenue
  // reports and campaign optimization don't count it — see the "Refund
  // tracking" note in the roadmap for why this can only be done
  // server-side. Safely does nothing until ad-account secrets exist.
  // Gated on the SAME consent choice stored on the order at checkout
  // time (order.marketing_consent) — if the customer hadn't consented
  // to marketing/analytics cookies, their order was never sent to these
  // platforms in the first place, so there's nothing to "un-send" here
  // either; firing a refund event for an order that was never tracked
  // would be meaningless (and would itself be a new, separate send of
  // their data without consent).
  if (body.status === 'cancelled' && order && order.marketing_consent) {
    ctx.waitUntil(
      trackRefundServerSide(
        env,
        { orderNum: order.order_num, total: order.total, email: order.email, phone: order.phone },
        request
      )
    );
  }

  return json({ ok: true });
}
