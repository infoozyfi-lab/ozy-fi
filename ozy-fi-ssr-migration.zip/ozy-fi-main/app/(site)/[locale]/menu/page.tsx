import { getCloudflareContext } from '@opennextjs/cloudflare';
import MenuPageClient from '@/components/MenuPageClient';
import { loadMenuData } from '@/lib/menu-data';
import { hreflangAlternates } from '@/lib/i18n/locales';
import type { StoreProviderInitialData } from '@/context/StoreContext';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const title = locale === 'fi'
    ? 'Koko ruokalista — Pizzaa, kebabia ja hampurilaisia | ozy.fi'
    : 'Full Menu — Pizza, Kebab & Burgers | ozy.fi';
  const description = locale === 'fi'
    ? 'Selaa koko ozy.fi-ruokalistaa — pizzaa, kebabia, hampurilaisia, salaatteja ja juomia. Tilaa verkosta kotiinkuljetuksena tai noutona.'
    : 'Browse the full ozy.fi menu — pizza, kebab, burgers, salads, drinks and more. Order online for delivery or pickup.';

  return {
    title,
    description,
    alternates: {
      canonical: `/${locale}/menu`,
      languages: hreflangAlternates('/menu'),
    },
    openGraph: { title, description, url: `https://ozy.fi/${locale}/menu`, locale: locale === 'fi' ? 'fi_FI' : 'en_US', type: 'website' },
    // Priority-fixes brief, Part 6 — Twitter/X Card metadata, reusing
    // the same title/description already computed above.
    twitter: { card: 'summary', title, description },
  };
}

export default async function MenuPage({ params }: { params: Promise<{ locale: string }> }) {
  // See app/(site)/[locale]/page.js for why this is wrapped — same fix,
  // same reasoning (bug-fix, bilingual-site crash, Sept 2026).
  const { locale } = await params;
  let initialData: StoreProviderInitialData | null = null;
  try {
    const { env } = await getCloudflareContext({ async: true });
    initialData = await loadMenuData(env);
  } catch (err) {
    console.error(`[/${locale}/menu] failed to load SSR menu data:`, err);
  }

  return <MenuPageClient initialData={initialData} />;
}
