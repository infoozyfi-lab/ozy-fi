'use client';

import { useEffect, useMemo, useRef, useState, type MouseEvent, type ChangeEvent } from 'react';
import { formatCurrency } from '@/components/admin/charts/colors';
import PaymentStatusPill from '@/components/admin/charts/PaymentStatusPill';
import ConfirmDialog from '@/components/admin/ConfirmDialog';
import type { OrderRow, OrderItemRow, OrderStatus, OrderType } from '@/lib/types';

interface KanbanColumn {
  status: OrderStatus;
  title: string;
  next: OrderStatus | null;
  nextLabel: string | null;
}

// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 —
// 'accepted' (between received/preparing) and 'ready' (between
// preparing/on_the_way) are new columns. Additive to the existing 4-stage
// board rather than a restructure — every order (delivery or pickup)
// still moves through the same shared sequence, just with two more real
// stages than before; see nextLabelFor below for how 'ready' reads
// differently per order type (the brief's explicit ask), coordinated
// with the round-2 pickup work's existing pattern of relabeling rather
// than branching the pipeline itself.
const COLUMNS: KanbanColumn[] = [
  { status: 'received', title: 'New', next: 'accepted', nextLabel: 'Accept order →' },
  { status: 'accepted', title: 'Accepted', next: 'preparing', nextLabel: 'Start preparing →' },
  { status: 'preparing', title: 'Preparing', next: 'ready', nextLabel: 'Mark ready →' },
  { status: 'ready', title: 'Ready', next: 'on_the_way', nextLabel: 'Send out →' },
  { status: 'on_the_way', title: 'Out for delivery', next: 'delivered', nextLabel: 'Mark delivered →' },
  { status: 'delivered', title: 'Delivered', next: null, nextLabel: null },
];

// Round-2 fixes brief, Part 5 — the shared COLUMNS array's static
// nextLabel ("Send out →", "Mark delivered →") assumes every order is a
// delivery. Rather than restructuring COLUMNS/OrderStatus for pickup (out
// of this part's explicit scope — see the brief's own wording: "add a
// clear, distinct badge/treatment... so staff immediately know not to
// dispatch a driver"), this just swaps in pickup-appropriate button text
// for the two transitions where the delivery-specific wording would
// actively mislead kitchen staff. Every other column's label (e.g. "Start
// preparing →") already reads fine for either type. Module-level (not a
// component-local function) so both OrderDetailModal and the main
// component's own compact-card grid can share it.
//
// Priority-fixes brief, Bundle 1 Task 3 — the two pickup-aware overrides
// moved down one stage each (from preparing/on_the_way to preparing/ready)
// now that 'ready' is a real status of its own: "ready for pickup" is
// exactly what the new 'ready' stage means for a pickup order, so that's
// where the override now lives; 'on_the_way' keeps its "Mark picked up"
// wording for pickup, now describing the ready -> on_the_way move instead
// of preparing -> on_the_way. The final on_the_way -> delivered step is
// left as the shared "Mark delivered →" for both types, same as before
// this task — a purely administrative close-out once a pickup customer
// has already collected their order (see components/TrackPageClient.tsx's
// OrderTimeline for how that reads on the customer-facing side).
function nextLabelFor(order: { order_type?: OrderType }, col: KanbanColumn): string | null {
  if (order.order_type === 'pickup') {
    if (col.status === 'preparing') return 'Mark ready for pickup →';
    if (col.status === 'ready') return 'Mark picked up →';
  }
  return col.nextLabel;
}

const POLL_MS = 15000;

function minutesAgo(createdAt: string): number {
  // D1's CURRENT_TIMESTAMP is UTC without a "Z" suffix — without it, Safari/JS
  // parses the string as local time and gets the age wrong by several hours.
  const iso = createdAt.includes('T') ? createdAt : `${createdAt.replace(' ', 'T')}Z`;
  const ms = Date.now() - new Date(iso).getTime();
  return Math.max(0, Math.floor(ms / 60000));
}

// These are solid badge FILL colors paired with light (--text-on-accent)
// text, same pairing convention as the ember buttons — not the same
// tokens used for plain danger/gold/success TEXT elsewhere in admin,
// which were darkened specifically for legibility as text on a light
// background and would be too dark to use as a badge fill here.
function ageColor(mins: number): string {
  if (mins >= 20) return 'var(--danger)';
  if (mins >= 10) return 'var(--gold)';
  return 'var(--success)';
}

// Part C (admin-initiated refunds) — shared eligibility/remaining-balance
// logic, used by both the detail popup here and app/admin/dashboard/
// page.tsx's OrderDetailRow so the two views can't drift on when a
// "Refund" action is even shown. A card order can be refunded once Stripe
// has actually confirmed the charge ('paid') or after an earlier partial
// refund ('partially_refunded') — never a 'pending'/'failed'/'cod' status,
// and never once it's already fully 'refunded'. A COD order never touches
// Stripe (see the refund route's own comment), so its only requirement is
// "not already marked fully refunded".
// Exported (not just module-private) so app/admin/dashboard/page.tsx's
// OrderDetailRow — the list view's equivalent of this file's detail popup —
// can gate its own "Refund" button on the exact same logic, rather than a
// hand-copied second version that could quietly drift from this one.
// Kitchen-queue safety brief — a card order starts life with
// payment_status 'pending' the instant it's created (before Stripe's
// webhook confirms the charge — see app/api/orders/route.ts), and flips
// to 'failed' if the card is declined. Until (and unless) it reaches
// 'paid', kitchen staff moving quickly through this board could easily
// miss the small PaymentStatusPill badge and prepare/dispatch food that
// was never actually paid for. A COD order's own payment_status values
// ('cod', or 'refunded'/'partially_refunded' after the fact) are a
// completely different, legitimate case — a COD order is never
// "unconfirmed", the customer just hasn't paid yet in person — so this
// is deliberately scoped to `payment_method === 'card'` only.
// Exported so this is the one place that decision lives — nothing else
// (the separate all-orders list view in app/admin/dashboard/page.tsx, the
// invoice page, analytics) reads this at all, and none of them should:
// this is specifically about which orders are safe to hand to the
// kitchen, not a blanket "hide unpaid orders everywhere" rule.
export function isAwaitingOrFailedPayment(order: Pick<OrderRow, 'payment_method' | 'payment_status'>): boolean {
  return order.payment_method === 'card' && (order.payment_status === 'pending' || order.payment_status === 'failed');
}

export function isRefundEligible(order: OrderRow): boolean {
  if (order.payment_method === 'card') {
    return order.payment_status === 'paid' || order.payment_status === 'partially_refunded';
  }
  return order.payment_status !== 'refunded';
}

export function refundRemaining(order: OrderRow): number {
  const already = Number(order.refunded_amount) || 0;
  return Math.max(0, Math.round((Number(order.total) - already) * 100) / 100);
}

// The admin order-detail fetch (/api/admin/orders/:id) returns the order row
// plus its line items — a narrower shape than the full OrderRow (only the
// fields this modal actually displays).
interface OrderDetail {
  customer_name: string;
  phone: string;
  address: string;
  payment_method: string;
  // Present on the real API response (SELECT * FROM orders — see
  // app/api/admin/orders/[id]/route.ts) but declared optional here for the
  // same reason as OrderRow.payment_status in lib/types.ts.
  payment_status?: string;
  notes?: string | null;
  driver_name?: string | null;
  items: OrderItemRow[];
  // Round-2 fixes brief, Part 5 — same optional-for-pre-migration-rows
  // reasoning as OrderRow.order_type. Absent/undefined is treated as
  // 'delivery' everywhere this is read below, same as that column's own
  // DB-level default.
  order_type?: OrderType;
}

function OrderDetailModal({
  token,
  order,
  onClose,
  onAdvance,
  onCancel,
  onRefund,
  movingId,
}: {
  token: string | null;
  order: OrderRow;
  onClose: () => void;
  onAdvance: (order: OrderRow, next: OrderStatus) => void;
  onCancel: (order: OrderRow) => void;
  onRefund: (order: OrderRow) => void;
  movingId: number | null;
}) {
  const [detail, setDetail] = useState<OrderDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/admin/orders/${order.id}`)
      .then((r) => r.json())
      .then((d) => { if (!cancelled) setDetail(d as OrderDetail); })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [token, order.id]);

  const col = COLUMNS.find((c) => c.status === order.status);
  // Captured as a plain local rather than read as `col.next` inside the
  // onClick below — a nested closure doesn't reliably keep TypeScript's
  // narrowing of an *optional property read*, only of a plain const like
  // this one. Same truth value as the original `col && col.next` check.
  const nextStatus = col?.next ?? null;
  const mins = minutesAgo(order.created_at);

  return (
    <div
      role="dialog"
      aria-label={`Order ${order.order_num}`}
      style={{
        position: 'fixed', inset: 0, zIndex: 900, background: 'rgba(10,6,4,0.85)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
      onClick={onClose}
    >
      <div
        onClick={(e: MouseEvent<HTMLDivElement>) => e.stopPropagation()}
        style={{
          background: 'var(--bg-card)', width: '100%', maxWidth: 560, maxHeight: '88vh', overflowY: 'auto',
          borderRadius: '16px 16px 0 0', border: '1px solid var(--line)', borderBottom: 'none',
          padding: '20px 18px 28px',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
          <div>
            <h2 style={{ margin: 0, fontSize: 22 }}>{order.order_num}</h2>
            <span
              style={{
                display: 'inline-block', marginTop: 6, fontSize: 12, fontWeight: 700, color: 'var(--text-on-accent)',
                background: ageColor(mins), borderRadius: 999, padding: '3px 10px',
              }}
            >
              {mins} min ago
            </span>
          </div>
          <button type="button" onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--muted)', fontSize: 28, lineHeight: 1, cursor: 'pointer', padding: 4 }}>
            ×
          </button>
        </div>

        {loading ? (
          <p style={{ marginTop: 20 }}>Loading order details…</p>
        ) : !detail ? (
          <p style={{ marginTop: 20 }}>Could not load order details.</p>
        ) : (
          <>
            <div style={{ marginTop: 18, padding: 14, background: 'var(--bg-alt)', borderRadius: 10 }}>
              <p style={{ margin: '0 0 4px', color: 'var(--muted)', fontSize: 12 }}>CUSTOMER</p>
              <p style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>{detail.customer_name}</p>
              <p style={{ margin: '6px 0 0', fontSize: 16 }}>📞 {detail.phone}</p>
              {/* Round-2 fixes brief, Part 5 — detail.address is a
                  sentinel string for a pickup order (never a real
                  address — see app/api/orders/route.ts's
                  PICKUP_ADDRESS_SENTINEL), so it's replaced entirely with
                  a clear, differently-colored/iconed badge rather than
                  ever printing that sentinel text to staff. This is the
                  primary identifying detail on the card, same as the
                  brief's own wording ("so staff immediately know not to
                  dispatch a driver"). */}
              {detail.order_type === 'pickup' ? (
                <p style={{ margin: '4px 0 0', fontSize: 15, fontWeight: 700, color: 'var(--gold)' }}>🏪 Pickup — no delivery</p>
              ) : (
                <p style={{ margin: '4px 0 0', fontSize: 15, color: 'var(--cream)' }}>📍 {detail.address}</p>
              )}
              <p style={{ margin: '10px 0 0', fontSize: 14, display: 'flex', alignItems: 'center', gap: 8 }}>
                Payment: {detail.payment_method} <PaymentStatusPill status={detail.payment_status} />
              </p>
              {detail.notes && (
                <p style={{ margin: '10px 0 0', fontSize: 14, color: 'var(--gold)' }}>📝 {detail.notes}</p>
              )}
              {detail.driver_name && (
                <p style={{ margin: '10px 0 0', fontSize: 14 }}>🛵 Driver: <strong>{detail.driver_name}</strong></p>
              )}
            </div>

            <div style={{ marginTop: 18 }}>
              <p style={{ margin: '0 0 8px', color: 'var(--muted)', fontSize: 12 }}>ITEMS</p>
              {(detail.items || []).map((item) => (
                <div key={item.id} style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 16 }}>
                    <strong>{item.qty}× {item.name}</strong>
                    <span>{formatCurrency(item.line_total)}</span>
                  </div>
                  {item.details && (() => {
                    try {
                      const d = JSON.parse(item.details);
                      return d.length ? <div style={{ color: 'var(--muted)', fontSize: 13, marginTop: 3 }}>{d.join(', ')}</div> : null;
                    } catch {
                      return null;
                    }
                  })()}
                </div>
              ))}
              <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 12, fontSize: 18, fontWeight: 700 }}>
                <span>Total</span>
                <span>{formatCurrency(order.total)}</span>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, marginTop: 22, flexWrap: 'wrap' }}>
              <a
                href={`/admin/orders/${order.id}/invoice`}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  background: 'none', color: 'var(--cream)', border: '1px solid var(--line)', textDecoration: 'none',
                  borderRadius: 10, padding: '14px 16px', fontSize: 14, cursor: 'pointer', display: 'inline-block',
                }}
              >
                View invoice ↗
              </a>
              {col && nextStatus && (
                <button
                  type="button"
                  disabled={movingId === order.id}
                  onClick={() => onAdvance(order, nextStatus)}
                  style={{
                    flex: 1, background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none',
                    borderRadius: 10, padding: '14px', fontSize: 15, fontWeight: 700, cursor: 'pointer',
                  }}
                >
                  {movingId === order.id ? 'Updating…' : nextLabelFor(order, col)}
                </button>
              )}
              {order.status !== 'delivered' && order.status !== 'cancelled' && (
                <button
                  type="button"
                  disabled={movingId === order.id}
                  onClick={() => onCancel(order)}
                  style={{
                    background: 'none', color: 'var(--danger)', border: '1px solid var(--danger-border)',
                    borderRadius: 10, padding: '14px 16px', fontSize: 14, cursor: 'pointer',
                  }}
                >
                  Cancel order
                </button>
              )}
              {isRefundEligible(order) && (
                <button
                  type="button"
                  disabled={movingId === order.id}
                  onClick={() => onRefund(order)}
                  style={{
                    background: 'none', color: 'var(--cream)', border: '1px solid var(--line)',
                    borderRadius: 10, padding: '14px 16px', fontSize: 14, cursor: 'pointer',
                  }}
                >
                  Refund
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function EtaPromptModal({
  token,
  order,
  onConfirm,
  onClose,
}: {
  token: string | null;
  order: OrderRow;
  onConfirm: (minutes: number) => void;
  onClose: () => void;
}) {
  const [custom, setCustom] = useState('');
  const [items, setItems] = useState<OrderItemRow[] | null>(null);
  const [loadingItems, setLoadingItems] = useState(true);
  const presets = [15, 20, 25, 30, 45];

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/admin/orders/${order.id}`)
      .then((r) => r.json())
      .then((d) => { if (!cancelled) setItems((d as { items?: OrderItemRow[] }).items || []); })
      .catch(() => {})
      .finally(() => { if (!cancelled) setLoadingItems(false); });
    return () => { cancelled = true; };
  }, [token, order.id]);

  return (
    <div
      role="dialog"
      aria-label="How long will this take?"
      style={{ position: 'fixed', inset: 0, zIndex: 950, background: 'rgba(10,6,4,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={onClose}
    >
      <div
        onClick={(e: MouseEvent<HTMLDivElement>) => e.stopPropagation()}
        style={{ background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 14, padding: 22, width: '100%', maxWidth: 380, maxHeight: '85vh', overflowY: 'auto' }}
      >
        {/* Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 —
            was "Accept {order.order_num}" before 'accepted' existed as its
            own real, earlier stage (see the new received -> accepted
            column above) — this modal now fires one stage later, when
            staff actually start cooking. */}
        <h3 style={{ margin: '0 0 4px' }}>Start preparing {order.order_num}</h3>

        <div style={{ margin: '12px 0 16px', padding: 12, background: 'var(--bg-alt)', borderRadius: 8 }}>
          {loadingItems ? (
            <p style={{ margin: 0, fontSize: 13, color: 'var(--muted)' }}>Loading order items…</p>
          ) : items && items.length > 0 ? (
            items.map((item) => (
              <div key={item.id} style={{ fontSize: 14, padding: '4px 0' }}>
                <strong>{item.qty}×</strong> {item.name}
              </div>
            ))
          ) : (
            <p style={{ margin: 0, fontSize: 13, color: 'var(--muted)' }}>Could not load items.</p>
          )}
        </div>

        <p style={{ margin: '0 0 16px', color: 'var(--muted)', fontSize: 14 }}>How long will this take?</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 14 }}>
          {presets.map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => onConfirm(m)}
              style={{ background: 'var(--bg-alt)', color: 'var(--cream)', border: '1px solid var(--line)', borderRadius: 8, padding: '12px 6px', fontSize: 15, fontWeight: 700, cursor: 'pointer' }}
            >
              {m} min
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <input
            type="number"
            min="1"
            placeholder="Custom minutes"
            value={custom}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setCustom(e.target.value)}
            style={{ flex: 1, padding: 12, border: '1px solid var(--line)', borderRadius: 8, background: 'var(--bg-alt)', color: 'var(--cream)', fontSize: 15 }}
          />
          <button
            type="button"
            disabled={!custom || Number(custom) <= 0}
            onClick={() => onConfirm(Number(custom))}
            style={{ background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none', borderRadius: 8, padding: '12px 18px', fontWeight: 700, cursor: 'pointer' }}
          >
            Confirm
          </button>
        </div>

        <button type="button" onClick={onClose} style={{ marginTop: 14, background: 'none', border: 'none', color: 'var(--muted)', textDecoration: 'underline', fontSize: 13, cursor: 'pointer', padding: 0 }}>
          Cancel
        </button>
      </div>
    </div>
  );
}

// Phase 7.1 — shown when sending an order out ("on_the_way"), mirroring
// EtaPromptModal's UX above (same overlay/card shape, same "quick presets
// + free entry" pattern — recent driver names instead of minute presets).
// Skippable: nobody's forced to name a driver before the order can move,
// since a small team might not always have that info handy at send-out
// time.
function DriverPromptModal({
  order,
  recentDrivers,
  onConfirm,
  onSkip,
  onClose,
}: {
  order: OrderRow;
  recentDrivers: string[];
  onConfirm: (name: string) => void;
  onSkip: () => void;
  onClose: () => void;
}) {
  const [name, setName] = useState('');

  return (
    <div
      role="dialog"
      aria-label="Who's delivering this?"
      style={{ position: 'fixed', inset: 0, zIndex: 950, background: 'rgba(10,6,4,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={onClose}
    >
      <div
        onClick={(e: MouseEvent<HTMLDivElement>) => e.stopPropagation()}
        style={{ background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 14, padding: 22, width: '100%', maxWidth: 380, maxHeight: '85vh', overflowY: 'auto' }}
      >
        <h3 style={{ margin: '0 0 4px' }}>Send out {order.order_num}</h3>
        <p style={{ margin: '0 0 16px', color: 'var(--muted)', fontSize: 14 }}>Who's delivering this?</p>

        {recentDrivers.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 14 }}>
            {recentDrivers.map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => onConfirm(d)}
                style={{ background: 'var(--bg-alt)', color: 'var(--cream)', border: '1px solid var(--line)', borderRadius: 999, padding: '8px 14px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}
              >
                {d}
              </button>
            ))}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8 }}>
          <input
            type="text"
            placeholder="Driver name"
            value={name}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
            style={{ flex: 1, padding: 12, border: '1px solid var(--line)', borderRadius: 8, background: 'var(--bg-alt)', color: 'var(--cream)', fontSize: 15 }}
          />
          <button
            type="button"
            disabled={!name.trim()}
            onClick={() => onConfirm(name.trim())}
            style={{ background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none', borderRadius: 8, padding: '12px 18px', fontWeight: 700, cursor: 'pointer' }}
          >
            Confirm
          </button>
        </div>

        <button type="button" onClick={onSkip} style={{ marginTop: 14, background: 'none', border: 'none', color: 'var(--muted)', textDecoration: 'underline', fontSize: 13, cursor: 'pointer', padding: 0 }}>
          Send without a driver
        </button>
      </div>
    </div>
  );
}

// Part C (admin-initiated refunds) — same overlay/card shape as
// EtaPromptModal/DriverPromptModal above. Offers a one-tap full refund
// (the common case) plus a free-entry partial amount, capped at what's
// actually left to refund (order.total minus anything already refunded —
// a second partial refund against the same order should never be able to
// request more than the remaining balance). For a card order this only
// ever CALLS the refund API — it never assumes success itself; the actual
// payment_status change comes back later via the Stripe webhook (see
// app/api/admin/orders/[id]/refund/route.ts's own comment). For a COD
// order there's no Stripe call at all, so the confirmation copy below
// reads differently for the two cases.
function RefundPromptModal({
  order,
  remaining,
  submitting,
  error,
  onConfirm,
  onClose,
}: {
  order: OrderRow;
  remaining: number;
  submitting: boolean;
  error: string;
  onConfirm: (amount?: number) => void;
  onClose: () => void;
}) {
  const [partial, setPartial] = useState('');
  const isCod = order.payment_method !== 'card';

  return (
    <div
      role="dialog"
      aria-label={`Refund ${order.order_num}`}
      style={{ position: 'fixed', inset: 0, zIndex: 950, background: 'rgba(10,6,4,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}
      onClick={submitting ? undefined : onClose}
    >
      <div
        onClick={(e: MouseEvent<HTMLDivElement>) => e.stopPropagation()}
        style={{ background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 14, padding: 22, width: '100%', maxWidth: 380, maxHeight: '85vh', overflowY: 'auto' }}
      >
        <h3 style={{ margin: '0 0 4px' }}>Refund {order.order_num}</h3>
        <p style={{ margin: '0 0 16px', color: 'var(--muted)', fontSize: 14 }}>
          {isCod
            ? `This marks up to ${formatCurrency(remaining)} as refunded. No Stripe charge exists for a cash-on-delivery order, so nothing is actually processed here — it's a record-keeping marker only.`
            : `Refunds through Stripe. Up to ${formatCurrency(remaining)} can still be refunded on this order. The payment status here will update once Stripe confirms the refund.`}
        </p>

        <button
          type="button"
          disabled={submitting}
          onClick={() => onConfirm(undefined)}
          style={{
            width: '100%', background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none',
            borderRadius: 8, padding: '14px', fontSize: 15, fontWeight: 700, cursor: 'pointer', marginBottom: 14,
          }}
        >
          {submitting ? 'Processing…' : `Refund full amount (${formatCurrency(remaining)})`}
        </button>

        <p style={{ margin: '0 0 8px', color: 'var(--muted)', fontSize: 13 }}>Or refund a specific amount:</p>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            type="number"
            min="0.01"
            max={remaining}
            step="0.01"
            placeholder={`Up to ${remaining.toFixed(2)}`}
            value={partial}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setPartial(e.target.value)}
            style={{ flex: 1, padding: 12, border: '1px solid var(--line)', borderRadius: 8, background: 'var(--bg-alt)', color: 'var(--cream)', fontSize: 15 }}
          />
          <button
            type="button"
            disabled={submitting || !partial || Number(partial) <= 0 || Number(partial) > remaining}
            onClick={() => onConfirm(Number(partial))}
            style={{ background: 'var(--bg-alt)', color: 'var(--cream)', border: '1px solid var(--line)', borderRadius: 8, padding: '12px 18px', fontWeight: 700, cursor: 'pointer' }}
          >
            Refund amount
          </button>
        </div>

        {error && <p style={{ marginTop: 12, color: 'var(--danger)', fontSize: 13 }}>{error}</p>}

        <button type="button" disabled={submitting} onClick={onClose} style={{ marginTop: 16, background: 'none', border: 'none', color: 'var(--muted)', textDecoration: 'underline', fontSize: 13, cursor: 'pointer', padding: 0 }}>
          Cancel
        </button>
      </div>
    </div>
  );
}

export default function OrderKanban({ token, size = 'normal' }: { token: string | null; size?: 'normal' | 'large' }) {
  const large = size === 'large';
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [movingId, setMovingId] = useState<number | null>(null);
  const [viewingOrder, setViewingOrder] = useState<OrderRow | null>(null);
  const [etaOrder, setEtaOrder] = useState<OrderRow | null>(null); // order currently being accepted (ETA prompt open)
  const [driverOrder, setDriverOrder] = useState<OrderRow | null>(null); // order currently being sent out (driver prompt open)
  const [refundOrder, setRefundOrder] = useState<OrderRow | null>(null); // Part C — order currently being refunded (refund prompt open)
  // Audit-fixes brief, Part 6.7 — order currently awaiting a Cancel
  // confirmation via ConfirmDialog (replaces window.confirm() below).
  const [pendingCancel, setPendingCancel] = useState<OrderRow | null>(null);
  const [refundSubmitting, setRefundSubmitting] = useState(false);
  const [refundError, setRefundError] = useState('');
  const [soundOn, setSoundOn] = useState(true);
  const [soundUnlocked, setSoundUnlocked] = useState(false);
  const [showCancelled, setShowCancelled] = useState(false);
  // Kitchen-queue safety brief — starts OPEN (unlike showCancelled above),
  // not collapsed: a cancelled order is just historical clutter, but an
  // order awaiting/failed payment is exactly the case a busy kitchen
  // could otherwise miss entirely, so it's shown expanded by default and
  // only collapses if staff choose to.
  const [showAwaitingPayment, setShowAwaitingPayment] = useState(true);
  const [flash, setFlash] = useState(false);
  const [, forceTick] = useState(0);

  const seenIds = useRef<Set<number> | null>(null); // null until first load completes
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Re-render every 30s just to keep the age badges/colors moving forward
  // even when no new order has arrived.
  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    // `token` is kept as a plain "are we ready to load yet" flag from the
    // parent (AdminDashboard / KitchenPage) — as of phase 5b it's not a
    // real secret and isn't sent anywhere; every fetch() below relies on
    // the httpOnly admin cookie instead, sent automatically same-origin.
    if (!token) return undefined;

    let cancelled = false;

    const load = async () => {
      try {
        const res = await fetch('/api/admin/orders');
        const data = await res.json();
        if (cancelled || !Array.isArray(data)) return;

        if (seenIds.current === null) {
          // First load — just remember what's already there, don't alert.
          seenIds.current = new Set(data.map((o: OrderRow) => o.id));
        } else {
          // Captured to a local const: a property read like `seenIds.current`
          // doesn't reliably keep its non-null narrowing inside the nested
          // closure passed to filter() below, even though it's already been
          // checked non-null on this branch.
          const seen = seenIds.current;
          const newOnes = data.filter((o: OrderRow) => !seen.has(o.id));
          if (newOnes.length > 0) {
            seenIds.current = new Set(data.map((o: OrderRow) => o.id));
            setFlash(true);
            setTimeout(() => setFlash(false), 4000);
          }
        }

        setOrders(data);
      } catch {
        // Keep showing the last good list rather than clearing it on a
        // transient network hiccup.
      } finally {
        setLoading(false);
      }
    };

    load();
    const interval = setInterval(load, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [token]);

  // Sound keeps looping for as long as there's at least one order sitting
  // in "New" (unaccepted) — not just a one-off ping — so a busy kitchen
  // can't miss it. Stops the moment every new order has been accepted.
  const pendingCount = orders.filter((o) => o.status === 'received').length;
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.loop = true;
    if (soundOn && soundUnlocked && pendingCount > 0) {
      audio.currentTime = 0;
      audio.play().catch(() => {
        // Still blocked for some reason — the visual flash still works.
      });
    } else {
      audio.pause();
    }
  }, [soundOn, soundUnlocked, pendingCount]);

  // Browsers block audio.play() from firing on its own — it only works
  // right after a real tap/click. This one-time tap "unlocks" it for the
  // rest of the session, so the loop above can then start itself freely
  // whenever a new order actually arrives.
  const unlockSound = () => {
    const audio = audioRef.current;
    if (audio) {
      audio.play().then(() => {
        audio.pause();
        audio.currentTime = 0;
      }).catch(() => {});
    }
    setSoundUnlocked(true);
  };
  const advance = async (order: OrderRow, nextStatus: OrderStatus, etaMinutes?: number | null, driverName?: string | null) => {
    setMovingId(order.id);
    try {
      const body: { status: OrderStatus; estimated_minutes?: number; driver_name?: string } = { status: nextStatus };
      if (etaMinutes) body.estimated_minutes = etaMinutes;
      if (driverName) body.driver_name = driverName;
      await fetch(`/api/admin/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, status: nextStatus, ...(driverName ? { driver_name: driverName } : {}) } : o)));
      if (seenIds.current) seenIds.current.add(order.id);
    } finally {
      setMovingId(null);
    }
  };

  // Recently-used driver names (most recent first, deduped) — shown as
  // quick-pick buttons in DriverPromptModal so the same few drivers don't
  // need retyping order after order. Derived from whatever's already
  // loaded (no extra request).
  const recentDrivers = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    orders
      .slice()
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .forEach((o) => {
        if (o.driver_name && !seen.has(o.driver_name)) {
          seen.add(o.driver_name);
          out.push(o.driver_name);
        }
      });
    return out.slice(0, 6);
  }, [orders]);

  // "Start preparing" (accepted -> preparing) is when staff commit to
  // actually cooking the order — ask for an ETA first instead of advancing
  // immediately, so the customer can see it on /track. "Send out"
  // (ready -> on_the_way) similarly asks who's delivering (Phase 7.1) —
  // skippable, see DriverPromptModal. Any other column's "next" action
  // (including the new received -> accepted "Accept order" step) advances
  // right away with no prompt.
  //
  // Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 — both
  // prompts moved one stage later than before this task (previously
  // received -> preparing and preparing -> on_the_way) now that 'accepted'
  // and 'ready' sit in between. The ETA prompt now fires specifically when
  // cooking actually starts (a more accurate moment to estimate "how long
  // will this take" than the old received -> preparing jump, which used to
  // conflate "we've seen this order" with "we've started making it").
  const handleAdvanceClick = (order: OrderRow, nextStatus: OrderStatus) => {
    if (order.status === 'accepted' && nextStatus === 'preparing') {
      setEtaOrder(order);
    } else if (order.status === 'ready' && nextStatus === 'on_the_way' && order.order_type !== 'pickup') {
      // Round-2 fixes brief, Part 5 — "who's delivering this" makes no
      // sense for a pickup order (nobody is), so it skips straight to
      // `advance` below instead of opening DriverPromptModal. Deliberately
      // NOT restructuring the shared OrderStatus pipeline/COLUMNS array
      // itself for this — see this file's own delivery-report note — a
      // pickup order still moves through the same shared stages, just
      // under pickup-aware button labels (nextLabelFor below) and without
      // this one prompt.
      setDriverOrder(order);
    } else {
      advance(order, nextStatus);
    }
  };

  // Audit-fixes brief, Part 6.7 — window.confirm() replaced with
  // ConfirmDialog (rendered below, alongside this file's other prompt
  // modals). cancelOrder just opens it now — both call sites below
  // (the Kanban card's own Cancel button, and OrderDetailModal's onCancel)
  // go through this same function, so confirmCancelOrder is the one place
  // that actually does the PATCH, whichever button opened the dialog.
  const cancelOrder = (order: OrderRow) => {
    setPendingCancel(order);
  };

  const confirmCancelOrder = async () => {
    if (!pendingCancel) return;
    const order = pendingCancel;
    setMovingId(order.id);
    try {
      await fetch(`/api/admin/orders/${order.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'cancelled' }),
      });
      setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, status: 'cancelled' } : o)));
    } finally {
      setMovingId(null);
      setPendingCancel(null);
      // Closing the detail modal here (rather than in OrderDetailModal's
      // own onCancel) means it stays open, underneath the confirmation
      // dialog, until the admin actually confirms — canceling out of the
      // dialog leaves the detail modal open and untouched, same as
      // dismissing any other prompt in this file.
      setViewingOrder(null);
    }
  };

  // Part C (admin-initiated refunds) — calls the refund API and reflects
  // what it actually reported back, nothing more. For a COD order that's a
  // real, immediate payment_status change (the route writes it directly —
  // no Stripe involved to wait on). For a card order the route only ever
  // starts the Stripe refund; the real payment_status flip lands later via
  // the webhook (app/api/webhooks/stripe/route.ts's charge.refunded
  // branch) and shows up here on this board's own 15s poll — this handler
  // does NOT optimistically mark a card order refunded, since that would
  // be trusting the admin action succeeded instead of the webhook, exactly
  // what this project's brief says not to do.
  const submitRefund = async (order: OrderRow, amount?: number) => {
    setRefundSubmitting(true);
    setRefundError('');
    try {
      const res = await fetch(`/api/admin/orders/${order.id}/refund`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(amount ? { amount } : {}),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; paymentStatus?: string };
      if (!res.ok) {
        setRefundError(data.error || 'Refund failed.');
        return;
      }
      // The COD path returns the new status directly (no webhook to wait
      // on) — reflect it immediately. The card path doesn't return one on
      // purpose (see the comment above); that order's pill updates once
      // the next poll picks up the webhook's write.
      if (data.paymentStatus) {
        setOrders((list) => list.map((o) => (o.id === order.id ? { ...o, payment_status: data.paymentStatus } : o)));
      }
      setRefundOrder(null);
    } catch {
      setRefundError('Refund failed. Please try again.');
    } finally {
      setRefundSubmitting(false);
    }
  };

  // Kitchen-queue safety brief — pending/failed CARD orders are pulled out
  // of the normal active queue here, the same way cancelledOrders already
  // is below, so the columns above only ever show orders that are safe to
  // actually prepare. This is purely a client-side split of the same
  // polled `orders` array (see the 15s-poll `load()` effect above) — no
  // new endpoint, no new request — so the instant a 'pending' order's
  // webhook lands and the next poll picks up payment_status: 'paid', it
  // automatically stops matching isAwaitingOrFailedPayment and reappears
  // in the real queue below on its own, with no extra plumbing needed for
  // that transition.
  const activeOrders = orders.filter((o) => o.status !== 'cancelled' && !isAwaitingOrFailedPayment(o));
  const awaitingPaymentOrders = orders
    .filter((o) => o.status !== 'cancelled' && isAwaitingOrFailedPayment(o))
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  const awaitingPaymentCount = awaitingPaymentOrders.length;
  const cancelledOrders = orders
    .filter((o) => o.status === 'cancelled')
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  const cancelledCount = cancelledOrders.length;

  return (
    <div>
      {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
      <audio ref={audioRef} src="/notification.wav" preload="auto" />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: large ? 20 : 14, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ margin: 0, fontSize: large ? 28 : undefined }}>Orders {flash && <span style={{ color: 'var(--ember)' }}>● New!</span>}</h2>
        {!soundUnlocked ? (
          <button
            type="button"
            onClick={unlockSound}
            style={{
              background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none', borderRadius: 8,
              padding: large ? '12px 18px' : '8px 14px', fontSize: large ? 16 : 13, fontWeight: 700, cursor: 'pointer',
            }}
          >
            🔔 Tap to enable sound alerts
          </button>
        ) : (
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: large ? 16 : 13, color: 'var(--muted)' }}>
            <input type="checkbox" checked={soundOn} onChange={(e: ChangeEvent<HTMLInputElement>) => setSoundOn(e.target.checked)} style={large ? { width: 20, height: 20 } : undefined} />
            Sound alert for new orders
          </label>
        )}
      </div>

      {loading ? (
        <p>Loading orders…</p>
      ) : (
        <>
          {/* Kitchen-queue safety brief — placed ABOVE the real board
              (rather than tucked below it, like the cancelled-orders link
              further down) and expanded by default, specifically because
              this is the one section staff must not be able to scroll
              past without noticing. Visually de-emphasized from a real
              active card (muted warning tint, explicit "don't prepare"
              copy) so it never reads as "just another order to cook". */}
          {awaitingPaymentCount > 0 && (
            <div
              style={{
                marginBottom: large ? 20 : 14, border: '1px solid var(--gold)', borderRadius: 10,
                background: 'rgba(212, 165, 74, 0.08)', padding: large ? 14 : 10,
              }}
            >
              <button
                type="button"
                onClick={() => setShowAwaitingPayment((v) => !v)}
                style={{
                  background: 'none', border: 'none', color: 'var(--gold)', fontSize: large ? 16 : 13, fontWeight: 700,
                  cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 6, width: '100%', textAlign: 'left',
                }}
              >
                {showAwaitingPayment ? '▾' : '▸'} ⏳ {awaitingPaymentCount} order{awaitingPaymentCount === 1 ? '' : 's'} awaiting/failed payment — do not prepare
              </button>

              {showAwaitingPayment && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 10 }}>
                  {awaitingPaymentOrders.map((order) => {
                    const mins = minutesAgo(order.created_at);
                    return (
                      <button
                        key={order.id}
                        type="button"
                        onClick={() => setViewingOrder(order)}
                        style={{
                          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                          background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 8,
                          padding: large ? '12px 14px' : '10px 12px', cursor: 'pointer', textAlign: 'left', opacity: 0.85,
                        }}
                      >
                        <span>
                          <strong style={{ fontSize: large ? 16 : 13 }}>{order.order_num}</strong>
                          <span style={{ color: 'var(--muted)', fontSize: large ? 14 : 12, marginLeft: 8 }}>{order.customer_name}</span>
                          <span style={{ color: 'var(--muted)', fontSize: large ? 14 : 12, marginLeft: 8 }}>· {mins}m ago</span>
                        </span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <PaymentStatusPill status={order.payment_status} />
                          <span style={{ fontSize: large ? 14 : 13, color: 'var(--muted)' }}>{formatCurrency(order.total)}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: `repeat(auto-fit, minmax(${large ? 280 : 240}px, 1fr))`, gap: large ? 18 : 14 }}>
            {COLUMNS.map((col) => {
              const colOrders = activeOrders
                .filter((o) => o.status === col.status)
                .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
              // Same reasoning as OrderDetailModal above: captured to a plain
              // local so the onClick closures below keep the narrowing.
              const nextStatus = col.next;

              return (
                <div key={col.status} style={{ background: 'var(--bg-alt)', borderRadius: 10, border: '1px solid var(--line)', padding: large ? 16 : 12, minHeight: 120 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: large ? 14 : 10 }}>
                    <strong style={{ fontSize: large ? 20 : 14 }}>{col.title}</strong>
                    <span style={{ fontSize: large ? 16 : 12, color: 'var(--muted)', background: 'var(--bg)', borderRadius: 999, padding: large ? '4px 12px' : '2px 8px' }}>
                      {colOrders.length}
                    </span>
                  </div>

                  {colOrders.length === 0 && (
                    <p style={{ fontSize: large ? 16 : 13, color: 'var(--muted)', margin: 0 }}>Nothing here.</p>
                  )}

                  <div style={{ display: 'flex', flexDirection: 'column', gap: large ? 12 : 8 }}>
                    {colOrders.map((order) => {
                      const mins = minutesAgo(order.created_at);
                      return (
                        <div
                          key={order.id}
                          style={{ background: 'var(--bg-card)', border: '1px solid var(--line)', borderRadius: 8, padding: large ? 16 : 10 }}
                        >
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                            <button
                              type="button"
                              onClick={() => setViewingOrder(order)}
                              style={{ background: 'none', border: 'none', padding: 0, textAlign: 'left', cursor: 'pointer', color: 'var(--cream)' }}
                            >
                              <strong style={{ fontSize: large ? 20 : 13 }}>{order.order_num}</strong>
                              <div style={{ fontSize: large ? 17 : 12, color: 'var(--muted)' }}>{order.customer_name}</div>
                            </button>
                            <span
                              title={`${mins} min ago`}
                              style={{
                                fontSize: large ? 15 : 11, fontWeight: 700, color: 'var(--text-on-accent)', background: ageColor(mins),
                                borderRadius: 999, padding: large ? '4px 10px' : '2px 7px', flexShrink: 0,
                              }}
                            >
                              {mins}m
                            </span>
                          </div>

                          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, margin: large ? '10px 0' : '6px 0' }}>
                            <span style={{ fontSize: large ? 19 : 13, fontWeight: 700 }}>
                              {formatCurrency(order.total)}
                            </span>
                            <PaymentStatusPill status={order.payment_status} />
                          </div>

                          {/* Round-2 fixes brief, Part 5 — the primary,
                              always-visible signal that this order needs
                              no driver at all. Distinct icon/color from
                              the driver_name line below (which only ever
                              applies to a delivery order once one's been
                              assigned) so the two can never be confused
                              at a glance. */}
                          {order.order_type === 'pickup' && (
                            <div style={{ fontSize: large ? 14 : 11.5, color: 'var(--gold)', fontWeight: 700, marginBottom: large ? 8 : 4 }}>
                              🏪 Pickup — no delivery
                            </div>
                          )}
                          {order.driver_name && (
                            <div style={{ fontSize: large ? 14 : 11.5, color: 'var(--muted)', marginBottom: large ? 8 : 4 }}>
                              🛵 {order.driver_name}
                            </div>
                          )}

                          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                            {nextStatus && (
                              <button
                                type="button"
                                disabled={movingId === order.id}
                                onClick={() => handleAdvanceClick(order, nextStatus)}
                                style={{
                                  flex: 1, minWidth: large ? 140 : 100, background: 'var(--ember)', color: 'var(--text-on-accent)', border: 'none',
                                  borderRadius: 6, padding: large ? '14px 10px' : '7px 8px', fontSize: large ? 16 : 12, fontWeight: 700, cursor: 'pointer',
                                }}
                              >
                                {movingId === order.id ? '…' : nextLabelFor(order, col)}
                              </button>
                            )}
                            {col.status !== 'delivered' && (
                              <button
                                type="button"
                                disabled={movingId === order.id}
                                onClick={() => cancelOrder(order)}
                                style={{
                                  background: 'none', color: 'var(--danger)', border: '1px solid var(--danger-border)',
                                  borderRadius: 6, padding: large ? '14px 12px' : '7px 8px', fontSize: large ? 15 : 12, cursor: 'pointer',
                                }}
                              >
                                Cancel
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {cancelledCount > 0 && (
            <div style={{ marginTop: 20, borderTop: '1px solid var(--line)', paddingTop: 14 }}>
              <button
                type="button"
                onClick={() => setShowCancelled((v) => !v)}
                style={{
                  background: 'none', border: 'none', color: 'var(--muted)', fontSize: 13,
                  cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 6,
                }}
              >
                {showCancelled ? '▾' : '▸'} {cancelledCount} cancelled order{cancelledCount === 1 ? '' : 's'}
              </button>

              {showCancelled && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 10 }}>
                  {cancelledOrders.map((order) => (
                    <button
                      key={order.id}
                      type="button"
                      onClick={() => setViewingOrder(order)}
                      style={{
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        background: 'var(--bg-alt)', border: '1px solid var(--line)', borderRadius: 8,
                        padding: '10px 12px', cursor: 'pointer', textAlign: 'left', opacity: 0.75,
                      }}
                    >
                      <span>
                        <strong style={{ fontSize: 13 }}>{order.order_num}</strong>
                        <span style={{ color: 'var(--muted)', fontSize: 12, marginLeft: 8 }}>{order.customer_name}</span>
                      </span>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <PaymentStatusPill status={order.payment_status} />
                        <span style={{ fontSize: 13, color: 'var(--muted)' }}>{formatCurrency(order.total)}</span>
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {etaOrder && (
        <EtaPromptModal
          token={token}
          order={etaOrder}
          onClose={() => setEtaOrder(null)}
          onConfirm={(minutes) => {
            advance(etaOrder, 'preparing', minutes);
            setEtaOrder(null);
          }}
        />
      )}

      {driverOrder && (
        <DriverPromptModal
          order={driverOrder}
          recentDrivers={recentDrivers}
          onClose={() => setDriverOrder(null)}
          onConfirm={(name) => {
            advance(driverOrder, 'on_the_way', null, name);
            setDriverOrder(null);
          }}
          onSkip={() => {
            advance(driverOrder, 'on_the_way');
            setDriverOrder(null);
          }}
        />
      )}

      {viewingOrder && (
        <OrderDetailModal
          token={token}
          order={orders.find((o) => o.id === viewingOrder.id) || viewingOrder}
          movingId={movingId}
          onClose={() => setViewingOrder(null)}
          onAdvance={async (order, next) => {
            setViewingOrder(null);
            handleAdvanceClick(order, next);
          }}
          onCancel={(order) => {
            // Audit-fixes brief, Part 6.7 — cancelOrder just opens the
            // confirmation dialog now; confirmCancelOrder (run only once
            // the admin confirms) is what actually closes this detail
            // modal, so a "Cancel" tap here doesn't dismiss the detail
            // view before the admin has actually confirmed anything.
            cancelOrder(order);
          }}
          onRefund={(order) => {
            setRefundError('');
            setRefundOrder(order);
          }}
        />
      )}

      {refundOrder && (
        <RefundPromptModal
          order={refundOrder}
          remaining={refundRemaining(refundOrder)}
          submitting={refundSubmitting}
          error={refundError}
          onClose={() => { if (!refundSubmitting) { setRefundOrder(null); setRefundError(''); } }}
          onConfirm={(amount) => submitRefund(refundOrder, amount)}
        />
      )}

      <ConfirmDialog
        open={pendingCancel !== null}
        title="Cancel this order?"
        message={pendingCancel ? `Cancel order ${pendingCancel.order_num}? This cannot be undone.` : ''}
        confirmLabel="Cancel order"
        cancelLabel="Keep order"
        busy={movingId !== null && movingId === pendingCancel?.id}
        onConfirm={confirmCancelOrder}
        onCancel={() => setPendingCancel(null)}
      />
    </div>
  );
}
