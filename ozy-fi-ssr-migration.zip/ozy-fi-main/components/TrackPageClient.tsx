'use client';

import { useEffect, useState, type FormEvent, type ChangeEvent } from 'react';
import { useRouter } from 'next/navigation';
import { StoreProvider } from '@/context/StoreContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useTranslations, useLocale, useLocalePath } from '@/lib/i18n';
import type {
  OrderStatus,
  OrderType,
  OrderTrackingResult,
  OrderPhoneMatch,
  RecentOrder,
  CartLine,
} from '@/lib/types';

interface Step {
  key: string;
  label: string;
}

function stepIndex(status: OrderStatus, STEPS: Step[]) {
  const i = STEPS.findIndex((s) => s.key === status);
  return i === -1 ? 0 : i + 1;
}

// Round-2 fixes brief, Part 5 — "On the way"/"Delivered" are delivery-
// specific language that's simply wrong for a pickup order (nobody is
// "on the way" to a customer who's coming to collect it themselves).
//
// Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 — OrderStatus
// gained 'accepted' (between received/preparing) and 'ready' (between
// preparing/on_the_way). For a DELIVERY order this is a straightforward
// extra two steps in the same timeline. For PICKUP there's no real
// "on the way" phase at all — the round-2 pickup work already reused
// on_the_way's slot to mean "ready and waiting for the customer" before
// this task existed; now that 'ready' is a real status of its own, that
// meaning moves to 'ready' ("Ready for pickup"), and the pickup timeline
// simply doesn't show 'on_the_way' as its own visual step — an order
// that has moved past 'ready' into 'on_the_way' (the admin's "Mark
// picked up" action — see components/admin/OrderKanban.tsx) is shown as
// already at the final "Picked up" milestone (active, not yet checked),
// which is checked off once the admin's last, purely administrative
// on_the_way -> delivered close-out happens. This is a genuine,
// deliberate scope decision (not an oversight) — seemed the honest
// customer-facing depiction of a flow pickup was never going to have an
// "on the way" leg for regardless of how many backend statuses exist.
function OrderTimeline({ status, orderType, t }: { status: OrderStatus; orderType?: OrderType; t: any }) {
  const isPickup = orderType === 'pickup';
  const STEPS: Step[] = isPickup
    ? [
        { key: 'received', label: t.track.stepReceived },
        { key: 'accepted', label: t.track.stepAccepted },
        { key: 'preparing', label: t.track.stepPreparing },
        { key: 'ready', label: t.track.stepReadyForPickup },
        { key: 'delivered', label: t.track.stepPickedUp },
      ]
    : [
        { key: 'received', label: t.track.stepReceived },
        { key: 'accepted', label: t.track.stepAccepted },
        { key: 'preparing', label: t.track.stepPreparing },
        { key: 'ready', label: t.track.stepReady },
        { key: 'on_the_way', label: t.track.stepOnTheWay },
        { key: 'delivered', label: t.track.stepDelivered },
      ];

  if (status === 'cancelled') {
    return (
      <div className="track-cancelled">
        <span style={{ fontSize: '1.3rem' }}>⚠️</span>
        <span>{t.track.cancelledNotice}</span>
      </div>
    );
  }

  // See this function's own comment — a pickup order's real 'on_the_way'
  // status has no visual step of its own; treat it the same as 'delivered'
  // (active, not yet checked) for the purposes of computing which step is
  // current.
  const effectiveStatus = isPickup && status === 'on_the_way' ? 'delivered' : status;
  const current = stepIndex(effectiveStatus, STEPS);

  return (
    <div className="checkout-steps" style={{ marginTop: 20 }}>
      {STEPS.map((s, i) => {
        const n = i + 1;
        const isActive = current === n;
        const isDone = current > n;
        return (
          <div key={s.key} style={{ display: 'contents' }}>
            <div className="checkout-step">
              <div className={`checkout-step-dot${isActive ? ' active' : isDone ? ' done' : ''}`}>
                {isDone ? '✓' : n}
              </div>
              <span className={`checkout-step-label${isActive ? ' active' : ''}`}>{s.label}</span>
            </div>
            {n < STEPS.length && (
              <div className={`checkout-step-line${current > n ? ' done' : ''}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

function parseDetails(raw?: string | null): string[] {
  if (!raw) return [];
  try {
    const d = JSON.parse(raw);
    return Array.isArray(d) ? d : [];
  } catch {
    return [];
  }
}

// Date/time formatting stays locale-aware via Intl (toLocaleString), not
// the UI dictionary — 'fi-FI' gives Finnish month names/24h time, 'en-IE'
// keeps the existing English formatting this page already used.
function formatDate(iso: string | null | undefined, locale: string) {
  if (!iso) return '';
  const d = new Date(iso.includes('T') ? iso : `${iso.replace(' ', 'T')}Z`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString(locale === 'fi' ? 'fi-FI' : 'en-IE', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function formatTime(iso: string | null | undefined, locale: string) {
  if (!iso) return '';
  const d = new Date(iso.includes('T') ? iso : `${iso.replace(' ', 'T')}Z`);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleString(locale === 'fi' ? 'fi-FI' : 'en-IE', { hour: '2-digit', minute: '2-digit' });
}

// Phase 7 remainder, part 6 — a live "X min left" alongside the existing
// fixed clock-time ETA (formatTime above), not replacing it. Re-renders
// once a minute via setInterval, which is precise enough for a minutes-
// level estimate — no point re-rendering every second for this.
function minutesRemainingLabel(etaIso: string | null | undefined, nowMs: number, t: any) {
  if (!etaIso) return null;
  const d = new Date(etaIso.includes('T') ? etaIso : `${etaIso.replace(' ', 'T')}Z`);
  if (Number.isNaN(d.getTime())) return null;

  const diffMinutes = Math.round((d.getTime() - nowMs) / 60000);

  // The kitchen can run behind — an order still "preparing"/"on_the_way"
  // past its original ETA shouldn't show a confusing "-3 min left".
  if (diffMinutes <= 0) return t.track.minutesLeftSoon;
  if (diffMinutes === 1) return t.track.minutesLeftOne;
  return t.track.minutesLeft(diffMinutes);
}

function EtaCountdown({ etaIso, t, locale }: { etaIso?: string | null; t: any; locale: string }) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 60000);
    return () => clearInterval(id);
  }, []);

  const remaining = minutesRemainingLabel(etaIso, now, t);

  return (
    <p className="track-eta">
      ⏱ {t.track.estimatedReadyBy(formatTime(etaIso, locale))}
      {/* estimatedReadyBy returns JSX (bolds the time) — see lib/i18n/*.js */}
      {remaining && <span className="track-eta-remaining"> ({remaining})</span>}
    </p>
  );
}

function RecentOrderShortcut({ onPick, t }: { onPick: (o: RecentOrder) => void; t: any }) {
  const [recent, setRecent] = useState<RecentOrder[]>([]);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('ozy_recent_orders') || '[]');
      setRecent(Array.isArray(saved) ? saved.slice(0, 3) : []);
    } catch {
      setRecent([]);
    }
  }, []);

  if (recent.length === 0) return null;

  return (
    <div className="track-recent">
      <p className="track-recent-title">{t.track.recentOrdersHint}</p>
      {recent.map((o) => (
        <button key={o.orderNum} type="button" className="track-recent-btn" onClick={() => onPick(o)}>
          {o.orderNum} <span>→</span>
        </button>
      ))}
    </div>
  );
}

function PhoneLookup({ onFound, t, locale }: { onFound: (orderNum: string, phone: string) => void; t: any; locale: string }) {
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [matches, setMatches] = useState<OrderPhoneMatch[] | null>(null);

  const search = async (e: FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) return;
    setLoading(true);
    setError('');
    setMatches(null);
    try {
      const res = await fetch(`/api/orders/by-phone?phone=${encodeURIComponent(phone.trim())}`);
      // res.json() resolves to `unknown` under real fetch typings — cast to
      // this endpoint's actual response shape.
      const data = (await res.json()) as { error?: string; orders?: OrderPhoneMatch[] };
      if (!res.ok) {
        setError(data.error || t.track.genericError);
        return;
      }
      if (!data.orders || data.orders.length === 0) {
        setError(t.track.noPhoneMatches);
        return;
      }
      setMatches(data.orders);
    } catch {
      setError(t.track.genericError);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="track-phone-lookup">
      <form onSubmit={search} className="track-form" style={{ marginBottom: matches ? 16 : 0 }}>
        <label>
          {t.track.phoneLabel}
          <input
            type="tel"
            value={phone}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setPhone(e.target.value)}
            placeholder={t.track.phonePlaceholder}
          />
        </label>
        <button type="submit" className={`btn-primary${loading ? ' is-loading' : ''}`} disabled={loading}>
          {loading ? t.track.searching : t.track.findMyOrders}
        </button>
        {error && <span className="field-error">{error}</span>}
      </form>

      {matches && (
        <div className="track-recent">
          <p className="track-recent-title">{t.track.recentOrdersForNumber}</p>
          {matches.map((o) => (
            <button
              key={o.orderNum}
              type="button"
              className="track-recent-btn"
              onClick={() => onFound(o.orderNum, phone.trim())}
            >
              {o.orderNum} <span className="track-recent-meta">{formatDate(o.createdAt, locale)}</span> <span>→</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// Feature 1 — "Reorder this". Two-step by design: fetching the reorder
// data first (so any "N items skipped" notice is visible on THIS page,
// before leaving it) and only navigating to checkout once the customer
// explicitly continues — matches the brief's "lands the customer on
// checkout with the cart already filled — not an auto-submitted order
// (they should still review before confirming)".
function ReorderButton({ orderNum, phone, orderType, t }: { orderNum: string; phone: string; orderType?: OrderType; t: any }) {
  const router = useRouter();
  const lp = useLocalePath();
  const [status, setStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ cart: CartLine[]; skippedCount: number; addedCount: number } | null>(null);

  const fetchReorder = async () => {
    setStatus('loading');
    setError('');
    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(orderNum)}/reorder?phone=${encodeURIComponent(phone)}`);
      // res.json() resolves to `unknown` under real fetch typings — cast to
      // this endpoint's actual response shape.
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        cart?: CartLine[];
        skippedCount?: number;
        addedCount?: number;
      };
      if (!res.ok || !data.cart) {
        setError(data.error || t.track.reorderGenericError);
        setStatus('error');
        return;
      }
      setResult({ cart: data.cart, skippedCount: data.skippedCount || 0, addedCount: data.addedCount || data.cart.length });
      setStatus('ready');
    } catch {
      setError(t.track.reorderGenericError);
      setStatus('error');
    }
  };

  // Writes into the SAME sessionStorage keys StoreContext.tsx's cart-
  // persistence effect and one-shot checkout-open effect already read on
  // mount (see that file's header comment on why this is the only way to
  // hand off state to a different page's StoreProvider instance) — this
  // page never imports StoreContext itself for cart state.
  const continueToCheckout = () => {
    if (!result) return;
    try {
      sessionStorage.setItem('ozy_cart', JSON.stringify(result.cart));
      sessionStorage.setItem('ozy_open_checkout', '1');
      // Stamp-card redesign / discount-source tracking (Part C —
      // "Reorders") — a sibling one-shot flag, consumed by
      // context/StoreContext.tsx's mount effect the same way
      // ozy_open_checkout is, so the order this cart turns into can be
      // marked orders.is_reorder = 1.
      sessionStorage.setItem('ozy_is_reorder', '1');
      // Round-2 fixes brief, Part 5 — a reordered pickup order should
      // default back to pickup, not silently become a delivery order
      // (the local `orderType` state CheckoutModal.tsx starts every fresh
      // checkout with). Same one-shot sessionStorage handoff pattern as
      // ozy_is_reorder above, consumed once by
      // context/StoreContext.tsx's mount effect. Only written when it's
      // actually 'pickup' — the default (delivery, or this order
      // predating the order_type column) needs no override at all, since
      // 'delivery' is already CheckoutModal's own starting state.
      if (orderType === 'pickup') {
        sessionStorage.setItem('ozy_reorder_order_type', 'pickup');
      }
    } catch {
      // Storage unavailable — still navigate; the customer just lands on
      // an empty cart instead of a pre-filled one, same degraded
      // experience session storage being unavailable already causes
      // elsewhere in this app.
    }
    router.push(lp('/menu'));
  };

  if (status === 'ready' && result) {
    return (
      <div className="track-recent" style={{ marginTop: 16 }}>
        <p className="track-recent-title">
          {result.skippedCount > 0
            ? t.track.reorderSkippedNotice(result.skippedCount)
            : t.track.reorderReadyNotice(result.addedCount)}
        </p>
        <button type="button" className="btn-primary" onClick={continueToCheckout}>
          {t.track.reorderContinue}
        </button>
      </div>
    );
  }

  return (
    <div style={{ marginTop: 16 }}>
      <button type="button" className="btn-primary" onClick={fetchReorder} disabled={status === 'loading'}>
        {status === 'loading' ? t.track.reorderLoading : t.track.reorderButton}
      </button>
      {status === 'error' && <p className="field-error" style={{ marginTop: 8 }}>{error}</p>}
    </div>
  );
}

function TrackForm({ t, locale }: { t: any; locale: string }) {
  const [orderNum, setOrderNum] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [order, setOrder] = useState<OrderTrackingResult | null>(null);
  const [lostOrderNum, setLostOrderNum] = useState(false);

  const lookup = async (num: string, ph: string) => {
    setLoading(true);
    setError('');
    setOrder(null);
    try {
      const res = await fetch(
        `/api/orders/${encodeURIComponent(num.trim())}?phone=${encodeURIComponent(ph.trim())}`
      );
      if (!res.ok) {
        setError(t.track.notFoundError);
        return;
      }
      const data = (await res.json()) as OrderTrackingResult;
      setOrder(data);
      setOrderNum(num);
      setPhone(ph);
      setLostOrderNum(false);
    } catch {
      setError(t.track.genericError);
    } finally {
      setLoading(false);
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!orderNum.trim() || !phone.trim()) {
      setError(t.track.fillBothFields);
      return;
    }
    lookup(orderNum, phone);
  };

  return (
    <>
      {!order && !lostOrderNum && (
        <RecentOrderShortcut onPick={(o) => lookup(o.orderNum, o.phone)} t={t} />
      )}

      {!order && !lostOrderNum && (
        <>
          <form className="track-form" onSubmit={submit}>
            <label>
              {t.track.orderNumberLabel}
              <input
                type="text"
                value={orderNum}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setOrderNum(e.target.value)}
                placeholder={t.track.orderNumberPlaceholder}
                autoCapitalize="characters"
              />
            </label>
            <label>
              {t.track.phoneLabel}
              <input
                type="tel"
                value={phone}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setPhone(e.target.value)}
                placeholder={t.track.phonePlaceholder}
              />
            </label>
            <button type="submit" className={`btn-primary${loading ? ' is-loading' : ''}`} disabled={loading}>
              {loading ? t.track.lookingUp : t.track.trackOrderBtn}
            </button>
            {error && <span className="field-error">{error}</span>}
          </form>
          <button type="button" className="track-lost-link" onClick={() => { setLostOrderNum(true); setError(''); }}>
            {t.track.dontHaveOrderNumber}
          </button>
        </>
      )}

      {!order && lostOrderNum && (
        <>
          <PhoneLookup onFound={(num, ph) => lookup(num, ph)} t={t} locale={locale} />
          <button type="button" className="track-lost-link" onClick={() => { setLostOrderNum(false); setError(''); }}>
            {t.track.backToOrderNumber}
          </button>
        </>
      )}

      {order && (
        <div className="track-result">
          <div className="track-result-head">
            <div>
              <div className="track-order-num">{order.order_num}</div>
              <div className="track-placed-at">{t.track.placedAt(formatDate(order.created_at, locale))}</div>
            </div>
          </div>

          {/* Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 3 —
              'ready' added to the same "still worth showing the ETA"
              window this already covered ('preparing' through
              'on_the_way'), so inserting it between them doesn't create a
              one-stage gap where the countdown briefly disappears. */}
          {order.estimated_ready_at && ['preparing', 'ready', 'on_the_way'].includes(order.status) && (
            <EtaCountdown etaIso={order.estimated_ready_at} t={t} locale={locale} />
          )}

          <OrderTimeline status={order.status} orderType={order.order_type} t={t} />

          <div className="track-items">
            {(order.items || []).map((item) => {
              const details = parseDetails(item.details);
              return (
                <div className="track-item-row" key={item.id}>
                  <div>
                    <div className="track-item-name">{item.qty}× {item.name}</div>
                    {details.length > 0 && <div className="track-item-meta">{details.join(', ')}</div>}
                  </div>
                  <span className="cs-price">{Number(item.line_total).toFixed(2)} €</span>
                </div>
              );
            })}
            <div className="track-total-row">
              <span>{t.checkout.total}</span>
              <span>{Number(order.total).toFixed(2)} €</span>
            </div>
          </div>

          {/* Round-2 fixes brief, Part 5 — order.address is a sentinel
              string for a pickup order (never a real address — see
              app/api/orders/route.ts's PICKUP_ADDRESS_SENTINEL), so this
              shows the pickup-appropriate line instead of ever printing
              that sentinel text to the customer. */}
          <p className="track-address">
            {order.order_type === 'pickup'
              ? t.track.pickupAt(order.payment_method === 'cod' ? t.track.codPaymentLabel : order.payment_method)
              : t.track.deliveringTo(order.address, order.payment_method === 'cod' ? t.track.codPaymentLabel : order.payment_method)}
          </p>

          <ReorderButton orderNum={order.order_num} phone={phone} orderType={order.order_type} t={t} />

          <button type="button" className="track-lost-link" onClick={() => setOrder(null)}>
            {t.track.trackDifferentOrder}
          </button>
        </div>
      )}
    </>
  );
}

export default function TrackPageClient() {
  const t = useTranslations();
  // useLocale() is typed (via next/navigation's useParams()) as
  // string | string[] since lib/i18n/index.js stays a plain .js module —
  // it only ever returns a single locale string ('fi' | 'en') at runtime.
  // Same cast as context/StoreContext.tsx.
  const locale = useLocale() as string;

  return (
    <StoreProvider>
      <Header />
      <main className="wrap track-page">
        <p className="eyebrow">{t.track.eyebrow}</p>
        <h1>{t.track.heading}</h1>
        <p className="desc">
          {t.track.desc}
        </p>
        <TrackForm t={t} locale={locale} />
      </main>
      <Footer />
    </StoreProvider>
  );
}
