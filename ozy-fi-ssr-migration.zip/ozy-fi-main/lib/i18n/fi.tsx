// Finnish UI dictionary — the PRIMARY/default language for this site
// (see the brief: Finnish-area customers searching in Finnish is the
// whole point of this change). Real, hand-written Finnish — not machine
// translation — but this project's assistant is not a native Finnish
// speaker, so lower-confidence strings are flagged in this feature's
// delivery summary rather than guessed silently. Keep this file's shape
// identical to en.js — every key here has a matching key there.

import type { ReactNode } from 'react';

const fi = {
  common: {
    loading: 'Ladataan…',
    // SEO-täydennys, osa C — ks. vastaava kommentti en.js:ssä.
    placeholderLabel: 'Paikkamerkki — tarvitsee oikeaa sisältöä',
    // Ks. en.tsx:n vastaava kommentti (ostoskoriin lisäämisen "Lisätty!"-ilmoitus).
    addedToCart: (name: string) => `${name} lisätty ostoskoriin`,
  },

  // SEO gap-fill, Part A — see the matching comment in en.js.
  breadcrumb: {
    home: 'Etusivu',
  },

  header: {
    menu: 'Ruokalista',
    // Audit-fixes-korjaukset, osa 6.5 — ks. en.tsx:n vastaava kommentti.
    ourStory: 'Tarinamme',
    findUs: 'Löydä meidät',
    trackOrder: 'Seuraa tilausta',
    cartAriaLabel: 'Ostoskori',
    openMenuAriaLabel: 'Avaa valikko',
    storeClosedBanner: 'Olemme tilapäisesti suljettu emmekä ota juuri nyt vastaan uusia tilauksia.',
    // amountText is a pre-formatted "10%" tai "2.00 €" (jaettu discount-
    // value-malli — ks. lib/pricing.ts:n describeDiscountValue).
    scheduledOfferBanner: (label: string, amountText: string) => `🔥 ${label}: ${amountText} alennus juuri nyt!`,
  },

  footer: {
    tagline: 'Pizzaa, kebabia ja hampurilaisia, tuoreena valmistettuna.',
    pagesHeading: 'Sivut',
    ourStory: 'Tarinamme',
    findUs: 'Löydä meidät',
    contactHeading: 'Yhteystiedot',
    privacyPolicy: 'Tietosuojaseloste',
    faq: 'UKK',
    terms: 'Käyttöehdot',
    rights: (year: number) => `© ${year} ozy.fi. Kaikki oikeudet pidätetään.`,
    demoNotice: 'Demosivusto.',
    // Growth features (Feature 4 — referral program).
    referralColumnHeading: 'Suosittele ystävälle',
    referralHeading: 'Hanki alennuskoodi ystävällesi',
    referralEmailPlaceholder: 'sinun@sahkoposti.fi',
    referralSubmit: 'Hae koodi',
    referralSubmitting: 'Lähetetään…',
    referralError: 'Koodia ei juuri nyt saatu haettua. Yritä uudelleen.',
    referralSuccess: 'Tässä koodisi — jaa se ystävällesi!',
    referralAlreadyHad: 'Sinulla on jo koodi:',
    referralCopy: 'Kopioi koodi',
    referralCopied: 'Kopioitu!',
  },

  cookieBanner: {
    dialogAriaLabel: 'Evästesuostumus',
    message: (privacyLink: ReactNode) => (
      <>
        Käytämme evästeitä ja vastaavaa teknistä tallennustilaa sivuston toimintaan ja ostoskorisi sisällön
        säilyttämiseen tilauksen aikana. Luvallasi voimme käyttää evästeitä myös kävijämäärän ja mainonnan
        mittaamiseen. Lisätietoja {privacyLink}ssamme.
      </>
    ),
    privacyPolicyLinkText: 'tietosuojaselosteesta',
    cookieSettings: 'Evästeasetukset',
    necessaryOnly: 'Vain välttämättömät',
    acceptAll: 'Hyväksy kaikki',
    necessaryTitle: 'Välttämättömät',
    necessaryDesc: 'Vaaditaan sivuston toimintaan — ostoskorin sisällön säilyttämiseen ja ylläpitäjänä kirjautumiseen. Aina käytössä, ei voi kytkeä pois.',
    necessaryAriaLabel: 'Välttämätön tallennustila — aina käytössä',
    adsTitle: 'Mainonta ja analytiikka',
    adsDesc: 'Auttaa meitä näkemään, miten sivustoa käytetään, ja mittaamaan mainontaa (Google Analytics, Meta/TikTok, Microsoft Clarity). Pois päältä, ellet valitse alta "Hyväksy kaikki".',
    adsAriaLabel: 'Mainonta ja analytiikka — pois päältä, ellei valita Hyväksy kaikki',
  },

  orderBar: {
    viewOrder: 'Näytä tilaus',
  },

  hero: {
    eyebrow: 'Pizzaa, kebabia ja hampurilaisia',
    titleStart: 'Aloita',
    titleEm: 'tilauksesi',
    openNow: 'Avoinna nyt',
    closedNow: 'Suljettu nyt',
    // Priority-fixes brief (roadmap gap analysis), Part 5 — same
    // next-transition messaging as en.tsx's hero block; see that file's
    // comment for when this is shown instead of the plain openNow/closedNow.
    openClosesAt: (time: string) => `Avoinna — suljetaan klo ${time}`,
    closedOpensAt: (time: string) => `Suljettu — avataan klo ${time}`,
    closedOpensAtDay: (dayLabel: string, time: string) => `Suljettu — avataan ${dayLabel} klo ${time}`,
    tomorrow: 'huomenna',
    etaRange: '25–35 min',
    subtitle: 'Tuoretta taikinaa, valmistettu tilauksesta, aina kuumana. Valitse kategoria tai selaa koko ruokalistaa — kotiinkuljetus tai nouto valitaan kassalla.',
  },

  categories: {
    pizza: 'Pizza',
    kebab: 'Kebab',
    burgers: 'Hampurilaiset',
  },

  menuTeaser: {
    eyebrow: 'JO NÄLKÄ?',
    heading: 'Tuoretta pizzaa, kebabia ja hampurilaisia',
    seeFullMenu: 'Katso koko ruokalista',
  },

  popularNow: {
    eyebrow: 'SUOSITUIMMAT JUURI NYT',
  },

  bundles: {
    heading: 'Yhdistelmätarjoukset',
  },

  featuredCard: {
    badgeNew: 'UUTTA',
    badgeDeal: 'TARJOUS',
  },

  menuSection: {
    eyebrow: 'Ruokalista',
    heading: 'Koko ruokalista',
    description: 'Selaa kategorioittain — pizzat, kebabit, hampurilaiset, salaatit ja leikkeet, kaikki tuoreena valmistettuna. Napauta tuotetta muokataksesi sitä ja lisätäksesi sen tilaukseesi.',
    loading: 'Ladataan ruokalistaa…',
    loadError: 'Ruokalistaa ei voitu ladata. Yritä uudelleen.',
    note: 'Lisätäytteet 2,50 €: 120 g pihvi, pekoni, juusto, ananas, sinihomejuusto, sipuli, kananmuna · Kastikkeet: ketsuppi, jogurttikastike, suolakurkku, sitruunamehu, majoneesi, amerikanmajoneesi, persilja, minttu, chilihiutaleet.',
    relatedCategoriesHeading: 'Saatat pitää myös näistä',
    // Priority-fixes brief (roadmap gap analysis), Bundle 1 Task 2 — menu
    // search (see components/MenuSection.tsx).
    searchPlaceholder: 'Hae ruokalistalta…',
    searchLabel: 'Hae ruokalistan tuotteita',
    clearSearch: 'Tyhjennä haku',
    noResultsHeading: 'Tuloksia ei löytynyt',
    noResults: (query: string) => `Yksikään tuote ei vastaa hakua "${query}". Kokeile toista hakusanaa.`,
    // Search-improvements brief, items 4 and 5.
    recentSearchesHeading: 'Viimeisimmät haut',
    didYouMean: (name: string) => `Tarkoititko "${name}"?`,
  },

  story: {
    p1: 'ozy.fi sai alkunsa yhdestä uunista, yhdestä reseptistä ja periaatteesta olla tinkimättä kummastakaan.',
    p2: 'Valmistamme jokaisen tilauksen samalla tavalla, joka kerta — tuoretta taikinaa, käsin annosteltuja täytteitä, kuuma uuni — lautaselle heti kun se on valmis.',
    p3: 'Ei oikoteitä, ei pakastepohjia. Vain hyviä raaka-aineita ja keittiö, joka ei koskaan oikeastaan jäähdy.',
    stat1Label: 'Valmistetaan tilauksesta',
    stat2Label: 'Tuotetta ruokalistalla',
    stat3Label: 'Päivää viikossa',
    bannerAltFallback: (index: number) => `Kuva ozy.fi:n keittiöstä (${index + 1})`,
    bannerPrev: 'Edellinen kuva',
    bannerNext: 'Seuraava kuva',
    bannerGoTo: (index: number) => `Siirry kuvaan ${index + 1}`,
  },

  visit: {
    addressHeading: 'Osoite',
    openingHoursHeading: 'Aukioloajat',
    contactHeading: 'Yhteystiedot',
    closed: 'Suljettu',
    // SEO gap-fill, Part C — ks. vastaava kommentti en.js:ssä.
    notSet: '[Ei vielä asetettu — lisää Admin → Asetukset-kohdassa]',
    days: {
      mon: 'Maanantai', tue: 'Tiistai', wed: 'Keskiviikko', thu: 'Torstai',
      fri: 'Perjantai', sat: 'Lauantai', sun: 'Sunnuntai',
    },
    fallbackRows: [
      { label: 'Ma – To', value: '15–22' },
      { label: 'Pe – La', value: '15–23' },
      { label: 'Sunnuntai', value: '14–21' },
    ],
  },

  ctaStrip: {
    heading: 'Nälkä yllätti?',
    text: 'Tilaa verkosta kotiinkuljetuksena tai noutona — valmiina alle 30 minuutissa.',
    cta: 'Selaa ruokalistaa',
  },

  productPage: {
    backAriaLabel: 'Takaisin',
    cartAriaLabel: 'Ostoskori',
    removeOneAriaLabel: 'Poista yksi',
    addOneAriaLabel: 'Lisää yksi',
    // Per-product-size brief — see en.tsx's matching key comment; `size` is
    // now the sole heading for the per-product 'size' option-group selector.
    size: 'Koko',
    // Option-gating-and-extras-system brief, Task 2 — see en.tsx's
    // matching key comment.
    extrasHeading: 'Lisät — napauta lisätäksesi',
    finishToppings: 'Viimeistely — napauta lisätäksesi täytteitä',
    bottom: 'Pohja',
    change: 'vaihda',
    select: 'valitse',
    fillingsHeading: 'Täytteet',
    fillingsEmptyHint: 'Täytteitä ei ole vielä lisätty — lisää niitä alta kohdasta "Lisää täytteitä".',
    moreFillings: 'Lisää täytteitä',
    sauceStripesHeading: 'Viimeistele kastikeraidoilla',
    dipHeading: 'Reunatäyte',
    selectADip: 'Valitse reunatäyte',
    productDetailsHeading: 'Tuotetiedot',
    rawMaterialTitle: 'Raaka-ainetiedot',
    rawMaterialBody: 'Kaikki raaka-aineet hankitaan hyväksytyiltä toimittajilta ja valmistetaan tuoreena päivittäin paikan päällä. Allergeeni- ja alkuperätiedot jokaisesta täytteestä ovat saatavilla pyynnöstä ravintolasta, ja täydelliset ainesosaluettelot on painettu pakkaukseen.',
    nutritionTitle: 'Ravintosisältötiedot',
    nutritionBody: 'Energia-, rasva-, hiilihydraatti-, sokeri-, proteiini- ja suola-arvot on laskettu 100 g:aa ja annosta kohden, ja ne vaihtelevat hieman valitsemasi koon ja täytteiden mukaan. Tarkat arvot muokatulle tilauksellesi näytetään kassalla.',
    climateTitle: 'Ilmastolaskuri',
    climateBody: 'Tämän tuotteen arvioitu hiilijalanjälki lasketaan sen raaka-aineiden, pakkauksen ja valmistustavan perusteella. Kasvipohjaisten täytteiden ja juuston valitseminen yleensä pienentää tilauksesi jalanjälkeä.',
    loadingOptions: 'Ladataan vaihtoehtoja…',
    itemUnavailable: 'Tämä tuote ei ole juuri nyt saatavilla.',
    relatedHeading: 'Saatat pitää myös näistä',
    partOfBundleLabel: 'Saatavana myös yhdistelmätarjouksessa',
    viewBundle: (bundleTitle: string) => `Katso "${bundleTitle}" -yhdistelmätarjous`,
    addToOrder: (price: string) => `Lisää tilaukseen — ${price}`,
    addToBundle: 'Lisää pakettiin',
    addToBundleExtra: (price: string) => `Lisää pakettiin — +${price}`,
  },

  bundleModal: {
    backAriaLabel: 'Takaisin',
    backToBundle: '← takaisin pakettiin',
    chooseItem: 'Valitse tuote',
    added: 'lisätty',
    included: 'Sisältyy',
    choose: 'Valitse',
    remove: 'poista',
    chooseItemBtn: (label: string) => `+ Valitse ${label}`,
    item: 'tuote',
    fillEverySlot: 'Täytä jokainen kohta jatkaaksesi',
    addBundleToOrder: (price: string) => `Lisää paketti tilaukseen — ${price}`,
  },

  drinkUpsell: {
    titleLine1: 'Pepsi vai',
    titleLine2: 'Pepsi Max?',
    noThanks: 'Ei kiitos',
  },

  checkout: {
    stepCart: 'Ostoskori',
    stepDetails: 'Tiedot',
    stepPayment: 'Maksu',
    // Ks. en.tsx:n vastaava kommentti (kohta 10 — "Vaihe X/Y").
    stepOfLabel: (current: number, total: number) => `Vaihe ${current}/${total}`,
    backAriaLabel: 'Takaisin',
    closeAriaLabel: 'Sulje',
    title: 'Tilauksesi',
    itemsCount: (n: number) => (n === 1 ? '1 tuote tilauksessasi' : `${n} tuotetta tilauksessasi`),
    emptyCart: 'Ostoskorisi on tyhjä. Lisää ensin jotain herkullista ruokalistalta.',
    backToMenu: 'Takaisin ruokalistalle',
    reviewOrder: 'Tarkista tilauksesi',
    total: 'Yhteensä',
    remove: 'Poista',
    coldDrink: 'Kylmä juoma kylkeen?',
    inCart: (n: number) => `Korissa · ${n}`,
    orderDetails: 'Tilauksen tiedot',
    fullName: 'Etu- ja sukunimi',
    deliveryAddress: 'Toimitusosoite',
    deliveryAddressPlaceholder: 'Katu, talon numero, kaupunki',
    postalCode: 'Postinumero',
    postalCodePlaceholder: 'esim. 01600',
    emailOptional: 'Sähköpostiosoite (valinnainen)',
    emailPlaceholder: 'sina@esimerkki.fi (valinnainen)',
    phone: 'Puhelin',
    phonePlaceholder: '040 123 4567',
    additionalInfo: 'Lisätietoa ravintolalle',
    additionalInfoPlaceholder: 'esim. ovikoodi, kerros, yritys, ruoka-allergia',
    errorName: 'Anna koko nimesi.',
    errorAddress: 'Anna toimitusosoitteesi.',
    errorPostalCode: 'Anna kelvollinen 5-numeroinen postinumero.',
    errorEmail: 'Anna kelvollinen sähköpostiosoite.',
    errorPhone: 'Anna kelvollinen suomalainen puhelinnumero (esim. 040 123 4567).',
    couponPlaceholder: 'Alennuskoodi',
    couponApply: 'Käytä',
    couponChecking: 'Tarkistetaan…',
    couponApplied: (code: string, amount: string) => `${code} käytössä — −${amount}`,
    couponRemove: 'Poista',
    couponGenericError: 'Tämä alennuskoodi ei ole voimassa.',
    couponNetworkError: 'Alennuskoodia ei voitu tarkistaa juuri nyt. Yritä uudelleen.',
    paymentMethodHeading: 'Maksutapa',
    cod: 'Käteinen toimituksessa',
    codDesc: 'Maksa, kun tilauksesi saapuu',
    card: 'Kortti',
    cardDesc: 'Kortti, Google Pay tai Apple Pay',
    cardGenericError: 'Maksua ei voitu suorittaa. Tarkista korttitietosi ja yritä uudelleen.',
    cardUnavailableError: 'Korttimaksu ei ole juuri nyt käytettävissä. Valitse maksu noudettaessa tai yritä hetken kuluttua uudelleen.',
    // Audit-fixes-korjaukset, osa 1 — kun korttimaksun PaymentIntent on
    // luotu, taaksepäin siirtyminen lukitaan (ks. CheckoutModal.tsx), jotta
    // tilaus/osoite ei voi enää hiljaa poiketa siitä mitä näytetään. Tämä on
    // ainoa selkeä tapa perua se tila.
    paymentLockedNotice: 'Tilauksesi on lukittu maksun ajaksi. Jos haluat muuttaa jotain, peruuta ja aloita alusta.',
    cancelPaymentAction: 'Peruuta ja aloita alusta',
    cancellingPayment: 'Perutaan…',
    // Audit-fixes-korjaukset, osa 6.3.
    securePaymentNotice: 'Turvallinen maksu',
    continue: 'Jatka',
    continueWithTotal: (total: string) => `Jatka — ${total}`,
    placeOrder: (total: string) => `Tilaa — ${total}`,
    genericOrderError: 'Tilausta ei voitu lähettää. Yritä uudelleen.',
    storeClosedError: 'Olemme tilapäisesti suljettu emmekä ota juuri nyt vastaan tilauksia. Käy pian uudelleen.',
    ready: 'Valmis',
    allDrinks: 'Kaikki juomat',
    dipsShortcut: 'Reunatäyte',
    snacks: 'Naposteltavat',
    added: 'Lisätty',
    // Growth features (Feature 2 — first-order welcome discount).
    // amountText: ks. header.scheduledOfferBanner:n kommentti.
    welcomeDiscountBanner: (amountText: string) => `🎉 Ensimmäinen tilaus? Saat ${amountText} alennuksen — lisätään automaattisesti kassalla!`,
    scheduledOfferBanner: (label: string, amountText: string) => `🔥 ${label}: ${amountText} alennus — lisätään automaattisesti kassalla!`,
    // Round-2 fixes brief, Part 1 / Part 5 — ks. en.tsx:n vastaavat
    // kommentit.
    deliveryFeeRow: 'Toimitusmaksu',
    minOrderNotice: (amountNeeded: string, minimum: string) =>
      `Lisää tilaukseen ${amountNeeded} saavuttaaksesi kotiinkuljetuksen ${minimum} vähimmäissumman.`,
    orderTypeHeading: 'Miten haluat saada tilauksesi?',
    orderTypeDelivery: 'Kotiinkuljetus',
    orderTypeDeliveryDesc: 'Toimitetaan ovellesi',
    orderTypePickup: 'Nouto',
    orderTypePickupDesc: 'Nouda tilaus itse ravintolasta',
    pickupInfoHeading: 'Noutopaikka ja aukioloajat',
    pickupInfoIntro: 'Tule meille osoitteeseen:',
    // Ks. en.tsx:n vastaavat kommentit (kohdat 13 ja 12).
    estimatedDeliveryTime: (minutes: number) => `~${minutes} min alueellesi`,
    estimatedPickupTime: (minutes: number) => `~${minutes} min kunnes valmis noudettavaksi`,
    addressPrefilledNotice: 'Täytimme osoitteen edellisestä tilauksestasi — voit muuttaa sitä vapaasti.',
    addressPrefilledClear: 'Eikö tämä ole sinun? Tyhjennä',
  },

  confirm: {
    eyebrow: 'Tilaus vastaanotettu',
    thanks: (name: string | undefined) => `Kiitos${name ? `, ${name}` : ''}! Tilauksesi on matkalla.`,
    eta: 'Arvioitu valmistumisaika: 25–35 minuuttia',
    couponApplied: (amount: string) => `Alennuskoodi käytössä: −${amount}`,
    // Growth features (Feature 2 — first-order welcome discount).
    welcomeDiscountApplied: (amount: string) => `Ensitilausalennus käytössä: −${amount}`,
    scheduledOfferApplied: (label: string, amount: string) => `${label}-alennus käytössä: −${amount}`,
    stampCardApplied: (amount: string) => `Kanta-asiakasetu käytössä: −${amount}`,
    codNote: (total: ReactNode) => (
      <>Maksa <b>{total}</b> käteisellä, kun tilauksesi saapuu.</>
    ),
    // Round-2 fixes brief, Part 5 — nouto-tilauksen vastine yllä olevalle
    // codNotelle (asiakas noutaa itse, ei kuriiri toimita).
    codNotePickup: (total: ReactNode) => (
      <>Maksa <b>{total}</b> käteisellä, kun noudat tilauksesi.</>
    ),
    // Part A (order confirmation screen) — shown instead of codNote when
    // paymentMethod is 'card'.
    cardPaidNote: (total: ReactNode) => (
      <>Maksettu <b>{total}</b> — kiitos!</>
    ),
    saveOrderNumber: (trackLink: ReactNode) => (
      <>Tallenna tilausnumerosi — voit tarkistaa tilauksesi tilan milloin tahansa {trackLink}-sivulla.</>
    ),
    trackLinkText: 'Seuraa tilausta',
    continueShopping: 'Jatka ostoksia',
    // Growth features (Feature 3 — stamp card / loyalty), redesigned.
    stampCardRewardApplied: '🎁 Kanta-asiakasetusi käytettiin tähän tilaukseen!',
    stampCardPendingEarned: (count: number) =>
      `🎉 Onnittelut ${count}. tilauksestasi! Käytämme kanta-asiakasetusi automaattisesti seuraavan kerran, kun tilaat jonkin siihen oikeuttavan tuotteen.`,
    loyaltyProgress: (count: number, remaining: number) => `Tämä on ${count}. tilauksesi — ${remaining} lisää palkintoon!`,
    copyCode: 'Kopioi koodi',
    codeCopied: 'Kopioitu!',
    // Growth features batch 2 (Feature 6 — "Ozy Wow Moment").
    wowMomentReward: '✨ Wow-hetki! Voitit yllätyspalkinnon seuraavaan tilaukseesi:',
  },

  // Part B (Stripe return_url / redirect handling) — ks. lib/i18n/en.tsx:n
  // sama kommentti.
  checkoutReturn: {
    checkingTitle: 'Tarkistetaan maksuasi…',
    checkingMessage: 'Hetki, vahvistamme maksusi Stripen kautta.',
    processingTitle: 'Maksua käsitellään',
    processingMessage: 'Maksusi on vielä käsittelyssä. Päivitämme tilauksesi heti, kun maksu on vahvistettu — voit tarkistaa tilanteen milloin tahansa Seuraa tilausta -sivulla.',
    failedTitle: 'Maksua ei suoritettu',
    failedMessage: 'Maksu ei mennyt läpi, joten tilaustasi ei tehty. Yritä uudelleen.',
    errorTitle: 'Jokin meni pieleen',
    errorMessage: 'Emme voineet vahvistaa maksusi tilaa täällä. Jos et ole varma, meniikö tilauksesi läpi, tarkista tilanne Seuraa tilausta -sivulta tai ota meihin yhteyttä ennen uutta yritystä.',
    successNoOrderNumMessage: 'Maksusi meni läpi — kiitos! Jos tilausnumerosi ei näy tässä, voit hakea tilauksesi puhelinnumerolla Seuraa tilausta -sivulla.',
    backToMenu: 'Takaisin menuun',
    trackOrderLink: 'Seuraa tilausta',
  },

  track: {
    eyebrow: 'Tilauksen tila',
    heading: 'Seuraa tilaustasi',
    desc: 'Anna tilausnumerosi (vahvistuksestasi) ja puhelinnumero, jota käytit tilatessasi.',
    orderNumberLabel: 'Tilausnumero',
    orderNumberPlaceholder: 'esim. OZY-AB123456',
    phoneLabel: 'Puhelinnumero',
    phonePlaceholder: 'Numero, jota käytit tilatessasi',
    trackOrderBtn: 'Seuraa tilausta',
    lookingUp: 'Haetaan tilaustasi…',
    fillBothFields: 'Anna sekä tilausnumerosi että puhelinnumerosi.',
    notFoundError: 'Emme löytäneet tilausta kyseisellä numerolla ja puhelinnumerolla. Tarkista molemmat ja yritä uudelleen.',
    genericError: 'Jotain meni pieleen. Yritä hetken kuluttua uudelleen.',
    dontHaveOrderNumber: 'Eikö tilausnumero ole tiedossa?',
    backToOrderNumber: '← Minulla on tilausnumero',
    recentOrdersHint: 'Tilasitko äskettäin tällä laitteella?',
    findMyOrders: 'Hae tilaukseni',
    searching: 'Haetaan…',
    noPhoneMatches: 'Emme löytäneet tuoreita tilauksia kyseisellä puhelinnumerolla.',
    recentOrdersForNumber: 'Tämän numeron viimeaikaiset tilaukset',
    placedAt: (date: string) => `Tilattu ${date}`,
    estimatedReadyBy: (time: string) => <>Arvioitu valmis <strong>{time}</strong></>,
    minutesLeftSoon: 'pitäisi olla valmis hetkestä hetkeen',
    minutesLeftOne: 'noin 1 min jäljellä',
    minutesLeft: (n: number) => `noin ${n} min jäljellä`,
    cancelledNotice: 'Tämä tilaus on peruutettu. Jos tämä on odottamatonta, soita meille.',
    stepReceived: 'Tilaus vastaanotettu',
    stepAccepted: 'Hyväksytty',
    stepPreparing: 'Valmistetaan',
    stepReady: 'Valmis',
    stepOnTheWay: 'Matkalla',
    stepDelivered: 'Toimitettu',
    stepReadyForPickup: 'Valmis noudettavaksi',
    stepPickedUp: 'Noudettu',
    deliveringTo: (addr: string, method: string) => `Toimitetaan osoitteeseen ${addr} · ${method}`,
    pickupAt: (method: string) => `Valmis noudettavaksi ravintolastamme · ${method}`,
    codPaymentLabel: 'Käteinen toimituksessa',
    trackDifferentOrder: '← Seuraa toista tilausta',
    // Growth features (Feature 1 — reorder).
    reorderButton: 'Tilaa uudelleen',
    reorderLoading: 'Valmistellaan uudelleentilaustasi…',
    reorderGenericError: 'Uudelleentilaus ei juuri nyt onnistunut. Yritä uudelleen.',
    reorderReadyNotice: (n: number) => `${n} tuote${n !== 1 ? 'tta' : ''} lisätty koriisi tämän päivän hintaan.`,
    reorderSkippedNotice: (n: number) => `${n} tuote${n !== 1 ? 'tta' : ''} ei ole enää saatavilla ja ${n !== 1 ? 'ne jätettiin' : 'se jätettiin'} pois. Loput ovat valmiina korissasi.`,
    reorderContinue: 'Jatka kassalle',
  },

  legal: {
    lastUpdated: (date: string) => `Päivitetty viimeksi: ${date}`,
  },

  privacy: {
    title: 'Tietosuojaseloste',
    metaTitle: 'Tietosuojaseloste — ozy.fi',
    lastUpdated: '6. syyskuuta 2026',
    intro: 'ozy.fi ("me") kunnioittaa yksityisyyttäsi. Tällä sivulla kerrotaan, mitä henkilötietoja keräämme, kun tilaat ruokaa tämän verkkosivun kautta, miksi keräämme niitä, ja mitä oikeuksia sinulla on EU:n yleisen tietosuoja-asetuksen (GDPR) mukaan.',
    s1Title: '1. Keitä olemme',
    s1CompanyPlaceholder: '[Yrityksen nimi / Y-tunnus — täytettävä]',
    s1AddressPlaceholder: '[Yrityksen osoite — täytettävä]',
    s2Title: '2. Mitä tietoja keräämme',
    s2Intro: 'Kun teet tilauksen, keräämme:',
    s2Items: ['Koko nimen', 'Toimitusosoitteen', 'Sähköpostiosoitteen', 'Puhelinnumeron', 'Tilauksen sisällön ja mahdolliset lisäämäsi huomautukset (esim. allergiat, ovikoodi)'],
    s3Title: '3. Miksi keräämme niitä',
    s3Items: ['Tilauksesi valmistamiseen ja toimittamiseen', 'Sinuun yhteyden ottamiseen tilaukseesi liittyen tarvittaessa', 'Kirjanpito- ja verolainsäädännön edellyttämien tietojen säilyttämiseen'],
    s3Outro: 'Emme myy henkilötietojasi kolmansille osapuolille.',
    s4Title: '4. Kuinka kauan säilytämme tietoja',
    s4Body: 'Tilaustietoja säilytetään niin kauan kuin Suomen kirjanpitolaki edellyttää (nykyisin 6 vuotta), minkä jälkeen ne poistetaan.',
    s5Title: '5. Oikeutesi',
    s5Intro: 'GDPR:n mukaan sinulla on oikeus:',
    s5Items: ['Kysyä, mitä henkilötietoja meillä on sinusta', 'Pyytää meitä korjaamaan virheelliset tiedot', 'Pyytää meitä poistamaan tietosi, mikäli se on lain mukaan mahdollista', 'Vastustaa tietojesi käyttöä'],
    s5Outro: 'Käyttääksesi näitä oikeuksia, lähetä sähköpostia osoitteeseen hello@ozy.fi.',
    s6Title: '6. Evästeet',
    s6Body: 'Tämä sivusto käyttää teknisiä evästeitä/paikallista tallennustilaa, joita tarvitaan ostoskorisi sisällön säilyttämiseen tilauksen aikana sekä evästevalintasi muistamiseen. Luvallasi (evästebannerin kautta annettuna) sivusto voi käyttää myös Google Analyticsin, Metan, TikTokin ja Microsoft Clarityn evästeitä sivuston kävijämäärän ja mainonnan tehokkuuden mittaamiseen. Voit peruuttaa tämän luvan milloin tahansa tyhjentämällä selaimesi sivustokohtaiset tiedot, jolloin evästebanneri näytetään uudelleen.',
    s7Title: '7. Yhteystiedot',
    s7Body: 'Kysyttävää tästä selosteesta? Lähetä sähköpostia osoitteeseen hello@ozy.fi.',
  },

  terms: {
    title: 'Käyttöehdot',
    metaTitle: 'Käyttöehdot — ozy.fi',
    lastUpdated: '6. syyskuuta 2026',
    s1Title: '1. Tilaukset',
    s1Body: 'Tekemällä tilauksen ozy.fi-sivustolla vahvistat, että antamasi toimitustiedot (nimi, osoite, puhelin, sähköposti) ovat oikein. Valmistamme tilauksesi heti sen saavuttua emmekä voi taata muutoksia lähettämisen jälkeen — soita meille, jos jokin tarvitsee korjausta.',
    s2Title: '2. Hinnat ja maksaminen',
    s2Body: 'Kaikki hinnat näytetään euroina (€) ja sisältävät arvonlisäveron soveltuvin osin. Maksutapana on toistaiseksi vain käteinen toimituksessa, maksettuna suoraan kuljettajalle.',
    s3Title: '3. Toimitus',
    s3Body: 'Kassalla näytetyt arvioidut toimitus-/valmistumisajat ovat suuntaa-antavia ja voivat vaihdella tilausmäärän, sään ja liikenteen mukaan.',
    s4Title: '4. Allergiat ja ruokatiedot',
    s4Body: 'Merkitse mahdolliset allergiat tai ruokavaliorajoitukset kassan "Lisätietoa ravintolalle" -kenttään. Vaikka olemme huolellisia ainesosien kanssa, keittiössämme käsitellään yleisiä allergeeneja (gluteeni, maitotuotteet, pähkinät) emmekä voi taata täysin allergeenitonta ympäristöä.',
    s5Title: '5. Peruutukset',
    s5Body: 'Peruuttaaksesi tai muuttaaksesi tilauksen, soita meille mahdollisimman pian. Kun valmistus on aloitettu, emme välttämättä voi enää perua tilausta.',
    s6Title: '6. Vastuunrajoitus',
    s6Body: 'ozy.fi ei vastaa viivästyksistä tai ongelmista, jotka johtuvat kohtuullisen vaikutusvaltamme ulkopuolella olevista olosuhteista (esim. ankarat sääolot, liikennehäiriöt).',
    s7Title: '7. Yhteystiedot',
    s7Body: 'Kysyttävää näistä ehdoista? Lähetä sähköpostia osoitteeseen hello@ozy.fi.',
  },

  // SEO-täydennys, osa C — ks. vastaava kommentti en.js:ssä. Nämä
  // suomenkieliset merkkijonot ovat matalamman luottamuksen käännöksiä
  // (ei natiivipuhujan tarkistamia) — merkitty tämän toimituksen
  // raporttiin tämän projektin oman käytännön mukaisesti (ks. tämän
  // tiedoston alun kommentti).
  about: {
    metaTitle: 'Meistä — ozy.fi',
    title: 'Meistä',
    storyHeading: 'Tarinamme',
    storyPlaceholder: 'Paikkamerkki — lisää tähän ozy.fi:n oikea tarina: miten kaikki alkoi, mikä tekee meistä erilaisen, ja mitä muuta haluatte kertoa asiakkaille.',
    findUsHeading: 'Meidät löydät',
  },

  contact: {
    metaTitle: 'Ota yhteyttä — ozy.fi',
    title: 'Ota yhteyttä',
    intro: 'Kysyttävää tilauksesta, toimituksesta tai muusta? Näin tavoitat meidät.',
  },

  delivery: {
    metaTitle: 'Kotiinkuljetus — ozy.fi',
    title: 'Kotiinkuljetus',
    intro: 'Tilaatko kotiinkuljetuksena? Tässä mitä voit odottaa.',
    feeLabel: 'Toimitusmaksu',
    minOrderLabel: 'Tilauksen vähimmäissumma',
    areaHeading: 'Toimitusalue',
    areaConfiguredIntro: 'Toimitamme tällä hetkellä näihin postinumeroihin (lyhyt merkintä kuten "00" kattaa kaikki sillä alkavat postinumerot):',
    areaUnset: 'Toimitusaluetta ei ole tällä hetkellä rajattu — syötä osoitteesi kassalla, niin vahvistamme sen siellä.',
  },

  pickup: {
    metaTitle: 'Nouto — ozy.fi',
    title: 'Nouto',
    intro: 'Haluatko noutaa tilauksesi itse? Tässä mistä ja milloin.',
    locationHeading: 'Noutopiste',
    hoursHeading: 'Noutoajat',
    orderingHeading: 'Miten tilaan noudettavaksi',
    orderingInstructions: 'Tilaa verkossa aivan kuten aina — lisää tuotteet ostoskoriin ja siirry kassalle. Valitse vaiheessa 2 "Nouto" "Kotiinkuljetuksen" sijaan: sinun ei tarvitse antaa toimitusosoitetta, eikä toimitusmaksua peritä. Tilauksesi on valmiina alla mainitussa osoitteessa ja aukioloaikoina.',
  },

  error: {
    heading: 'Jokin meni pieleen',
    body: 'Sivun lataamisessa tapahtui virhe. Yritä uudelleen — jos ongelma jatkuu, palaa etusivulle.',
    tryAgain: 'Yritä uudelleen',
    goHome: 'Etusivulle',
  },

  faq: {
    metaTitle: 'UKK — Toimitus, Maksutavat ja Tilaaminen | ozy.fi',
    title: 'Usein kysytyt kysymykset',
    intro: 'Nopeita vastauksia toimituksesta, maksutavoista ja tilaamisesta ozy.fi:ssä Helsingissä. Etkö löytänyt etsimääsi? Ota suoraan yhteyttä.',
    items: [
      {
        q: 'Mille alueille toimitatte?',
        a: 'Toimitamme tiettyihin Helsingin postinumeroihin. Syötä postinumerosi kassalla, niin näet heti kuuluuko osoitteesi toimitusalueeseemme.',
      },
      {
        q: 'Paljonko toimitus maksaa?',
        a: 'Toimitusmaksu näkyy selkeästi ostoskorissa ennen tilauksen vahvistamista — ei yllätyskuluja jälkikäteen.',
      },
      {
        q: 'Onko tilauksella minimisumma?',
        a: 'Kyllä, kotiinkuljetuksella on minimitilaussumma. Se näkyy ostoskorissasi, samoin kuin kuinka paljon sinun tarvitsee vielä lisätä sen täyttämiseksi.',
      },
      {
        // Audit-fixes-korjaukset, osa 2 — ks. en.tsx:n vastaava kommentti:
        // vastaus väitti korttimaksun olevan vielä tulossa, vaikka se on jo
        // käytössä. Pidetään yhdenmukaisena components/CheckoutModal.tsx:n
        // maksutapavalinnan kanssa ('cod' ja 'card', jälkimmäinen kuvattu
        // siellä "Kortti, Google Pay tai Apple Pay").
        q: 'Miten voin maksaa?',
        a: 'Voit maksaa kortilla, Google Paylla tai Apple Paylla verkossa kassalla, tai valita käteismaksun ja maksaa kuljettajalle tilauksen saapuessa.',
      },
      {
        q: 'Kuinka kauan toimitus kestää?',
        a: 'Useimmat tilaukset saapuvat 30-45 minuutissa, riippuen ruuhkasta ja etäisyydestäsi ravintolaan. Näet arvioidun toimitusajan tilausta tehdessäsi.',
      },
      {
        q: 'Voinko seurata tilaustani?',
        a: 'Kyllä — tilauksen tekemisen jälkeen voit seurata sen tilaa seurantasivullamme tilausnumerolla ja puhelinnumerolla.',
      },
      {
        q: 'Voinko muokata täytteitä tai kysyä allergioista?',
        a: 'Kyllä, jokaisen pizzan, kebabin ja burgerin voi muokata valitsemallasi pohjalla, kastikkeella, juustolla ja täytteillä tilatessasi. Erityisistä allergiakysymyksistä ota suoraan yhteyttä ennen tilaamista.',
      },
      {
        q: 'Voinko muuttaa tai peruuttaa tilaukseni sen tekemisen jälkeen?',
        a: 'Soita meille mahdollisimman pian — voimme usein tehdä muutoksia, jos tilauksesi valmistus ei ole vielä alkanut, mutta emme voi taata sitä valmistuksen jo alettua.',
      },
      // Priority-fixes-korjaukset (roadmap gap analysis), osa 3 — viisi
      // uutta kysymystä. Halal-saatavuutta ei lisätä tähän tarkoituksella:
      // meillä ei ole vahvistettua vastausta siihen, eikä tämän koko
      // toimeksiannon säännöissä keksitä liiketoimintatietoja — tämä on
      // merkitty toimituksen raporttiin liikkeenomistajan vahvistusta
      // odottavaksi.
      {
        q: 'Mitä ruokaa tarjoatte?',
        a: 'ozy.fi tarjoaa tuoretta, tilauksesta valmistettua pizzaa, kebabia ja hampurilaisia sekä schnitzeleitä, kanaa ja salaatteja — selaa koko ruokalistaa nähdäksesi kaiken tänään saatavilla olevan.',
      },
      {
        q: 'Onko teillä nouto vai vain kotiinkuljetus?',
        a: 'Molemmat. Valitse kassalla tilaustyypiksi "Nouto" välttääksesi toimitusmaksun — noutotilaukset valmistetaan heti niiden saavuttua (erillistä noutoaikaa ei vielä voi varata, joten tilaukset valmistuvat saapumisjärjestyksessä) ja ne ovat noudettavissa suoraan meiltä.',
      },
      {
        q: 'Mitkä ovat aukioloaikanne?',
        a: 'Ajantasaiset aukioloaikamme näkyvät etusivun yläosassa, samoin kuin se, olemmeko juuri nyt avoinna — ajat voivat vaihdella päivittäin, joten sieltä näet aina uusimman tiedon.',
      },
      {
        q: 'Missä sijaitsette?',
        a: 'Osoitteemme näkyy etusivun "Löydä meidät" -osiossa sekä Toimitus-sivullamme, yhdessä toimitusalueemme ja yhteystietojemme kanssa.',
      },
      {
        q: 'Mitä kokoja on saatavilla?',
        a: 'Pizzat ja muut muokattavat tuotteet ovat saatavilla Medium- ja Large-koossa (Large pientä lisämaksua vastaan) — valitse koko, pohja, kastike, juusto ja täytteet muokatessasi tuotetta. Tuotteet, joita ei voi muokata (kuten useimmat hampurilaiset), ovat saatavilla yhdessä koossa.',
      },
    ],
  },

  notFound: {
    heading: 'Sivua ei löytynyt',
    body: 'Etsimääsi sivua ei ole olemassa tai se on siirretty.',
    goHome: 'Etusivulle',
  },

  // Tilauskohtainen lasku (admin-paneeli, app/admin/orders/[id]/invoice) —
  // ainoa kaksikielinen kohta admin-paneelissa, koska toisin kuin muu
  // (tarkoituksella englanninkielinen, sisäinen) admin-käyttöliittymä,
  // tämän sivun voi tulostaa/tallentaa ja antaa suoraan asiakkaalle.
  invoice: {
    documentTitle: 'Lasku',
    orderNumber: 'Tilausnumero',
    orderDate: 'Tilauspäivä',
    customer: 'Asiakas',
    itemsHeading: 'Tuotteet',
    columnItem: 'Tuote',
    columnQty: 'Määrä',
    columnUnitPrice: 'Á-hinta',
    columnLineTotal: 'Yhteensä',
    subtotal: 'Välisumma',
    discount: 'Alennus',
    adjustment: 'Toimitusmaksu / muu lisäys',
    total: 'Loppusumma',
    paymentMethod: 'Maksutapa',
    paymentStatus: 'Maksun tila',
    vatNote: 'Hinnat sisältävät ALV:n, mikäli sovellettavissa.',
    printButton: 'Tulosta / tallenna PDF',
    backToOrder: '← Takaisin tilaukseen',
    loading: 'Ladataan laskua…',
    notFound: 'Tilausta ei voitu ladata.',
    forbidden: 'Sinulla ei ole oikeutta laskuihin — pyydä esihenkilöä tai omistajaa.',
    signInRequired: 'Kirjaudu sisään nähdäksesi tämän laskun.',
    pickupLabel: 'Noutotilaus — asiakas noutaa itse, ei toimitusosoitetta.',
    discountSourceLabel: {
      manual_coupon: 'Alennuskoodi',
      referral: 'Suosituspalkkio',
      first_order_welcome: 'Ensitilausalennus',
      stamp_card: 'Kanta-asiakaspalkkio',
      scheduled_offer: 'Erikoistarjous',
    } as Record<string, string>,
    paymentMethodLabel: {
      cod: 'Käteinen toimituksessa',
      card: 'Kortti',
    } as Record<string, string>,
  },

  languageSwitcher: {
    fi: 'Suomi',
    en: 'English',
    ariaLabel: 'Vaihda kieltä',
  },
};

export default fi;
