// ozy.fi backend Worker.
// Serves the static Next.js export for normal pages, and handles every
// /api/* route backed by D1.

const ADMIN_TABLES = {
  categories: { cols: ['id', 'title', 'sub', 'image', 'sort_order'] },
  products: {
    cols: [
      'id', 'category_id', 'name', 'description', 'price', 'offer_price',
      'image', 'tag', 'has_toppings', 'sort_order', 'active',
    ],
  },
  option_groups: { cols: ['id', 'title', 'kind', 'icon', 'sort_order'] },
  options: { cols: ['id', 'group_id', 'label', 'price_delta', 'color', 'sort_order'] },
  addons: { cols: ['id', 'type', 'name', 'price', 'image', 'active', 'sort_order'] },
  bundles: { cols: ['id', 'title', 'description', 'image', 'price', 'slots', 'active', 'sort_order'] },
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json;charset=UTF-8',
    },
  });
}

function slugify(text) {
  return String(text)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

// Clears the edge-cached /api/menu response for this datacenter so admin
// edits show up on the next request instead of waiting out the cache TTL.
// Note: Cloudflare's Cache API is per-datacenter, not global — this makes
// changes appear instantly for anyone routed through the same (or nearby)
// edge node as the admin, which covers the common case for a single-city
// restaurant; a visitor hitting a distant datacenter could still see the
// old menu for up to the remaining TTL.
async function purgeMenuCache(request, ctx) {
  const origin = new URL(request.url).origin;
  const cacheKey = new Request(`${origin}/api/menu`, { method: 'GET' });
  const del = caches.default.delete(cacheKey);
  if (ctx && ctx.waitUntil) ctx.waitUntil(del);
  else await del;
}

/* -------------------------------------------------------
   ADMIN AUTH
------------------------------------------------------- */

function bytesToBase64Url(bytes) {
  let binary = '';
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }

  return btoa(binary)
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function base64UrlToBytes(str) {
  const base64 = str
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);

  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

async function getAdminSecretKey(env) {
  const secret = `${env.ADMIN_EMAIL}:${env.ADMIN_PASSWORD}`;

  return crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    {
      name: 'HMAC',
      hash: 'SHA-256',
    },
    false,
    ['sign', 'verify']
  );
}

async function createAdminToken(env) {
  const timestamp = Math.floor(Date.now() / 1000);
  const payload = `ozy-admin:${timestamp}`;

  const key = await getAdminSecretKey(env);

  const signature = await crypto.subtle.sign(
    'HMAC',
    key,
    new TextEncoder().encode(payload)
  );

  return `${bytesToBase64Url(new TextEncoder().encode(payload))}.${bytesToBase64Url(new Uint8Array(signature))}`;
}

async function isAdmin(request, env) {
  const auth = request.headers.get('authorization') || '';
  const token = auth.startsWith('Bearer ')
    ? auth.slice(7)
    : '';

  if (!token) return false;

  const parts = token.split('.');

  if (parts.length !== 2) return false;

  try {
    const payload = new TextDecoder().decode(
      base64UrlToBytes(parts[0])
    );

    const [prefix, timestamp] = payload.split(':');

    if (prefix !== 'ozy-admin') return false;

    const tokenTime = Number(timestamp);

    if (!Number.isFinite(tokenTime)) return false;

    const now = Math.floor(Date.now() / 1000);

    // Token valid for 24 hours.
    if (now - tokenTime < 0 || now - tokenTime > 86400) {
      return false;
    }

    const key = await getAdminSecretKey(env);

    const signature = base64UrlToBytes(parts[1]);

    return await crypto.subtle.verify(
      'HMAC',
      key,
      signature,
      new TextEncoder().encode(payload)
    );
  } catch {
    return false;
  }
}

function requireAdmin(handler) {
  return async (request, env, ctx, params) => {
    if (!(await isAdmin(request, env))) {
      return json(
        { error: 'Unauthorized' },
        401
      );
    }

    return handler(request, env, ctx, params);
  };
}

/* -------------------------------------------------------
   PUBLIC: MENU
------------------------------------------------------- */

async function getMenu(request, env, ctx) {
  // Edge-cache the menu for a short window so most visitors get an
  // instant response instead of a D1 round-trip on every page load —
  // this is the main thing slowing down "browse → order" for customers.
  // Cloudflare's per-datacenter cache; a short TTL keeps admin edits
  // showing up quickly without needing a purge mechanism.
  const cache = caches.default;
  const cacheKey = new Request(request.url, { method: 'GET' });

  const cached = await cache.match(cacheKey);
  if (cached) return cached;

  const [
    categories,
    products,
    groups,
    options,
    addons,
    bundles,
    settingsRows,
  ] = await Promise.all([
    env.DB.prepare(
      'SELECT * FROM categories ORDER BY sort_order'
    ).all(),

    env.DB.prepare(
      'SELECT * FROM products WHERE active = 1 ORDER BY sort_order'
    ).all(),

    env.DB.prepare(
      'SELECT * FROM option_groups ORDER BY sort_order'
    ).all(),

    env.DB.prepare(
      'SELECT * FROM options ORDER BY sort_order'
    ).all(),

    env.DB.prepare(
      'SELECT * FROM addons WHERE active = 1 ORDER BY sort_order'
    ).all(),

    // Bundles/combos (e.g. "3 Pizza + 1.5L Lemonade — €45"). `slots` is
    // stored as a JSON string; the frontend parses it.
    env.DB.prepare(
      'SELECT * FROM bundles WHERE active = 1 ORDER BY sort_order'
    ).all(),

    // NOTE (audit fix): this comment used to say "never secrets" — that
    // stopped being true once the Tracking & Analytics feature added
    // secret_ga4_api_secret / secret_meta_access_token /
    // secret_tiktok_access_token rows to this same table. Every key is
    // still fetched here (cheap, one query), but anything prefixed
    // "secret_" is stripped below before it reaches the public response —
    // see the matching, deliberately identical rule in
    // lib/menu-data.js (the Next.js/SSR-branch equivalent of this
    // function) and app/api/menu/route.js's comment referencing it.
    env.DB.prepare(
      'SELECT key, value FROM admin_settings'
    ).all(),
  ]);

  const optionsByGroup = {};

  for (const o of options.results) {
    (optionsByGroup[o.group_id] ||= []).push(o);
  }

  const optionGroups = groups.results.map((g) => ({
    ...g,
    options: optionsByGroup[g.id] || [],
  }));

  const settings = {};

  for (const row of settingsRows.results) {
    // Keys prefixed "secret_" (ad-platform access tokens) never leave the
    // server via this public, unauthenticated endpoint.
    if (row.key.startsWith('secret_')) continue;
    settings[row.key] = row.value;
  }

  const payload = JSON.stringify({
    categories: categories.results,
    products: products.results,
    optionGroups,
    addons: addons.results,
    bundles: bundles.results,
    settings,
  });

  const response = new Response(payload, {
    status: 200,
    headers: {
      'content-type': 'application/json;charset=UTF-8',
      // Edge cache for 1 hour (purged instantly on any admin save via
      // purgeMenuCache); short browser-side max-age so a customer's own
      // tab still re-checks periodically rather than holding a full-hour
      // stale copy locally.
      'Cache-Control': 'public, max-age=60, s-maxage=90',
    },
  });

  if (ctx && ctx.waitUntil) {
    ctx.waitUntil(cache.put(cacheKey, response.clone()));
  } else {
    await cache.put(cacheKey, response.clone());
  }

  return response;
}

/* -------------------------------------------------------
   PUBLIC: ORDERS
------------------------------------------------------- */

function makeOrderNum() {
  const n = Math.floor(1000 + Math.random() * 9000);

  return `OZY-${Date.now()
    .toString(36)
    .toUpperCase()
    .slice(-4)}${n}`;
}

async function createOrder(request, env) {
  const body = await request
    .json()
    .catch(() => null);

  if (
    !body ||
    !body.customer ||
    !Array.isArray(body.items) ||
    body.items.length === 0
  ) {
    return json(
      { error: 'Invalid order payload' },
      400
    );
  }

  const {
    customer,
    items,
    total,
  } = body;

  if (
    !customer.name ||
    !customer.address ||
    !customer.email ||
    !customer.phone
  ) {
    return json(
      { error: 'Missing customer details' },
      400
    );
  }

  const orderNum = makeOrderNum();

  const insertOrder = await env.DB.prepare(
    `INSERT INTO orders
      (
        order_num,
        customer_name,
        address,
        email,
        phone,
        notes,
        total,
        status,
        payment_method
      )
     VALUES
      (?, ?, ?, ?, ?, ?, ?, 'received', 'cod')`
  )
    .bind(
      orderNum,
      customer.name,
      customer.address,
      customer.email,
      customer.phone,
      customer.notes || '',
      total
    )
    .run();

  const orderId = insertOrder.meta.last_row_id;

  const stmts = items.map((line) =>
    env.DB.prepare(
      `INSERT INTO order_items
        (
          order_id,
          product_id,
          name,
          qty,
          line_total,
          details
        )
       VALUES
        (?, ?, ?, ?, ?, ?)`
    ).bind(
      orderId,
      line.productId || null,
      line.name,
      line.qty,
      line.lineTotal,
      JSON.stringify(line.details || [])
    )
  );

  if (stmts.length) {
    await env.DB.batch(stmts);
  }

  return json(
    {
      orderNum,
      id: orderId,
      status: 'received',
    },
    201
  );
}

// Last-6-digits comparison tolerates the different phone formats the
// checkout form itself accepts (+358401234567 vs 0401234567 vs spaced/
// dashed variants) without needing to fully normalize to E.164.
function phoneMatches(a, b) {
  const da = String(a || '').replace(/\D/g, '');
  const db = String(b || '').replace(/\D/g, '');
  if (da.length < 6 || db.length < 6) return false;
  return da.slice(-6) === db.slice(-6);
}

async function trackOrder(
  request,
  env,
  ctx,
  params
) {
  const url = new URL(request.url);
  const phone = url.searchParams.get('phone') || '';

  const order = await env.DB.prepare(
    'SELECT * FROM orders WHERE order_num = ?'
  )
    .bind(params.orderNum)
    .first();

  // Order number alone isn't secret enough to hand back a stranger's name,
  // address and phone on request — also require the phone number used at
  // checkout. Same generic error either way, so a guesser can't tell
  // whether the order number or the phone was the part that was wrong.
  if (!order || !phoneMatches(order.phone, phone)) {
    return json(
      { error: 'Order not found' },
      404
    );
  }

  const items = await env.DB.prepare(
    'SELECT * FROM order_items WHERE order_id = ?'
  )
    .bind(order.id)
    .all();

  return json({
    ...order,
    items: items.results,
  });
}

/* -------------------------------------------------------
   ADMIN: LOGIN
------------------------------------------------------- */

async function adminLogin(request, env) {
  const body = await request
    .json()
    .catch(() => ({}));

  const email = String(body.email || '').trim();
  const password = String(body.password || '');

  if (!env.ADMIN_EMAIL || !env.ADMIN_PASSWORD) {
    return json(
      {
        error: 'Admin authentication is not configured',
      },
      500
    );
  }

  if (
    email !== env.ADMIN_EMAIL ||
    password !== env.ADMIN_PASSWORD
  ) {
    return json(
      { error: 'Invalid email or password' },
      401
    );
  }

  const token = await createAdminToken(env);

  return json({
    token,
    email: env.ADMIN_EMAIL,
  });
}

/* -------------------------------------------------------
   ADMIN: GENERIC CRUD
------------------------------------------------------- */

async function adminList(
  request,
  env,
  ctx,
  params
) {
  const table = ADMIN_TABLES[params.table];

  if (!table) {
    return json(
      { error: 'Unknown table' },
      404
    );
  }

  const rows = await env.DB.prepare(
    `SELECT * FROM ${params.table} ORDER BY sort_order`
  ).all();

  return json(rows.results);
}

async function adminCreate(
  request,
  env,
  ctx,
  params
) {
  const table = ADMIN_TABLES[params.table];

  if (!table) {
    return json(
      { error: 'Unknown table' },
      404
    );
  }

  const body = await request
    .json()
    .catch(() => ({}));

  if (!body.id && body.name) {
    body.id = `${slugify(body.name)}-${Date.now()
      .toString(36)
      .slice(-4)}`;
  }

  if (!body.id && body.label) {
    body.id = `${slugify(body.label)}-${Date.now()
      .toString(36)
      .slice(-4)}`;
  }

  if (!body.id) {
    return json(
      {
        error: 'id (or name/label) required',
      },
      400
    );
  }

  const cols = table.cols.filter(
    (c) => c in body
  );

  const placeholders = cols
    .map(() => '?')
    .join(', ');

  const values = cols.map(
    (c) => body[c]
  );

  await env.DB.prepare(
    `INSERT INTO ${params.table}
      (${cols.join(', ')})
     VALUES
      (${placeholders})`
  )
    .bind(...values)
    .run();

  await purgeMenuCache(request, ctx);

  return json(
    {
      ok: true,
      id: body.id,
    },
    201
  );
}

async function adminUpdate(
  request,
  env,
  ctx,
  params
) {
  const table = ADMIN_TABLES[params.table];

  if (!table) {
    return json(
      { error: 'Unknown table' },
      404
    );
  }

  const body = await request
    .json()
    .catch(() => ({}));

  const cols = table.cols.filter(
    (c) => c in body && c !== 'id'
  );

  if (!cols.length) {
    return json(
      { error: 'Nothing to update' },
      400
    );
  }

  const setClause = cols
    .map((c) => `${c} = ?`)
    .join(', ');

  const values = cols.map(
    (c) => body[c]
  );

  await env.DB.prepare(
    `UPDATE ${params.table}
     SET ${setClause}
     WHERE id = ?`
  )
    .bind(
      ...values,
      params.id
    )
    .run();

  await purgeMenuCache(request, ctx);

  return json({ ok: true });
}

async function adminDelete(
  request,
  env,
  ctx,
  params
) {
  const table = ADMIN_TABLES[params.table];

  if (!table) {
    return json(
      { error: 'Unknown table' },
      404
    );
  }

  await env.DB.prepare(
    `DELETE FROM ${params.table} WHERE id = ?`
  )
    .bind(params.id)
    .run();

  await purgeMenuCache(request, ctx);

  return json({ ok: true });
}

/* -------------------------------------------------------
   ADMIN: IMAGE UPLOAD (Cloudflare R2)
------------------------------------------------------- */

const ALLOWED_IMAGE_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/gif',
]);

const MAX_IMAGE_BYTES = 5 * 1024 * 1024; // 5MB

function extFromContentType(type) {
  switch (type) {
    case 'image/jpeg': return 'jpg';
    case 'image/png': return 'png';
    case 'image/webp': return 'webp';
    case 'image/gif': return 'gif';
    default: return 'bin';
  }
}

async function adminUploadImage(request, env) {
  if (!env.IMAGES) {
    return json(
      { error: 'Image storage is not configured. Add an IMAGES R2 bucket binding.' },
      500
    );
  }

  const contentType = request.headers.get('content-type') || '';

  if (!contentType.startsWith('multipart/form-data')) {
    return json({ error: 'Expected multipart/form-data with a "file" field.' }, 400);
  }

  const form = await request.formData().catch(() => null);
  const file = form ? form.get('file') : null;

  if (!file || typeof file === 'string') {
    return json({ error: 'No file provided.' }, 400);
  }

  if (!ALLOWED_IMAGE_TYPES.has(file.type)) {
    return json({ error: 'Only JPEG, PNG, WEBP or GIF images are allowed.' }, 400);
  }

  if (file.size > MAX_IMAGE_BYTES) {
    return json({ error: 'Image is too large (max 5MB).' }, 400);
  }

  const ext = extFromContentType(file.type);
  const key = `uploads/${Date.now().toString(36)}-${crypto.randomUUID().slice(0, 8)}.${ext}`;

  await env.IMAGES.put(key, await file.arrayBuffer(), {
    httpMetadata: { contentType: file.type },
  });

  return json({ ok: true, url: `/images/${key}` }, 201);
}

async function serveImage(request, env, ctx, params) {
  if (!env.IMAGES) {
    return json({ error: 'Image storage is not configured.' }, 500);
  }

  const object = await env.IMAGES.get(params.key);

  if (!object) {
    return json({ error: 'Not found' }, 404);
  }

  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set('etag', object.httpEtag);
  headers.set('cache-control', 'public, max-age=31536000, immutable');

  return new Response(object.body, { headers });
}

/* -------------------------------------------------------
   ADMIN: ORDERS
------------------------------------------------------- */

async function adminListOrders(request, env) {
  const url = new URL(request.url);

  const status = url.searchParams.get(
    'status'
  );

  const rows = status
    ? await env.DB.prepare(
        'SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC'
      )
        .bind(status)
        .all()
    : await env.DB.prepare(
        'SELECT * FROM orders ORDER BY created_at DESC'
      ).all();

  return json(rows.results);
}

async function adminOrderDetail(
  request,
  env,
  ctx,
  params
) {
  const order = await env.DB.prepare(
    'SELECT * FROM orders WHERE id = ?'
  )
    .bind(params.id)
    .first();

  if (!order) {
    return json(
      { error: 'Not found' },
      404
    );
  }

  const items = await env.DB.prepare(
    'SELECT * FROM order_items WHERE order_id = ?'
  )
    .bind(params.id)
    .all();

  return json({
    ...order,
    items: items.results,
  });
}

async function adminUpdateOrderStatus(
  request,
  env,
  ctx,
  params
) {
  const body = await request
    .json()
    .catch(() => ({}));

  const allowed = [
    'received',
    'preparing',
    'on_the_way',
    'delivered',
    'cancelled',
  ];

  if (!allowed.includes(body.status)) {
    return json(
      { error: 'Invalid status' },
      400
    );
  }

  await env.DB.prepare(
    'UPDATE orders SET status = ? WHERE id = ?'
  )
    .bind(
      body.status,
      params.id
    )
    .run();

  return json({ ok: true });
}

/* -------------------------------------------------------
   ADMIN: ANALYTICS (dashboard KPIs, trends, best sellers)
------------------------------------------------------- */

// One conditional-aggregation pass over `orders` for every headline KPI +
// period-over-period comparison the dashboard needs (today vs yesterday,
// last 7 days vs the 7 before that, last 30 days vs the 30 before that).
// Rolling windows rather than calendar day/week/month — avoids a Monday
// looking artificially "down" against a full previous week.
async function loadSummary(env) {
  const row = await env.DB.prepare(
    `SELECT
      SUM(CASE WHEN date(created_at) = date('now') AND status != 'cancelled' THEN total ELSE 0 END) AS today_revenue,
      SUM(CASE WHEN date(created_at) = date('now') THEN 1 ELSE 0 END) AS today_orders,
      SUM(CASE WHEN date(created_at) = date('now','-1 day') AND status != 'cancelled' THEN total ELSE 0 END) AS yesterday_revenue,
      SUM(CASE WHEN date(created_at) = date('now','-1 day') THEN 1 ELSE 0 END) AS yesterday_orders,
      SUM(CASE WHEN created_at >= datetime('now','-7 days') AND status != 'cancelled' THEN total ELSE 0 END) AS last7_revenue,
      SUM(CASE WHEN created_at >= datetime('now','-7 days') THEN 1 ELSE 0 END) AS last7_orders,
      SUM(CASE WHEN created_at >= datetime('now','-14 days') AND created_at < datetime('now','-7 days') AND status != 'cancelled' THEN total ELSE 0 END) AS prev7_revenue,
      SUM(CASE WHEN created_at >= datetime('now','-14 days') AND created_at < datetime('now','-7 days') THEN 1 ELSE 0 END) AS prev7_orders,
      SUM(CASE WHEN created_at >= datetime('now','-30 days') AND status != 'cancelled' THEN total ELSE 0 END) AS last30_revenue,
      SUM(CASE WHEN created_at >= datetime('now','-30 days') THEN 1 ELSE 0 END) AS last30_orders,
      SUM(CASE WHEN created_at >= datetime('now','-60 days') AND created_at < datetime('now','-30 days') AND status != 'cancelled' THEN total ELSE 0 END) AS prev30_revenue,
      SUM(CASE WHEN created_at >= datetime('now','-60 days') AND created_at < datetime('now','-30 days') THEN 1 ELSE 0 END) AS prev30_orders,
      SUM(CASE WHEN status != 'cancelled' THEN total ELSE 0 END) AS total_revenue,
      COUNT(*) AS total_orders,
      SUM(CASE WHEN status IN ('received','preparing','on_the_way') THEN 1 ELSE 0 END) AS pending_orders,
      SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS completed_orders,
      SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders
    FROM orders`
  ).first();

  const n = (v) => Number(v || 0);

  return {
    today: { revenue: n(row.today_revenue), orders: n(row.today_orders) },
    yesterday: { revenue: n(row.yesterday_revenue), orders: n(row.yesterday_orders) },
    last7Days: { revenue: n(row.last7_revenue), orders: n(row.last7_orders) },
    prev7Days: { revenue: n(row.prev7_revenue), orders: n(row.prev7_orders) },
    last30Days: { revenue: n(row.last30_revenue), orders: n(row.last30_orders) },
    prev30Days: { revenue: n(row.prev30_revenue), orders: n(row.prev30_orders) },
    totalRevenue: n(row.total_revenue),
    totalOrders: n(row.total_orders),
    avgOrderValue: n(row.total_orders) ? n(row.total_revenue) / n(row.total_orders) : 0,
    pendingOrders: n(row.pending_orders),
    completedOrders: n(row.completed_orders),
    cancelledOrders: n(row.cancelled_orders),
  };
}

async function adminAnalytics(request, env) {
  const [summary, revenueByDayRows, bestSellersRows, categoryRows, statusRows, hourlyRows] = await Promise.all([
    loadSummary(env),

    // Daily revenue + order count for the last 30 days (chart fills gaps client-side).
    env.DB.prepare(
      `SELECT date(created_at) AS day,
              SUM(CASE WHEN status != 'cancelled' THEN total ELSE 0 END) AS revenue,
              COUNT(*) AS orders
       FROM orders
       WHERE created_at >= datetime('now','-30 days')
       GROUP BY day
       ORDER BY day ASC`
    ).all(),

    // Best-selling products by quantity, aggregated straight from order_items
    // (works even for items whose product was later edited/deleted, since
    // name/qty/line_total are snapshotted onto the order at checkout time).
    env.DB.prepare(
      `SELECT oi.name AS name, SUM(oi.qty) AS qty, SUM(oi.line_total) AS revenue
       FROM order_items oi
       JOIN orders o ON o.id = oi.order_id
       WHERE o.status != 'cancelled'
       GROUP BY oi.name
       ORDER BY qty DESC
       LIMIT 8`
    ).all(),

    // Revenue by category (join through products; anything whose product
    // was deleted, or that isn't tied to a category, buckets into "Other").
    env.DB.prepare(
      `SELECT COALESCE(c.title, 'Other') AS category,
              SUM(oi.line_total) AS revenue,
              SUM(oi.qty) AS qty
       FROM order_items oi
       JOIN orders o ON o.id = oi.order_id
       LEFT JOIN products p ON p.id = oi.product_id
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE o.status != 'cancelled'
       GROUP BY category
       ORDER BY revenue DESC`
    ).all(),

    // Order status mix over the last 30 days (donut on the dashboard).
    env.DB.prepare(
      `SELECT status, COUNT(*) AS count
       FROM orders
       WHERE created_at >= datetime('now','-30 days')
       GROUP BY status`
    ).all(),

    // Orders by hour of day over the last 30 days — spots peak service hours.
    env.DB.prepare(
      `SELECT CAST(strftime('%H', created_at) AS INTEGER) AS hour, COUNT(*) AS count
       FROM orders
       WHERE created_at >= datetime('now','-30 days')
       GROUP BY hour
       ORDER BY hour ASC`
    ).all(),
  ]);

  return json({
    summary,
    revenueByDay: revenueByDayRows.results.map((r) => ({ day: r.day, revenue: Number(r.revenue || 0), orders: Number(r.orders || 0) })),
    bestSellers: bestSellersRows.results.map((r) => ({ name: r.name, qty: Number(r.qty || 0), revenue: Number(r.revenue || 0) })),
    categoryBreakdown: categoryRows.results.map((r) => ({ category: r.category, revenue: Number(r.revenue || 0), qty: Number(r.qty || 0) })),
    statusBreakdown: statusRows.results.map((r) => ({ status: r.status, count: Number(r.count || 0) })),
    hourlyDistribution: hourlyRows.results.map((r) => ({ hour: Number(r.hour), count: Number(r.count || 0) })),
  });
}

/* -------------------------------------------------------
   ADMIN: SETTINGS
------------------------------------------------------- */

async function adminGetSettings(
  request,
  env
) {
  const rows = await env.DB.prepare(
    'SELECT key, value FROM admin_settings'
  ).all();

  const out = {};

  for (const r of rows.results) {
    out[r.key] = r.value;
  }

  // Never expose admin password.
  delete out.admin_password;

  return json(out);
}

async function adminUpdateSettings(
  request,
  env,
  ctx
) {
  const body = await request
    .json()
    .catch(() => ({}));

  // Prevent changing authentication secrets
  // through the database settings endpoint.
  delete body.admin_password;
  delete body.ADMIN_PASSWORD;
  delete body.ADMIN_EMAIL;

  const stmts = Object.entries(body).map(
    ([key, value]) =>
      env.DB.prepare(
        `INSERT INTO admin_settings
          (key, value)
         VALUES
          (?, ?)
         ON CONFLICT(key)
         DO UPDATE SET
          value = excluded.value`
      ).bind(
        key,
        String(value)
      )
  );

  if (stmts.length) {
    await env.DB.batch(stmts);
  }

  await purgeMenuCache(request, ctx);

  return json({ ok: true });
}

async function adminChangePassword(
  request,
  env
) {
  return json(
    {
      error:
        'Admin password is managed through Cloudflare Secrets.',
    },
    403
  );
}

/* -------------------------------------------------------
   ROUTER
------------------------------------------------------- */

const routes = [
  ['GET', /^\/api\/menu$/, getMenu],

  ['POST', /^\/api\/orders$/, createOrder],

  [
    'GET',
    /^\/api\/orders\/(?<orderNum>[^/]+)$/,
    trackOrder,
  ],

  ['POST', /^\/api\/admin\/login$/, adminLogin],

  [
    'GET',
    /^\/api\/admin\/settings$/,
    requireAdmin(adminGetSettings),
  ],

  [
    'PUT',
    /^\/api\/admin\/settings$/,
    requireAdmin(adminUpdateSettings),
  ],

  [
    'POST',
    /^\/api\/admin\/change-password$/,
    requireAdmin(adminChangePassword),
  ],

  [
    'POST',
    /^\/api\/admin\/upload$/,
    requireAdmin(adminUploadImage),
  ],

  [
    'GET',
    /^\/api\/admin\/orders$/,
    requireAdmin(adminListOrders),
  ],

  [
    'GET',
    /^\/api\/admin\/orders\/(?<id>\d+)$/,
    requireAdmin(adminOrderDetail),
  ],

  [
    'PATCH',
    /^\/api\/admin\/orders\/(?<id>\d+)$/,
    requireAdmin(adminUpdateOrderStatus),
  ],

  [
    'GET',
    /^\/api\/admin\/analytics$/,
    requireAdmin(adminAnalytics),
  ],

  [
    'GET',
    /^\/api\/admin\/(?<table>[a-z_]+)$/,
    requireAdmin(adminList),
  ],

  [
    'POST',
    /^\/api\/admin\/(?<table>[a-z_]+)$/,
    requireAdmin(adminCreate),
  ],

  [
    'PUT',
    /^\/api\/admin\/(?<table>[a-z_]+)\/(?<id>[^/]+)$/,
    requireAdmin(adminUpdate),
  ],

  [
    'DELETE',
    /^\/api\/admin\/(?<table>[a-z_]+)\/(?<id>[^/]+)$/,
    requireAdmin(adminDelete),
  ],
];

export default {
  async fetch(
    request,
    env,
    ctx
  ) {
    const url = new URL(
      request.url
    );

    if (
      url.pathname.startsWith('/api/')
    ) {
      for (
        const [
          method,
          pattern,
          handler,
        ] of routes
      ) {
        if (
          request.method !== method
        ) {
          continue;
        }

        const match =
          url.pathname.match(
            pattern
          );

        if (match) {
          try {
            return await handler(
              request,
              env,
              ctx,
              match.groups || {}
            );
          } catch (err) {
            return json(
              {
                error:
                  'Server error',
                detail:
                  String(err),
              },
              500
            );
          }
        }
      }

      return json(
        { error: 'Not found' },
        404
      );
    }

    if (url.pathname.startsWith('/images/')) {
      return serveImage(
        request,
        env,
        ctx,
        { key: url.pathname.slice('/images/'.length) }
      );
    }

    // Not an API route — serve the static Next.js export.
    return env.ASSETS.fetch(
      request
    );
  },
};
