import type { OrderStatus, StampCardPendingRewardRow } from './types';

export function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json;charset=UTF-8' },
  });
}

export function slugify(text: unknown): string {
  return String(text)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

interface AdminTableDef {
  cols: string[];
}

// `_fi` columns (Phase: bilingual site) are listed alongside their
// English/default counterpart in every table below — see worker/
// schema.sql's comment on those columns for why they're optional and
// never the sole source of truth.
export const ADMIN_TABLES: Record<string, AdminTableDef> = {
  categories: { cols: ['id', 'title', 'title_fi', 'sub', 'sub_fi', 'image', 'sort_order'] },
  products: {
    cols: [
      'id', 'category_id', 'name', 'name_fi', 'description', 'description_fi', 'price', 'offer_price',
      'image', 'tag', 'has_toppings', 'sort_order', 'active',
    ],
  },
  option_groups: { cols: ['id', 'title', 'title_fi', 'kind', 'icon', 'sort_order'] },
  options: { cols: ['id', 'group_id', 'label', 'label_fi', 'price_delta', 'color', 'sort_order'] },
  addons: { cols: ['id', 'type', 'name', 'name_fi', 'price', 'image', 'active', 'sort_order'] },
  bundles: { cols: ['id', 'title', 'title_fi', 'description', 'description_fi', 'image', 'price', 'slots', 'active', 'sort_order'] },
  // Growth features batch 2 (Feature 5) — managed through this SAME
  // generic CRUD system rather than a bespoke API, matching every other
  // "admin-manageable list" table above. See worker/schema.sql for
  // column meanings and app/api/admin/[table]/route.ts /
  // app/api/admin/[table]/[id]/route.ts for the table-specific
  // validation added alongside `products`' own offer_price check.
  // discount_type/discount_value (shared discount-value pattern — see
  // worker/migrations/011_shared_discount_value.sql) added alongside the
  // legacy discount_percent column, which components/admin/
  // ScheduledOffersManager.tsx still writes too (0 when amount-shaped)
  // purely to satisfy that column's NOT NULL constraint.
  scheduled_offers: {
    cols: ['id', 'label', 'days', 'start_time', 'end_time', 'discount_percent', 'discount_type', 'discount_value', 'active', 'sort_order'],
  },
};

// Same per-datacenter cache purge as the old worker — see app/api/menu/route.js.
export async function purgeMenuCache(request: Request, ctx?: { waitUntil?: (p: Promise<unknown>) => void } | null): Promise<void> {
  const origin = new URL(request.url).origin;
  const cacheKey = new Request(`${origin}/api/menu`, { method: 'GET' });
  const del = caches.default.delete(cacheKey);
  if (ctx && ctx.waitUntil) ctx.waitUntil(del);
  else await del;
}

export function makeOrderNum(): string {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `OZY-${Date.now().toString(36).toUpperCase().slice(-4)}${n}`;
}

// Last-6-digits comparison tolerates the different phone formats the
// checkout form itself accepts, without needing full E.164 normalization.
export function phoneMatches(a: unknown, b: unknown): boolean {
  const da = String(a || '').replace(/\D/g, '');
  const db = String(b || '').replace(/\D/g, '');
  if (da.length < 6 || db.length < 6) return false;
  return da.slice(-6) === db.slice(-6);
}

export interface PhoneOrderRow {
  phone: string;
  status: OrderStatus;
}

// Growth features (welcome discount + stamp card) — every past order for
// a given phone number, matched the same way as everywhere else in this
// codebase (phoneMatches' last-6-digits tolerance — see
// app/api/orders/by-phone/route.ts for the original use of this
// tolerance). Deliberately NOT windowed by date/row-count the way that
// route's own lookup is (that one only needs to show a customer their own
// recent orders for a self-service UI) — "is this phone's first order
// ever" and "how many non-cancelled orders has this phone placed in
// total" both need the phone's FULL history to be correct, not just the
// last 7 days. A plain `SELECT phone, status FROM orders` (no WHERE
// clause) is an acceptable full-table read at this business's current
// order volume — same volume assumption already made elsewhere in this
// project (see app/api/orders/route.ts's coupon-usage-counter comment) —
// but will need revisiting (e.g. a real phone index/column) if order
// volume grows enough to make a full-table scan on every checkout slow.
export async function findOrdersByPhone(env: CloudflareEnv, phone: string): Promise<PhoneOrderRow[]> {
  const rows = await env.DB.prepare('SELECT phone, status FROM orders').all<PhoneOrderRow>();
  return rows.results.filter((o) => phoneMatches(o.phone, phone));
}

// Shared single-use coupon code generator for the stamp-card and referral
// features (app/api/orders/route.ts and app/api/referral/route.ts) —
// same "timestamp base36 + random 4 digits" shape as makeOrderNum() above,
// just with a feature-specific prefix instead of "OZY", so a business
// owner looking at the coupons list can immediately tell where a code
// came from (admin-created vs. auto-generated by which feature).
// Astronomically unlikely to collide with an existing code (same
// acceptable risk level makeOrderNum() already carries for order_num,
// which is also uniqueness-constrained with no retry loop) — never
// verified unique before use.
export function makeCouponCode(prefix: string): string {
  const n = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${Date.now().toString(36).toUpperCase().slice(-4)}${n}`;
}

// Stamp-card redesign — same full-table-scan + phoneMatches() tolerance
// as findOrdersByPhone above, over the new stamp_card_pending_rewards
// table (worker/migrations/010_stamp_card_redesign_and_source_tracking.
// sql) instead of `orders`. Only un-redeemed rows are ever candidates —
// a redeemed one is history, not something a future order could still
// apply. Returns the single row for this phone, or null if none is
// pending; app/api/orders/route.ts's own logic is what guarantees at
// most one un-redeemed row per phone ever exists, not a query here.
export async function findPendingStampCardReward(
  env: CloudflareEnv,
  phone: string
): Promise<StampCardPendingRewardRow | null> {
  const rows = await env.DB.prepare('SELECT * FROM stamp_card_pending_rewards WHERE redeemed_at IS NULL')
    .all<StampCardPendingRewardRow>();
  return rows.results.find((r) => phoneMatches(r.phone, phone)) || null;
}
